(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 645645, e => {
    "use strict";
    var t = e.i(843476),
        l = e.i(657688),
        a = e.i(271645),
        r = e.i(745850),
        n = e.i(862356),
        s = e.i(429452),
        i = e.i(900949),
        o = e.i(770703),
        c = e.i(522016),
        d = e.i(599109),
        h = e.i(916494);
    let f = (0, o.default)(() => e.A(466552), {
        loadableGenerated: {
            modules: [79313]
        },
        ssr: !1
    });

    function u({
        next: e
    }) {
        let [l, r] = (0, a.useState)(!1), n = (0, a.useRef)(null), [s, i] = (0, a.useState)(!1);
        return (0, a.useEffect)(() => {
            let e = n.current;
            if (!e) return;
            let t = new IntersectionObserver(([e]) => {
                e.isIntersecting && (i((0, h.can3D)()), t.disconnect())
            }, {
                rootMargin: "100%"
            });
            return t.observe(e), () => t.disconnect()
        }, []), (0, t.jsxs)("section", {
            ref: n,
            className: "pj-next",
            "aria-label": "Next project",
            children: [(0, t.jsxs)("p", {
                className: "pj-next-info",
                children: [(0, t.jsx)("span", {
                    className: "pj-next-label",
                    children: "[Next tape]"
                }), e.title]
            }), (0, t.jsxs)(c.default, {
                href: `/work/${e.slug}`,
                className: `pj-next-tape${l?" is-out":""}`,
                "data-caption": "[Play tape]",
                "aria-label": `Next: ${e.title}`,
                onPointerEnter: e => "mouse" === e.pointerType && r(!0),
                onPointerLeave: () => r(!1),
                onFocus: () => r(!0),
                onBlur: () => r(!1),
                children: [(0, t.jsx)("span", {
                    className: "pj-next-cassette",
                    "aria-hidden": !0,
                    children: s && (0, t.jsx)(f, {
                        out: !1,
                        portrait: e.photo
                    })
                }), (0, t.jsxs)("span", {
                    className: "pj-next-sleeve",
                    children: [(0, t.jsx)(p, {
                        src: e.sleeve
                    }), (0, t.jsx)(m, {
                        seed: e.slug
                    })]
                })]
            })]
        })
    }

    function m({
        seed: e
    }) {
        let l = (0, a.useRef)(null);
        return (0, a.useEffect)(() => {
            let t = l.current,
                a = t ? .getContext("2d");
            if (!t || !a) return;
            a.clearRect(0, 0, t.width, t.height);
            let r = 0;
            for (let t of e) r = (31 * r + t.charCodeAt(0)) % 0x7fffffff;
            (0, d.drawWear)(a, t.width, t.height, 4001 + r % 1e5)
        }, [e]), (0, t.jsx)("canvas", {
            ref: l,
            className: "pj-next-wear",
            width: 762,
            height: 1150,
            "aria-hidden": !0
        })
    }

    function p({
        src: e
    }) {
        let {
            done: a,
            onDone: r,
            fade: n
        } = (0, s.useMediaLoad)();
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)(s.MediaLoading, {
                done: a
            }), (0, t.jsx)(l.default, {
                src: e,
                alt: "",
                fill: !0,
                sizes: "30vw",
                className: n,
                onLoad: r,
                onError: r,
                style: {
                    objectFit: "cover"
                }
            })]
        })
    }
    var x = e.i(306257),
        v = e.i(58685),
        j = e.i(942295);

    function b({
        section: e,
        low: l
    }) {
        return (0, t.jsxs)("section", {
            className: `pj-copy${l?" is-low":""}`,
            "aria-label": e.label,
            children: [(0, t.jsxs)("p", {
                className: "pj-copy-label",
                children: ["[", e.label, "]"]
            }), (0, t.jsxs)("div", {
                className: "pj-copy-text",
                children: [(0, t.jsx)("h2", {
                    className: "pj-copy-lead",
                    children: e.lead
                }), e.body.map(e => (0, t.jsx)("p", {
                    className: "pj-copy-body",
                    children: e
                }, e))]
            })]
        })
    }

    function g({
        label: e,
        items: l,
        i: a
    }) {
        return (0, t.jsxs)("div", {
            className: "pj-detail",
            children: [(0, t.jsx)("dt", {
                children: (0, t.jsxs)(r.Reveal, {
                    i: a,
                    children: ["[", e, "]"]
                })
            }), l.map(e => (0, t.jsx)("dd", {
                children: (0, t.jsx)(r.Reveal, {
                    i: a,
                    children: e
                })
            }, e))]
        })
    }

    function w({
        m: e,
        first: a
    }) {
        let {
            done: r,
            onDone: n,
            fade: i
        } = (0, s.useMediaLoad)();
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)(s.MediaLoading, {
                done: r
            }), "video" === e.kind ? (0, t.jsxs)(t.Fragment, {
                children: [e.poster && (0, t.jsx)(l.default, {
                    src: e.poster,
                    alt: "",
                    fill: !0,
                    sizes: "60vw",
                    className: i,
                    onLoad: n,
                    onError: n,
                    style: {
                        objectFit: "cover"
                    }
                }), (0, t.jsx)("video", {
                    src: e.src,
                    muted: !0,
                    loop: !0,
                    playsInline: !0,
                    preload: "metadata",
                    className: i,
                    onLoadedData: n,
                    onError: n,
                    "aria-label": e.alt || void 0
                })]
            }) : (0, t.jsx)(l.default, {
                src: e.src,
                alt: e.alt,
                fill: !0,
                sizes: "60vw",
                priority: a,
                className: i,
                onLoad: n,
                onError: n,
                style: {
                    objectFit: "cover"
                }
            })]
        })
    }
    e.s(["default", 0, function({
        title: e,
        client: l,
        year: s,
        services: o,
        results: c,
        description: d,
        summary: h,
        url: f,
        slides: m,
        sections: p = [],
        next: y
    }) {
        let M = (0, a.useRef)(null),
            S = (0, a.useRef)(null),
            [E, N] = (0, a.useState)(0),
            [L, R] = (0, a.useState)(null),
            k = (0, a.useRef)(null),
            T = (0, a.useCallback)(e => {
                R(e), k.current ? .(e)
            }, []),
            [C, P] = (0, a.useState)(),
            $ = (0, a.useCallback)(e => S.current ? .querySelectorAll(".pj-shot")[e] ? .getBoundingClientRect(), []),
            A = (e, t) => {
                P(t.getBoundingClientRect()), R(e)
            };
        (0, x.useBend)(M), (0, a.useEffect)(() => {
            let e = M.current,
                t = S.current;
            if (!e || !t) return;
            let l = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                a = window.matchMedia("(max-width: 1024px)"),
                r = 0,
                n = 0,
                s = 0,
                i = 0,
                o = 0,
                c = null,
                d = !1,
                h = 0,
                f = 0,
                u = [],
                m = () => {
                    u = [...t.querySelectorAll(".pj-shot")].map(e => (e.style.transform = "", {
                        el: e,
                        left: e.offsetLeft + (e.parentElement === t ? 0 : e.parentElement.offsetLeft),
                        at: n
                    })), r = a.matches ? Math.max(0, e.scrollHeight - e.clientHeight) : Math.max(0, t.scrollWidth - e.clientWidth), s = Math.min(s, r), n = Math.min(n, r), p()
                },
                p = () => {
                    if (a.matches) {
                        t.style.transform = "", N(r ? n / r : 0);
                        return
                    }
                    t.style.transform = `translate3d(${-n}px, 0, 0)`, N(r ? n / r : 0)
                },
                x = t => {
                    let c = Math.min(.1, (t - o) / 1e3);
                    o = t, h && (s = Math.max(0, Math.min(r, s + h * c)), (12 > Math.abs(h *= Math.exp(-c / .325)) || s <= 0 || s >= r) && (h = 0)), n += (s - n) * (1 - Math.exp(-(d ? 22 : j.EASE) * c)), .3 > Math.abs(s - n) && (n = s), p();
                    let f = (t => {
                        if (!(!a.matches && !l)) return !1;
                        let r = e.clientWidth,
                            s = .06 * r,
                            i = !1;
                        for (let e of u) {
                            let l = 3.2 + 2.3 * Math.min(1, Math.max(0, (e.left - n) / r));
                            e.at += (n - e.at) * (1 - Math.exp(-l * t)), 1 > Math.abs(n - e.at) ? e.at = n : i = !0;
                            let a = s * Math.tanh((n - e.at) * .2 / s);
                            e.el.style.transform = Math.abs(a) >= .1 ? `translate3d(${a.toFixed(1)}px, 0, 0)` : ""
                        }
                        return i
                    })(c);
                    i = n !== s || h || f ? requestAnimationFrame(x) : 0
                },
                v = t => {
                    if (a.matches) {
                        s = Math.max(0, Math.min(r, e.scrollTop + t)), e.scrollTo({
                            top: s,
                            behavior: l ? "auto" : "smooth"
                        });
                        return
                    }
                    if (s = Math.max(0, Math.min(r, s + t)), l)
                        for (let e of (n = s, p(), u)) e.at = n;
                    else i || (o = performance.now(), i = requestAnimationFrame(x))
                };
            k.current = l => {
                let n = t.querySelectorAll(".pj-shot")[l];
                if (!n) return;
                let i = a.matches ? n.offsetTop + n.offsetHeight / 2 - e.clientHeight / 2 : n.offsetLeft + n.offsetWidth / 2 - e.clientWidth / 2;
                v(Math.max(0, Math.min(r, i)) - (a.matches ? e.scrollTop : s))
            };
            let b = e => {
                    if (document.querySelector(".vhs-about, .pj-zoom") || a.matches) return;
                    e.preventDefault(), d = !1;
                    let t = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
                    v((1 === e.deltaMode ? 16 * t : t) * 1.2)
                },
                g = e => {
                    document.querySelector(".vhs-about, .pj-zoom") || e.button > 0 || (h = 0, a.matches && "mouse" !== e.pointerType || (d = (c = {
                        x: e.clientX,
                        y: e.clientY,
                        t: performance.now(),
                        v: 0,
                        touch: "mouse" !== e.pointerType
                    }).touch, f = 0))
                },
                w = t => {
                    if (!c) return;
                    let l = c.x - t.clientX,
                        r = c.y - t.clientY,
                        n = Math.abs(l) >= Math.abs(r) ? l : r;
                    a.matches ? e.scrollTop += r : v(n), f += Math.abs(l) + Math.abs(r);
                    let s = performance.now(),
                        i = n / Math.max(8, s - c.t) * 1e3;
                    c.v = .6 * c.v + .4 * i, c.x = t.clientX, c.y = t.clientY, c.t = s
                },
                y = e => {
                    f <= 6 || (e.preventDefault(), e.stopPropagation())
                },
                E = () => {
                    c ? .touch && !a.matches && performance.now() - c.t < 80 && (h = c.v, i || (o = performance.now(), i = requestAnimationFrame(x))), c = null
                },
                L = t => {
                    if (document.querySelector(".vhs-about, .pj-zoom")) return;
                    let l = (a.matches ? e.clientHeight : e.clientWidth) * .8,
                        n = {
                            ArrowRight: 120,
                            ArrowDown: 120,
                            ArrowLeft: -120,
                            ArrowUp: -120,
                            PageDown: l,
                            " ": l,
                            PageUp: -l,
                            Home: -1 / 0,
                            End: 1 / 0
                        };
                    t.key in n && (t.preventDefault(), v(n[t.key] === 1 / 0 ? r : n[t.key] === -1 / 0 ? -r : n[t.key]))
                },
                R = () => {
                    n = s = h = 0, e.scrollTop = 0, m()
                };
            a.addEventListener("change", R), m();
            let T = new ResizeObserver(m);
            T.observe(e), T.observe(t);
            let C = () => {
                a.matches && (n = s = e.scrollTop, p())
            };
            return e.addEventListener("scroll", C, {
                passive: !0
            }), window.addEventListener("wheel", b, {
                passive: !1
            }), e.addEventListener("pointerdown", g), e.addEventListener("click", y, !0), window.addEventListener("pointermove", w), window.addEventListener("pointerup", E), window.addEventListener("pointercancel", E), window.addEventListener("keydown", L), () => {
                k.current = null, T.disconnect(), a.removeEventListener("change", R), e.removeEventListener("scroll", C), window.removeEventListener("wheel", b), e.removeEventListener("pointerdown", g), e.removeEventListener("click", y, !0), window.removeEventListener("pointermove", w), window.removeEventListener("pointerup", E), window.removeEventListener("pointercancel", E), window.removeEventListener("keydown", L), cancelAnimationFrame(i)
            }
        }, []);
        let F = (0, v.useScreenReady)();
        (0, a.useEffect)(() => {
            let e = S.current;
            if (!e || !F) return;
            let t = new IntersectionObserver(e => e.forEach(e => {
                let t = e.target;
                e.isIntersecting ? t.play().catch(() => {}) : t.pause()
            }), {
                threshold: .2
            });
            return e.querySelectorAll("video").forEach(e => t.observe(e)), () => t.disconnect()
        }, [m, F]);
        let q = [];
        m.forEach((e, t) => {
            t > 0 && m[t - 1].pair && q.at(-1) ? .length === 1 ? q.at(-1).push(t) : q.push([t])
        });
        let W = e => {
            let l = m[e];
            return (0, t.jsx)("figure", {
                className: "pj-shot",
                style: {
                    aspectRatio: `${l.width} / ${l.height}`
                },
                "data-caption": "[Focus]",
                role: "button",
                tabIndex: 0,
                "aria-label": `Zoom into ${l.alt||`picture ${e+1}`}`,
                onClick: t => A(e, t.currentTarget),
                onKeyDown: t => {
                    "Enter" === t.key && A(e, t.currentTarget)
                },
                children: (0, t.jsx)(w, {
                    m: l,
                    first: 0 === e
                })
            }, `${l.src}-${e}`)
        };
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)("div", {
                ref: M,
                className: "pj-view",
                children: (0, t.jsxs)("div", {
                    ref: S,
                    className: "pj-track",
                    children: [(0, t.jsxs)("section", {
                        className: "pj-intro",
                        "aria-label": e,
                        children: [(0, t.jsxs)("dl", {
                            className: "pj-meta",
                            children: [(0, t.jsx)(g, {
                                label: "Client",
                                items: [l],
                                i: 1
                            }), s && (0, t.jsx)(g, {
                                label: "Year",
                                items: [String(s)],
                                i: 1
                            }), o.length > 0 && (0, t.jsx)(g, {
                                label: "Services",
                                items: o,
                                i: 2
                            }), c.length > 0 && (0, t.jsx)(g, {
                                label: "Results",
                                items: c,
                                i: 2
                            })]
                        }), (0, t.jsxs)("div", {
                            className: "pj-story",
                            children: [d && (0, t.jsx)("h1", {
                                className: "pj-headline",
                                children: (0, t.jsx)(r.Reveal, {
                                    i: 3,
                                    children: d
                                })
                            }), h && (0, t.jsx)("p", {
                                className: "pj-summary",
                                children: (0, t.jsx)(r.Reveal, {
                                    i: 4,
                                    children: h
                                })
                            }), f && (0, t.jsx)(r.Reveal, {
                                i: 5,
                                children: (0, t.jsxs)("a", {
                                    className: "pj-live",
                                    href: f,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    children: ["Visit Live Site[", (0, t.jsx)("span", {
                                        className: "pj-live-arrow",
                                        "aria-hidden": !0,
                                        children: "←"
                                    }), "]"]
                                })
                            })]
                        })]
                    }), q.map(e => (0, t.jsxs)(a.Fragment, {
                        children: [p.filter(t => t.at === e[0]).map(e => (0, t.jsx)(b, {
                            section: e,
                            low: p.indexOf(e) % 2 == 1
                        }, e.key)), e.length > 1 ? (0, t.jsx)("div", {
                            className: "pj-pair",
                            children: e.map(W)
                        }) : W(e[0])]
                    }, `run-${e[0]}`)), p.filter(e => e.at >= m.length).map(e => (0, t.jsx)(b, {
                        section: e,
                        low: p.indexOf(e) % 2 == 1
                    }, e.key)), y && (0, t.jsx)(u, {
                        next: y
                    })]
                })
            }), null !== L && (0, t.jsx)(i.default, {
                slides: m,
                index: L,
                onIndex: T,
                onClose: () => R(null),
                from: C,
                toRect: $
            }), (0, t.jsx)(n.default, {
                idle: null === L && E < .995 ? "[Scroll to discover]" : null
            }), (0, t.jsxs)("div", {
                className: "pj-progress",
                "aria-hidden": !0,
                style: {
                    "--loaded": E
                },
                children: [(0, t.jsx)("i", {
                    className: "vhs-loader-ticks"
                }), (0, t.jsx)("i", {
                    className: "vhs-loader-dashes"
                })]
            })]
        })
    }], 645645)
}, 466552, e => {
    e.v(t => Promise.all(["static/immutable/chunks/0zc-na89g39-k.js", "static/immutable/chunks/37n3r0zuw47_4.js", "static/immutable/chunks/0qxtffwpvg0u2.js"].map(t => e.l(t))).then(() => t(79313)))
}, 599109, e => {
    "use strict";
    let t = null;
    e.s(["drawWear", 0, function(e, l, a, r = 20260) {
        let n = r,
            s = () => (n = 16807 * n % 0x7fffffff) / 0x7fffffff,
            i = e => `rgba(238,232,218,${e})`;
        e.fillStyle = "rgba(190,160,110,0.07)", e.fillRect(0, 0, l, a);
        let o = e.createRadialGradient(l / 2, a / 2, .3 * a, l / 2, a / 2, .75 * a);
        o.addColorStop(0, "rgba(0,0,0,0)"), o.addColorStop(1, "rgba(10,6,2,0.35)"), e.fillStyle = o, e.fillRect(0, 0, l, a);
        for (let t = 0; t < 7; t++) {
            let t = s() * l,
                r = s() * a,
                n = 60 + 180 * s(),
                i = e.createRadialGradient(t, r, 0, t, r, n);
            i.addColorStop(0, `rgba(40,28,14,${.06+.08*s()})`), i.addColorStop(1, "rgba(40,28,14,0)"), e.fillStyle = i, e.fillRect(t - n, r - n, 2 * n, 2 * n)
        }
        let c = (t, l, a) => {
            for (let r = 0; r < t; r += 2 + 5 * s()) {
                .12 > s() && (r += 60 * s());
                let t = s() ** 2.2 * 26,
                    [n, o] = l(r, t),
                    c = 1.5 + s() * (t < 6 ? 7 : 3.5),
                    d = .8 + 2.2 * s();
                e.fillStyle = i(t < 5 ? .55 + .4 * s() : .2 + .35 * s()), e.beginPath(), e.ellipse(n, o, a ? d : c, a ? c : d, (s() - .5) * .6, 0, 2 * Math.PI), e.fill()
            }
        };
        for (let [t, r, n, o] of (c(l, (e, t) => [e, 4 + t], !1), c(l, (e, t) => [e, a - 4 - t], !1), c(a, (e, t) => [4 + t, e], !0), c(a, (e, t) => [l - 4 - t, e], !0), e.strokeStyle = i(.55), e.lineWidth = 2.5, e.setLineDash([]), e.beginPath(), [
                [7, 7, l - 7, 7],
                [l - 7, 7, l - 7, a - 7],
                [l - 7, a - 7, 7, a - 7],
                [7, a - 7, 7, 7]
            ]))
            for (let l = 0; l < 40; l++) {
                if (.35 > s()) continue;
                let a = l / 40,
                    i = (l + .4 + .6 * s()) / 40,
                    c = () => (s() - .5) * 3;
                e.moveTo(t + (n - t) * a + c(), r + (o - r) * a + c()), e.lineTo(t + (n - t) * i + c(), r + (o - r) * i + c())
            }
        for (let [t, r] of (e.stroke(), [
                [0, 0],
                [l, 0],
                [0, a],
                [l, a]
            ])) {
            let l = 40 + 50 * s(),
                a = e.createRadialGradient(t, r, 0, t, r, l);
            a.addColorStop(0, i(.85)), a.addColorStop(.45, i(.35)), a.addColorStop(1, i(0)), e.fillStyle = a, e.fillRect(t - l, r - l, 2 * l, 2 * l);
            for (let a = 0; a < 40; a++) {
                let a = s() * Math.PI * 2,
                    n = s() ** 1.5 * l * 1.3;
                e.fillStyle = i(.3 + .5 * s()), e.fillRect(t + Math.cos(a) * n, r + Math.sin(a) * n, 1 + 4 * s(), 1 + 3 * s())
            }
        }
        for (let t = 0; t < 4; t++) {
            let t = .5 > s(),
                r = t ? 0 : l * (.3 + .7 * s()),
                n = t ? a * s() : 0,
                o = t ? (s() - .5) * .9 : Math.PI / 2 + (s() - .5) * .9,
                c = 90 + 260 * s(),
                d = r + Math.cos(o) * c,
                h = n + Math.sin(o) * c,
                f = (r + d) / 2 + (s() - .5) * 30,
                u = (n + h) / 2 + (s() - .5) * 30;
            e.lineCap = "round", e.strokeStyle = "rgba(0,0,0,0.28)", e.lineWidth = 2.2, e.beginPath(), e.moveTo(r + 1.5, n + 1.5), e.quadraticCurveTo(f + 1.5, u + 1.5, d + 1.5, h + 1.5), e.stroke(), e.strokeStyle = i(.32), e.lineWidth = 1.4, e.beginPath(), e.moveTo(r, n), e.quadraticCurveTo(f, u, d, h), e.stroke()
        }
        for (let t = 0; t < 38; t++) {
            let t = s() * l,
                r = s() * a,
                n = s() * Math.PI,
                i = 20 + 180 * s();
            e.strokeStyle = `rgba(255,252,244,${.08+.22*s()})`, e.lineWidth = .5 + s(), e.beginPath(), e.moveTo(t, r), e.quadraticCurveTo(t + Math.cos(n) * i * .5 + (s() - .5) * 16, r + Math.sin(n) * i * .5 + (s() - .5) * 16, t + Math.cos(n) * i, r + Math.sin(n) * i), e.stroke()
        } {
            let t = .66 * l,
                r = .19 * a;
            e.save(), e.translate(t, r), e.rotate(-.05), e.beginPath(), e.moveTo(0, 0);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 * t, (s() - .5) * 4);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 + (s() - .5) * 6, 64 * t);
            for (let t = 1; t >= 0; t -= .1) e.lineTo(120 * t, 64 + (s() - .5) * 8);
            for (let t = 1; t >= 0; t -= .1) e.lineTo((s() - .5) * 4, 64 * t);
            e.closePath(), e.fillStyle = "rgba(235,225,200,0.13)", e.fill();
            for (let t = 0; t < 12; t++) e.fillStyle = i(.35 + .4 * s()), e.fillRect(120 * s(), 64 * s(), 3 + 22 * s(), 2 + 5 * s());
            e.restore()
        }
        let d = e.createPattern(function() {
            if (t) return t;
            (t = document.createElement("canvas")).width = t.height = 256;
            let e = t.getContext("2d"),
                l = 9001,
                a = () => (l = 16807 * l % 0x7fffffff) / 0x7fffffff;
            for (let t = 0; t < 520; t++) {
                let t = 255 * (a() > .5);
                e.fillStyle = `rgba(${t},${t},${t},${.02+.06*a()})`, e.fillRect(256 * a(), 256 * a(), 1 + 1.6 * a(), 1 + 1.6 * a())
            }
            return t
        }(), "repeat");
        d && (e.save(), e.translate(-Math.floor(256 * s()), -Math.floor(256 * s())), e.fillStyle = d, e.fillRect(0, 0, l + 256, a + 256), e.restore())
    }])
}]);