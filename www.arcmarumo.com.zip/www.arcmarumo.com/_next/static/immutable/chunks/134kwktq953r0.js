(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 957215, e => {
    "use strict";
    var t = e.i(247167),
        n = e.i(271645),
        r = e.i(618566);

    function s() {
        return false
    }

    function i(e) {
        return RegExp(`/${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?=[/?#]|$)`)
    }

    function a(e) {
        return e.startsWith("http://") || e.startsWith("https://") || e.startsWith("/") ? e : `/${e}`
    }

    function o(e) {
        (0, n.useEffect)(() => {
            var t;
            e.beforeSend && (null == (t = window.si) || t.call(window, "beforeSend", e.beforeSend))
        }, [e.beforeSend]);
        let r = (0, n.useRef)(null);
        return (0, n.useEffect)(() => {
            if (!r.current) {
                let n = function(e = {}, t) {
                    var n;
                    if (!("u" > typeof window) || null === e.route) return null;
                    window.si || (window.si = function(...e) {
                        window.siq = window.siq || [], window.siq.push(e)
                    });
                    let {
                        beforeSend: r,
                        src: i,
                        dataset: o
                    } = function(e, t) {
                        var n, r;
                        let i = e;
                        if (t) try {
                            i = { ...null == (n = JSON.parse(t)) ? void 0 : n.speedInsights,
                                ...e
                            }
                        } catch {}
                        let o = {
                            sdkn: "@vercel/speed-insights" + (i.framework ? `/${i.framework}` : ""),
                            sdkv: "2.0.0"
                        };
                        return i.sampleRate && (o.sampleRate = i.sampleRate.toString()), i.route && (o.route = i.route), s() && !1 === i.debug && (o.debug = "false"), i.dsn && (o.dsn = i.dsn), i.endpoint ? o.endpoint = a(i.endpoint) : i.basePath && (o.endpoint = a(`${i.basePath}/speed-insights/vitals`)), {
                            src: (r = i).scriptSrc ? a(r.scriptSrc) : s() ? "https://va.vercel-scripts.com/v1/speed-insights/script.debug.js" : r.dsn ? "https://va.vercel-scripts.com/v1/speed-insights/script.js" : r.basePath ? a(`${r.basePath}/speed-insights/script.js`) : "/_vercel/speed-insights/script.js",
                            beforeSend: i.beforeSend,
                            dataset: o
                        }
                    }(e, t);
                    if (document.head.querySelector(`script[src*="${i}"]`)) return null;
                    r && (null == (n = window.si) || n.call(window, "beforeSend", r));
                    let c = document.createElement("script");
                    for (let [e, t] of (c.src = i, c.defer = !0, Object.entries(o))) c.dataset[e] = t;
                    return c.onerror = () => {
                        console.log(`[Vercel Speed Insights] Failed to load script from ${i}. Please check if any content blockers are enabled and try again.`)
                    }, document.head.appendChild(c), {
                        setRoute: e => {
                            c.dataset.route = e ? ? void 0
                        }
                    }
                }({
                    framework: e.framework ? ? "react",
                    basePath: e.basePath ? ? function() {
                        if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.REACT_APP_VERCEL_OBSERVABILITY_BASEPATH
                    }(),
                    ...e
                }, e.configString ? ? function() {
                    if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.REACT_APP_VERCEL_OBSERVABILITY_CLIENT_CONFIG
                }());
                n && (r.current = n.setRoute)
            }
        }, [e]), (0, n.useEffect)(() => {
            r.current && e.route && r.current(e.route)
        }, [e.route]), null
    }

    function c(e) {
        let s = (() => {
            let e = (0, r.useParams)(),
                t = (0, r.useSearchParams)() || new URLSearchParams,
                n = (0, r.usePathname)();
            if (!e) return null;
            let s = Object.keys(e).length ? e : Object.fromEntries(t.entries());
            if (!n || !s) return n;
            let a = n;
            try {
                let e = Object.entries(s);
                for (let [t, n] of e)
                    if (!Array.isArray(n)) {
                        let e = i(n);
                        e.test(a) && (a = a.replace(e, `/[${t}]`))
                    }
                for (let [t, n] of e)
                    if (Array.isArray(n)) {
                        let e = i(n.join("/"));
                        e.test(a) && (a = a.replace(e, `/[...${t}]`))
                    }
                return a
            } catch {
                return n
            }
        })();
        return n.default.createElement(o, {
            route: s,
            ...e,
            framework: "next",
            basePath: function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.NEXT_PUBLIC_VERCEL_OBSERVABILITY_BASEPATH
            }(),
            configString: function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return '{"analytics":{"scriptSrc":"aafe13344bef70fc/script.js","viewEndpoint":"aafe13344bef70fc/view","eventEndpoint":"aafe13344bef70fc/event","sessionEndpoint":"aafe13344bef70fc/session"},"speedInsights":{"scriptSrc":"5d18c82ce29be22e/script.js","endpoint":"5d18c82ce29be22e/vitals"}}'
            }()
        })
    }
    e.s(["SpeedInsights", 0, function(e) {
        return n.default.createElement(n.Suspense, {
            fallback: null
        }, n.default.createElement(c, { ...e
        }))
    }])
}, 255343, function(e) {
    e.n(e.i(957215))
}]);