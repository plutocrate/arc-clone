(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 119789, e => {
    "use strict";
    var t = e.i(190072),
        r = e.i(271645),
        a = e.i(94800),
        n = e.i(306257);
    e.s(["BENT_CANVAS", 0, {
        antialias: !1,
        alpha: !0
    }, "default", 0, function({
        paused: e = !1
    }) {
        let o = (0, r.useRef)(!1),
            {
                target: i,
                screen: l,
                camera: s,
                material: u
            } = (0, r.useMemo)(() => {
                let e = new t.WebGLRenderTarget(1, 1, {
                        type: t.HalfFloatType,
                        samples: 4
                    }),
                    r = new t.ShaderMaterial({
                        uniforms: {
                            map: {
                                value: e.texture
                            },
                            k: {
                                value: n.K
                            },
                            fade: {
                                value: .12
                            }
                        },
                        vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = vec4(position.xy, 0.0, 1.0);
        }`,
                        fragmentShader: `
        uniform sampler2D map;
        uniform float k;
        uniform float fade;
        varying vec2 vUv;
        void main() {
          vec2 p = vUv * 2.0 - 1.0;
          vec2 st = vec2(p.x * (1.0 + k * p.y * p.y), p.y * (1.0 + k * p.x * p.x)) * 0.5 + 0.5;
          // Past the scene's edge (the corners fall away): nothing.
          if (st.x < 0.0 || st.x > 1.0 || st.y < 0.0 || st.y > 1.0) {
            gl_FragColor = vec4(0.0);
            return;
          }
          // A vignette: the picture fades out toward where the bend runs
          // out of it, so tapes near the corners melt into the screen
          // instead of being cut off along the curve.
          vec2 edge = smoothstep(vec2(0.0), vec2(fade), st) * smoothstep(vec2(0.0), vec2(fade), 1.0 - st);
          gl_FragColor = texture2D(map, st) * (edge.x * edge.y);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
                        depthTest: !1,
                        depthWrite: !1,
                        blending: t.NoBlending
                    }),
                    a = new t.Mesh(new t.PlaneGeometry(2, 2), r);
                a.frustumCulled = !1;
                let o = new t.Scene;
                return o.add(a), {
                    target: e,
                    screen: o,
                    camera: new t.OrthographicCamera(-1, 1, 1, -1, 0, 1),
                    material: r
                }
            }, []);
        (0, r.useEffect)(() => () => {
            i.dispose(), u.dispose(), l.traverse(e => e.geometry ? .dispose())
        }, [i, u, l]);
        let c = (0, r.useMemo)(() => new t.Vector2, []);
        return (0, a.useFrame)(({
            gl: t,
            scene: r,
            camera: a
        }) => {
            if (!e) {
                if (!o.current) try {
                    t.getDrawingBufferSize(c);
                    let e = Math.min(1, Math.sqrt(3686400 / Math.max(1, c.x * c.y))),
                        n = Math.max(1, Math.round(c.x * e)),
                        o = Math.max(1, Math.round(c.y * e));
                    (i.width !== n || i.height !== o) && i.setSize(n, o), t.setRenderTarget(i), t.render(r, a), t.setRenderTarget(null), t.render(l, s);
                    return
                } catch (e) {
                    o.current = !0, i.dispose(), console.warn("[bend] off, drawing the scene straight:", e)
                }
                t.setRenderTarget(null), t.render(r, a)
            }
        }, 1), null
    }])
}, 599109, e => {
    "use strict";
    let t = null;
    e.s(["drawWear", 0, function(e, r, a, n = 20260) {
        let o = n,
            i = () => (o = 16807 * o % 0x7fffffff) / 0x7fffffff,
            l = e => `rgba(238,232,218,${e})`;
        e.fillStyle = "rgba(190,160,110,0.07)", e.fillRect(0, 0, r, a);
        let s = e.createRadialGradient(r / 2, a / 2, .3 * a, r / 2, a / 2, .75 * a);
        s.addColorStop(0, "rgba(0,0,0,0)"), s.addColorStop(1, "rgba(10,6,2,0.35)"), e.fillStyle = s, e.fillRect(0, 0, r, a);
        for (let t = 0; t < 7; t++) {
            let t = i() * r,
                n = i() * a,
                o = 60 + 180 * i(),
                l = e.createRadialGradient(t, n, 0, t, n, o);
            l.addColorStop(0, `rgba(40,28,14,${.06+.08*i()})`), l.addColorStop(1, "rgba(40,28,14,0)"), e.fillStyle = l, e.fillRect(t - o, n - o, 2 * o, 2 * o)
        }
        let u = (t, r, a) => {
            for (let n = 0; n < t; n += 2 + 5 * i()) {
                .12 > i() && (n += 60 * i());
                let t = i() ** 2.2 * 26,
                    [o, s] = r(n, t),
                    u = 1.5 + i() * (t < 6 ? 7 : 3.5),
                    c = .8 + 2.2 * i();
                e.fillStyle = l(t < 5 ? .55 + .4 * i() : .2 + .35 * i()), e.beginPath(), e.ellipse(o, s, a ? c : u, a ? u : c, (i() - .5) * .6, 0, 2 * Math.PI), e.fill()
            }
        };
        for (let [t, n, o, s] of (u(r, (e, t) => [e, 4 + t], !1), u(r, (e, t) => [e, a - 4 - t], !1), u(a, (e, t) => [4 + t, e], !0), u(a, (e, t) => [r - 4 - t, e], !0), e.strokeStyle = l(.55), e.lineWidth = 2.5, e.setLineDash([]), e.beginPath(), [
                [7, 7, r - 7, 7],
                [r - 7, 7, r - 7, a - 7],
                [r - 7, a - 7, 7, a - 7],
                [7, a - 7, 7, 7]
            ]))
            for (let r = 0; r < 40; r++) {
                if (.35 > i()) continue;
                let a = r / 40,
                    l = (r + .4 + .6 * i()) / 40,
                    u = () => (i() - .5) * 3;
                e.moveTo(t + (o - t) * a + u(), n + (s - n) * a + u()), e.lineTo(t + (o - t) * l + u(), n + (s - n) * l + u())
            }
        for (let [t, n] of (e.stroke(), [
                [0, 0],
                [r, 0],
                [0, a],
                [r, a]
            ])) {
            let r = 40 + 50 * i(),
                a = e.createRadialGradient(t, n, 0, t, n, r);
            a.addColorStop(0, l(.85)), a.addColorStop(.45, l(.35)), a.addColorStop(1, l(0)), e.fillStyle = a, e.fillRect(t - r, n - r, 2 * r, 2 * r);
            for (let a = 0; a < 40; a++) {
                let a = i() * Math.PI * 2,
                    o = i() ** 1.5 * r * 1.3;
                e.fillStyle = l(.3 + .5 * i()), e.fillRect(t + Math.cos(a) * o, n + Math.sin(a) * o, 1 + 4 * i(), 1 + 3 * i())
            }
        }
        for (let t = 0; t < 4; t++) {
            let t = .5 > i(),
                n = t ? 0 : r * (.3 + .7 * i()),
                o = t ? a * i() : 0,
                s = t ? (i() - .5) * .9 : Math.PI / 2 + (i() - .5) * .9,
                u = 90 + 260 * i(),
                c = n + Math.cos(s) * u,
                d = o + Math.sin(s) * u,
                f = (n + c) / 2 + (i() - .5) * 30,
                h = (o + d) / 2 + (i() - .5) * 30;
            e.lineCap = "round", e.strokeStyle = "rgba(0,0,0,0.28)", e.lineWidth = 2.2, e.beginPath(), e.moveTo(n + 1.5, o + 1.5), e.quadraticCurveTo(f + 1.5, h + 1.5, c + 1.5, d + 1.5), e.stroke(), e.strokeStyle = l(.32), e.lineWidth = 1.4, e.beginPath(), e.moveTo(n, o), e.quadraticCurveTo(f, h, c, d), e.stroke()
        }
        for (let t = 0; t < 38; t++) {
            let t = i() * r,
                n = i() * a,
                o = i() * Math.PI,
                l = 20 + 180 * i();
            e.strokeStyle = `rgba(255,252,244,${.08+.22*i()})`, e.lineWidth = .5 + i(), e.beginPath(), e.moveTo(t, n), e.quadraticCurveTo(t + Math.cos(o) * l * .5 + (i() - .5) * 16, n + Math.sin(o) * l * .5 + (i() - .5) * 16, t + Math.cos(o) * l, n + Math.sin(o) * l), e.stroke()
        } {
            let t = .66 * r,
                n = .19 * a;
            e.save(), e.translate(t, n), e.rotate(-.05), e.beginPath(), e.moveTo(0, 0);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 * t, (i() - .5) * 4);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 + (i() - .5) * 6, 64 * t);
            for (let t = 1; t >= 0; t -= .1) e.lineTo(120 * t, 64 + (i() - .5) * 8);
            for (let t = 1; t >= 0; t -= .1) e.lineTo((i() - .5) * 4, 64 * t);
            e.closePath(), e.fillStyle = "rgba(235,225,200,0.13)", e.fill();
            for (let t = 0; t < 12; t++) e.fillStyle = l(.35 + .4 * i()), e.fillRect(120 * i(), 64 * i(), 3 + 22 * i(), 2 + 5 * i());
            e.restore()
        }
        let c = e.createPattern(function() {
            if (t) return t;
            (t = document.createElement("canvas")).width = t.height = 256;
            let e = t.getContext("2d"),
                r = 9001,
                a = () => (r = 16807 * r % 0x7fffffff) / 0x7fffffff;
            for (let t = 0; t < 520; t++) {
                let t = 255 * (a() > .5);
                e.fillStyle = `rgba(${t},${t},${t},${.02+.06*a()})`, e.fillRect(256 * a(), 256 * a(), 1 + 1.6 * a(), 1 + 1.6 * a())
            }
            return t
        }(), "repeat");
        c && (e.save(), e.translate(-Math.floor(256 * i()), -Math.floor(256 * i())), e.fillStyle = c, e.fillRect(0, 0, r + 256, a + 256), e.restore())
    }])
}, 864644, e => {
    "use strict";
    let t;
    var r = e.i(843476),
        a = e.i(119789),
        n = e.i(190072),
        o = e.i(271645),
        i = e.i(575056),
        l = e.i(94800),
        s = e.i(297017),
        u = e.i(848546),
        c = e.i(408155);
    let d = e => {
            let t = (0, c.createStore)(e),
                r = e => (function(e, t = e => e) {
                    let r = o.default.useSyncExternalStore(e.subscribe, o.default.useCallback(() => t(e.getState()), [e, t]), o.default.useCallback(() => t(e.getInitialState()), [e, t]));
                    return o.default.useDebugValue(r), r
                })(t, e);
            return Object.assign(r, t), r
        },
        f = 0,
        h = (t = e => (n.DefaultLoadingManager.onStart = (t, r, a) => {
            e({
                active: !0,
                item: t,
                loaded: r,
                total: a,
                progress: (r - f) / (a - f) * 100
            })
        }, n.DefaultLoadingManager.onLoad = () => {
            e({
                active: !1
            })
        }, n.DefaultLoadingManager.onError = t => e(e => ({
            errors: [...e.errors, t]
        })), n.DefaultLoadingManager.onProgress = (t, r, a) => {
            r === a && (f = a), e({
                active: !0,
                item: t,
                loaded: r,
                total: a,
                progress: (r - f) / (a - f) * 100 || 100
            })
        }, {
            errors: [],
            active: !1,
            progress: 0,
            item: "",
            loaded: 0,
            total: 0
        })) ? d(t) : d;
    var g = e.i(511226),
        m = e.i(662053),
        p = e.i(284442),
        v = e.i(929487),
        w = e.i(592563),
        M = e.i(599109);
    let y = new Map;

    function E(e) {
        let t = y.get(e);
        return t || (t = new Promise(t => {
            let r = new Image;
            r.onload = () => t(r), r.onerror = () => t(null), r.src = e
        }), y.set(e, t)), t
    }
    async function S() {
        let [, e, t, r] = await Promise.all([document.fonts ? .ready, E("/about/arc-mark.svg"), E("/about/vhs-logo.svg"), E("/about/mpa.svg")]);
        return {
            arc: e,
            vhs: t,
            mpa: r
        }
    }
    var b = e.i(662181);
    let x = (0, o.memo)(function({
            image: e,
            focus: t,
            design: a,
            index: i,
            quarter: s = !1,
            drive: c,
            priority: d = 0
        }) {
            let f = (0, o.useRef)(null),
                h = (0, o.useRef)(null),
                g = (0, u.useThree)(e => e.gl),
                m = (0, o.useMemo)(() => new n.MeshBasicMaterial({
                    map: function() {
                        if (L) return L;
                        let e = 256 / (b.CASE.w + 52),
                            t = Math.round((b.CASE.h + 52) * e),
                            r = document.createElement("canvas");
                        r.width = 256, r.height = t;
                        let a = r.getContext("2d"),
                            o = b.CASE.w * e,
                            i = b.CASE.h * e;
                        return a.shadowColor = "#000", a.shadowBlur = 26 * e * .9, a.shadowOffsetX = 512, a.fillStyle = "#000", a.fillRect((256 - o) / 2 - 512, (t - i) / 2, o, i), L = new n.CanvasTexture(r)
                    }(),
                    color: 0,
                    transparent: !0,
                    opacity: 0,
                    depthWrite: !1,
                    toneMapped: !1
                }), []);
            (0, o.useEffect)(() => () => m.dispose(), [m]);
            let [p, y] = (0, o.useState)(null), E = t ? .x, x = t ? .y;
            (0, o.useEffect)(() => {
                let t = null,
                    r = !0,
                    o = () => {};
                return S().then(l => {
                    r && (o = (0, v.whenIdle)(d, () => {
                        t = function({
                            image: e,
                            focus: t,
                            design: r,
                            index: a,
                            quarter: o,
                            marks: i
                        }) {
                            let l = T ? 512 : 1024,
                                s = Math.round(l * b.CASE.h / b.CASE.w),
                                [u, c] = o ? [s, l] : [l, s],
                                d = document.createElement("canvas");
                            d.width = u, d.height = c;
                            let f = d.getContext("2d");
                            r ? function(e, t, r, {
                                design: a,
                                index: n
                            }) {
                                e.save(), e.fillStyle = "#000", e.fillRect(0, 0, t, r);
                                let o = Math.min(t / a.width, r / a.height),
                                    i = a.width * o,
                                    l = a.height * o;
                                e.drawImage(a, (t - i) / 2, (r - l) / 2, i, l), e.restore(), (0, M.drawWear)(e, t, r, 4001 + 7919 * n)
                            }(f, u, c, {
                                design: r,
                                index: a
                            }) : function(e, t, r, {
                                image: a,
                                focus: n,
                                index: o,
                                marks: i
                            }) {
                                let l = (0, w.fontFamily)("--font-mono", "ui-monospace, monospace");
                                e.save(), e.fillStyle = "#101010", e.fillRect(0, 0, t, r);
                                let s = a.width / a.height,
                                    u = t / r,
                                    c = a.width,
                                    d = a.height;
                                s > u ? c = a.height * u : d = a.width / u;
                                let f = n ? .x ? ? .5,
                                    h = n ? .y ? ? .5,
                                    g = Math.min(Math.max(f * a.width - c / 2, 0), a.width - c),
                                    m = Math.min(Math.max(h * a.height - d / 2, 0), a.height - d);
                                e.filter = "saturate(0.88) contrast(1.08) brightness(0.9)", e.drawImage(a, g, m, c, d, 0, 0, t, r), e.filter = "none";
                                let p = e.createLinearGradient(0, 0, 0, .32 * r);
                                p.addColorStop(0, "rgba(8,8,8,0.78)"), p.addColorStop(1, "rgba(8,8,8,0)"), e.fillStyle = p, e.fillRect(0, 0, t, .32 * r);
                                let v = e.createLinearGradient(0, .45 * r, 0, r);
                                v.addColorStop(0, "rgba(8,8,8,0)"), v.addColorStop(1, "rgba(8,8,8,0.88)"), e.fillStyle = v, e.fillRect(0, .45 * r, t, .55 * r);
                                let y = Math.min(t, r) / 100;
                                e.textAlign = "center", e.textBaseline = "alphabetic", e.fillStyle = "#ece9e1";
                                let E = 5.2 * y;
                                if (i.arc) {
                                    let r = E * (i.arc.width / i.arc.height || 3.4);
                                    e.drawImage(i.arc, t / 2 - r / 2, 5 * y, r, E)
                                }
                                e.font = `500 ${3.6*y}px ${l}`, e.fillText("HOME VIDEO", t / 2, 5 * y + E + 5 * y);
                                let S = 5 * y,
                                    b = 6 * y;
                                if (i.vhs) {
                                    let t = b * (i.vhs.width / i.vhs.height || 1.9);
                                    e.drawImage(i.vhs, S, r - S - b, t, b)
                                }
                                let x = 9 * y;
                                if (i.mpa) {
                                    let a = x * (i.mpa.width / i.mpa.height || 1.4);
                                    e.drawImage(i.mpa, t - S - a, r - S - x, a, x)
                                }
                                e.restore(), (0, M.drawWear)(e, t, r, 4001 + 7919 * o)
                            }(f, u, c, {
                                image: e,
                                focus: t,
                                index: a,
                                marks: i
                            });
                            let h = document.createElement("canvas");
                            h.width = l, h.height = s;
                            let g = h.getContext("2d");
                            o && g.setTransform(0, 1, -1, 0, l, 0), g.drawImage(d, 0, 0);
                            let m = new n.CanvasTexture(h);
                            return m.colorSpace = n.SRGBColorSpace, m.anisotropy = 8, m
                        }({
                            image: e.image,
                            focus: void 0 === E || void 0 === x ? void 0 : {
                                x: E,
                                y: x
                            },
                            design: a,
                            index: i,
                            quarter: s,
                            marks: l
                        }), g.initTexture(t), y(t)
                    }))
                }), () => {
                    r = !1, o(), t ? .dispose()
                }
            }, [e, E, x, a, i, s, d, g]);
            let P = (0, o.useMemo)(() => {
                    let e = {
                            roughness: .62,
                            metalness: 0
                        },
                        t = {
                            cover: new n.MeshStandardMaterial(p ? { ...e,
                                map: p,
                                roughness: .48
                            } : { ...e,
                                color: "#1c1c1c"
                            }),
                            back: new n.MeshStandardMaterial({ ...e,
                                map: function() {
                                    if (R) return R;
                                    let e = document.createElement("canvas");
                                    e.width = 700, e.height = Math.round(700 * b.CASE.h / b.CASE.w);
                                    let t = e.getContext("2d");
                                    return t.fillStyle = "#121212", t.fillRect(0, 0, e.width, e.height), (0, M.drawWear)(t, e.width, e.height, 777), (R = new n.CanvasTexture(e)).colorSpace = n.SRGBColorSpace, R
                                }()
                            }),
                            edge: new n.MeshStandardMaterial({ ...e,
                                color: "#161616",
                                roughness: .8
                            })
                        };
                    for (let e of Object.values(t)) e.userData.base = e.color.clone();
                    return t
                }, [p]),
                j = (0, o.useMemo)(() => (function(e) {
                    let {
                        w: t,
                        h: r,
                        t: a,
                        wall: o
                    } = b.CASE, i = e => {
                        let a = new n.BoxGeometry(t, r, o);
                        return a.translate(0, 0, e), a
                    }, l = a - 2 * o, s = e => {
                        let t = new n.BoxGeometry(o, r, l);
                        return t.translate(e, 0, 0), t
                    }, u = e => {
                        let r = new n.BoxGeometry(t - 2 * o, o, l);
                        return r.translate(0, e, 0), r
                    }, c = e ? [s(-t / 2 + o / 2), u(-r / 2 + o / 2), u(r / 2 - o / 2)] : [s(-t / 2 + o / 2), s(t / 2 - o / 2), u(-r / 2 + o / 2)], d = function(e) {
                        let t = e.map(e => e.toNonIndexed()),
                            r = t.reduce((e, t) => e + t.attributes.position.count, 0),
                            a = new n.BufferGeometry;
                        for (let e of ["position", "normal", "uv"]) {
                            let o = t[0].attributes[e].itemSize,
                                i = new Float32Array(r * o),
                                l = 0;
                            for (let r of t) i.set(r.attributes[e].array, l), l += r.attributes[e].array.length;
                            a.setAttribute(e, new n.BufferAttribute(i, o))
                        }
                        return e.forEach(e => e.dispose()), t.forEach(e => e.dispose()), a
                    }([i(a / 2 - o / 2), i(-a / 2 + o / 2), ...c]), f = new n.PlaneGeometry(t, r);
                    f.translate(0, 0, a / 2 + .05);
                    let h = new n.PlaneGeometry(t, r);
                    return h.rotateY(Math.PI), h.translate(0, 0, -a / 2 - .05), {
                        front: f,
                        back: h,
                        card: d
                    }
                })(s), [s]);
            return (0, o.useEffect)(() => () => {
                P.cover.dispose(), P.back.dispose(), P.edge.dispose()
            }, [P]), (0, o.useEffect)(() => () => Object.values(j).forEach(e => e.dispose()), [j]), (0, l.useFrame)(() => {
                let e = f.current;
                if (!e) return;
                let t = -(C(c.out) * (s ? b.PEEK.quarter : b.PEEK.wide)) / 2;
                e.position.set(s ? t : 0, s ? 0 : t, 0);
                let r = .14 + .9800000000000001 * c.lit,
                    a = .08 + 1.3699999999999999 * c.lit;
                for (let t of e.children) {
                    let e = t.material,
                        n = e.userData.base;
                    n && (e.color.copy(n).multiplyScalar(r), e.envMapIntensity = a)
                }
                let n = h.current;
                if (n) {
                    let e = n.material;
                    e.opacity = .8 * c.lit, n.visible = e.opacity > .004
                }
            }), (0, r.jsxs)("group", {
                ref: f,
                children: [(0, r.jsx)("mesh", {
                    geometry: j.front,
                    material: P.cover,
                    renderOrder: -1
                }), (0, r.jsx)("mesh", {
                    geometry: j.back,
                    material: P.back,
                    renderOrder: -1
                }), (0, r.jsx)("mesh", {
                    geometry: j.card,
                    material: P.edge,
                    renderOrder: -1
                }), (0, r.jsx)("mesh", {
                    ref: h,
                    geometry: A ? ? = new n.PlaneGeometry(b.CASE.w + 52, b.CASE.h + 52),
                    material: m,
                    position: [s ? -8 : 0, s ? 0 : -8, -b.CASE.t / 2 - 4],
                    visible: !1
                })]
            })
        }),
        C = e => e < .5 ? 2 * e * e : 1 - (-2 * e + 2) ** 2 / 2,
        T = window.matchMedia("(max-width: 700px)").matches,
        R = null,
        A = null,
        L = null;
    var P = e.i(993327),
        j = e.i(318615),
        q = e.i(942295),
        k = e.i(306257),
        O = e.i(82396);
    let I = [],
        W = e => I[e] ? ? = {
            speed: 0,
            out: 0,
            lit: 0
        };

    function D({
        projects: e,
        intro: t,
        entered: a = !1,
        hidden: i,
        focusIndex: c,
        onActive: d,
        onOpen: f,
        onHover: h,
        onSettle: g,
        onLayout: v
    }) {
        let w = (0, u.useThree)(e => e.size),
            M = (0, u.useThree)(e => e.gl),
            y = (0, u.useThree)(e => e.invalidate),
            E = (0, s.useLoader)(m.SafeTextureLoader, e.flatMap(e => e.sleeve ? [] : [(0, P.sized)(e.cover.src)])),
            S = (0, o.useMemo)(() => {
                let t = 0;
                return e.map(e => e.sleeve ? U : E[t++])
            }, [e, E]),
            C = (0, o.useMemo)(() => e.flatMap(e => e.sleeve ? [(0, P.sized)(e.sleeve)] : []), [e]),
            T = (0, s.useLoader)(m.SafeImageLoader, C),
            R = (0, o.useMemo)(() => new Map(C.map((e, t) => [e, T[t]])), [C, T]),
            A = (0, o.useMemo)(() => Array.from({
                length: Math.ceil(Math.max(5, e.length) / e.length) * e.length
            }, (t, r) => {
                let a = r % e.length;
                return {
                    project: a,
                    progress: .12 + 37 * a % 100 / 100 * .7
                }
            }), [e]),
            L = (0, o.useMemo)(() => (0, P.measure)(w.width, w.height), [w.width, w.height]),
            j = (0, o.useMemo)(() => window.matchMedia("(prefers-reduced-motion: reduce)").matches, []),
            I = 20 * Math.tan(n.MathUtils.degToRad(7)) / w.height,
            B = (0, o.useRef)([]),
            G = (0, o.useRef)([]),
            V = (0, o.useRef)(null),
            _ = (0, o.useRef)({
                offset: 0,
                target: 0,
                vel: 0,
                prevOffset: 0,
                velocity: 0,
                dragging: !1,
                moved: 0,
                lastX: 0,
                lastT: 0,
                dragV: 0,
                downAt: 0,
                from: 0,
                active: -1,
                announced: -1,
                hovered: null,
                pointer: null,
                squash: 0,
                mouse: new n.Vector2,
                tilt: new n.Vector2,
                enter: +!!a,
                sink: 0,
                idle: !0
            });
        (0, o.useEffect)(() => {
            v({
                centerY: L.centerY,
                width: L.shownW,
                height: L.shownH
            })
        }, [L, v]);
        let [F] = (0, o.useState)(c), X = (0, o.useMemo)(() => Math.max(0, A.findIndex(e => e.project === F)), [A, F]), N = (0, o.useMemo)(() => A.map((e, t) => Math.min(Math.abs(t - X), A.length - Math.abs(t - X))), [A, X]);
        (0, o.useEffect)(() => {
            let e = _.current,
                t = e.active >= 0 ? e.active : X;
            e.offset = e.target = e.prevOffset = t * L.spacing, e.vel = 0, y()
        }, [L.spacing, X, y]), (0, o.useEffect)(() => {
            y()
        }, [t, i, y]);
        let Y = (0, o.useMemo)(() => {
            let e = L.spacing;
            return t => Math.round(t / e) * e
        }, [L.spacing]);
        return (0, o.useEffect)(() => {
            let e = _.current;
            if (e.active < 0 || A[e.active] ? .project === c) return;
            let t = A.length * L.spacing,
                r = 1 / 0;
            A.forEach((a, n) => {
                if (a.project !== c) return;
                let o = (0, P.mod)(n * L.spacing - e.offset + t / 2, t) - t / 2;
                Math.abs(o) < Math.abs(r) && (r = o)
            }), Number.isFinite(r) && (e.target = e.offset + r, i && (e.offset = e.prevOffset = e.target), y())
        }, [c, i, A, L.spacing, y]), (0, o.useEffect)(() => {
            let e = M.domElement.parentElement;
            if (!e) return;
            let t = document.documentElement,
                r = _.current,
                a = A.length * L.spacing,
                n = e => (0, P.mod)(e * L.spacing - r.offset + a / 2, a) - a / 2,
                o = (t, r) => {
                    let a = e.getBoundingClientRect(),
                        {
                            x: o,
                            y: i
                        } = (0, k.unbendPoint)(t, r, a),
                        l = o - a.left - a.width / 2,
                        s = i - a.top,
                        u = L.tapeW / b.TAPE.w,
                        c = L.quarter ? b.PEEK.quarter : b.PEEK.wide,
                        d = (L.quarter ? b.CASE.h : b.CASE.w) / 2,
                        f = (L.quarter ? b.CASE.w : b.CASE.h) / 2;
                    for (let e = 0; e < A.length; e++) {
                        let t = (0, P.onArc)(n(e), L.arcR);
                        if (Math.abs(t.angle) > 1.2) continue;
                        let r = l - t.x,
                            a = s - (L.centerY + t.drop),
                            o = Math.cos(t.angle),
                            i = Math.sin(t.angle),
                            h = r * o + a * i,
                            g = -r * i + a * o,
                            m = d * u,
                            p = (f + (Math.abs(n(e)) < .25 * L.spacing ? c / 2 : 0)) * u;
                        if (Math.abs(h) <= m && Math.abs(g) <= p) return e
                    }
                    return -1
                },
                l = e => {
                    let a = r.pointer,
                        n = !a || i || e instanceof Element && e.closest("a, button, [role='dialog']") ? -1 : o(a.x, a.y);
                    t.classList.toggle("tape-over", n >= 0);
                    let l = n >= 0 ? A[n].project : null;
                    l !== r.hovered && (r.hovered = l, h(l))
                },
                s = null;
            V.current = () => l(s);
            let u = () => {
                    r.dragging = !1, t.classList.remove("tape-dragging")
                },
                c = t => {
                    let a = e.getBoundingClientRect(),
                        n = (0, k.unbendPoint)(t.clientX, t.clientY, a);
                    if ("mouse" === t.pointerType && (r.mouse.set((n.x - a.left) / a.width * 2 - 1, -((n.y - a.top) / a.height * 2 - 1)), y()), r.dragging && "mouse" === t.pointerType && 0 === t.buttons && u(), r.pointer = "mouse" === t.pointerType ? {
                            x: t.clientX,
                            y: t.clientY
                        } : null, s = t.target, l(t.target), !r.dragging) return;
                    let o = performance.now(),
                        i = t.clientX - r.lastX,
                        c = Math.max(8, o - r.lastT) / 1e3;
                    r.offset -= i, r.target = r.offset, r.moved += Math.abs(i), r.dragV += (-i / c - r.dragV) * .35, r.lastX = t.clientX, r.lastT = o
                },
                d = e => {
                    if (!r.dragging) return;
                    u(), y();
                    let t = performance.now();
                    if (r.moved < 6 && t - r.downAt < 450) {
                        let t = o(e.clientX, e.clientY);
                        if (t >= 0) {
                            let e = n(t);
                            Math.abs(e) < .25 * L.spacing ? f(A[t].project) : r.target = r.offset + e;
                            return
                        }
                        r.target = Y(r.offset);
                        return
                    }
                    let a = (0, q.releaseSpeed)(r.dragV, t - r.lastT, P.FLING_MAX);
                    r.vel = a, r.target = (0, q.settleSlot)(r.offset + a / q.SETTLE, r.from, L.spacing)
                },
                g = 0,
                m = e => {
                    if (i) return;
                    e.preventDefault();
                    let t = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
                    g || (r.from = Y(r.target)), r.target += 1.4 * t, y(), window.clearTimeout(g), g = window.setTimeout(() => {
                        g = 0, r.target = (0, q.settleSlot)(r.target, r.from, L.spacing), y()
                    }, P.WHEEL_IDLE_MS)
                },
                p = e => {
                    if (!(i || e.target instanceof HTMLInputElement)) {
                        if ("ArrowRight" === e.key) r.target = Y(r.target) + L.spacing;
                        else {
                            if ("ArrowLeft" !== e.key) return;
                            r.target = Y(r.target) - L.spacing
                        }
                        y()
                    }
                },
                v = e => {
                    !(e.target instanceof Element && e.target.closest("a, button, [role='dialog']")) && (i || e.button > 0 || (r.moved = 0, r.lastX = e.clientX, r.lastT = performance.now(), r.downAt = r.lastT, r.from = Y(r.offset), r.dragV = 0, r.vel = 0, r.dragging = !0, r.target = r.offset, t.classList.add("tape-dragging"), y()))
                },
                w = () => {
                    r.pointer = null, l(null)
                };
            document.documentElement.addEventListener("pointerleave", w);
            let E = (0, O.onTilt)((e, t) => {
                r.mouse.set(e, t), y()
            });
            return window.addEventListener("pointerdown", v), window.addEventListener("pointermove", c), window.addEventListener("pointerup", d), window.addEventListener("pointercancel", d), window.addEventListener("wheel", m, {
                passive: !1
            }), window.addEventListener("keydown", p), () => {
                window.removeEventListener("pointerdown", v), window.removeEventListener("pointermove", c), window.removeEventListener("pointerup", d), window.removeEventListener("pointercancel", d), window.removeEventListener("wheel", m), window.removeEventListener("keydown", p), document.documentElement.removeEventListener("pointerleave", w), E(), V.current = null, window.clearTimeout(g), u(), t.classList.remove("tape-over"), null !== r.hovered && (r.hovered = null, h(null))
            }
        }, [M, L, A, Y, i, f, h, y]), (0, l.useFrame)((e, r) => {
            let a = _.current,
                o = a.idle ? 1 / 60 : Math.min(r, .1),
                l = a.idle ? 1 / 60 : Math.min(r, 3);
            if (t && (a.enter = j ? 1 : Math.min(1, a.enter + l / P.ENTER_SECONDS)), a.sink = n.MathUtils.damp(a.sink, +!!i, 4.5, l), !a.dragging) {
                let e = (0, q.springTo)(a.offset, a.vel, a.target, o);
                a.offset = e.x, a.vel = e.v, .05 > Math.abs(a.target - a.offset) && 1 > Math.abs(a.vel) && (a.offset = a.target, a.vel = 0)
            }
            let s = o > 0 ? (a.offset - a.prevOffset) / o : 0;
            a.offset !== a.prevOffset && a.pointer && V.current ? .(), a.prevOffset = a.offset, a.velocity = n.MathUtils.damp(a.velocity, s, 10, o), 1 > Math.abs(a.velocity) && a.offset === a.target && !a.dragging && (a.velocity = 0);
            let u = n.MathUtils.clamp(Math.abs(a.velocity) / 2600 + .25 * !!a.dragging, 0, 1);
            a.squash = n.MathUtils.damp(a.squash, j ? 0 : u, u > a.squash ? 8 : 3, o), a.squash < .002 && u < .002 && (a.squash = 0), a.tilt.x = n.MathUtils.damp(a.tilt.x, a.mouse.x, 2.4, o), a.tilt.y = n.MathUtils.damp(a.tilt.y, a.mouse.y, 2.4, o);
            let c = A.length * L.spacing,
                f = L.tapeW * I / b.TAPE.w,
                h = -(L.centerY - w.height / 2) * I,
                m = 0,
                p = !1,
                v = 1 / 0;
            A.forEach((e, t) => {
                let r = (0, P.mod)(t * L.spacing - a.offset + c / 2, c) - c / 2,
                    i = Math.abs(r);
                i < v && (v = i, m = t);
                let l = B.current[t],
                    s = G.current[t];
                if (!l || !s) return;
                let u = n.MathUtils.clamp(1 - i / L.spacing, 0, 1),
                    d = Math.min(3, Math.round(i / L.spacing)),
                    g = n.MathUtils.clamp(1.7 * a.enter - .22 * d, 0, 1),
                    M = 1 - (1 - g) ** 3,
                    y = r * (1 - .1 * a.squash),
                    E = (0, P.onArc)(y, L.arcR);
                l.visible = g > .001 && 1.2 > Math.abs(E.angle) && Math.abs(E.x) < w.width / 2 + L.shownW, l.position.set(E.x * I, h - E.drop * I - (1 - M) * w.height * .75 * I - a.sink * w.height * I, -Math.abs(y) * I * .45 * a.squash), l.scale.setScalar(f);
                let S = +!j;
                s.rotation.x = -(.9 * (1 - M)) - .42 * a.squash - .16 * a.tilt.y * u * S + .6 * a.sink, s.rotation.y = n.MathUtils.clamp(-(11e-5 * a.velocity), -.55, .55) + .22 * a.tilt.x * u * S, s.rotation.z = (L.quarter ? Math.PI / 2 : 0) - E.angle;
                let b = W(t),
                    x = n.MathUtils.clamp(1 - i / (.55 * L.spacing), 0, 1);
                b.lit = x * x * (3 - 2 * x) * M * (1 - a.sink);
                let C = i < .12 * L.spacing && !a.dragging && a.squash < .35 && M > .98 && a.sink < .05,
                    T = +!!C;
                b.out = j ? T : n.MathUtils.damp(b.out, T, C ? 2.2 : 4, o), .001 > Math.abs(b.out - T) ? b.out = T : p = !0
            });
            let M = A[m].project;
            m !== a.active && (a.active = m, d(M)), v < .5 && a.offset === a.target && !a.dragging && a.enter > .95 && a.sink < .05 && a.announced !== m && (a.announced = m, g(M));
            let y = a.dragging || a.offset !== a.target || 0 !== a.velocity || 0 !== a.squash || t && a.enter < 1 || Math.abs(a.sink - !!i) > .001 || Math.abs(a.tilt.x - a.mouse.x) > 5e-4 || Math.abs(a.tilt.y - a.mouse.y) > 5e-4 || p;
            a.idle = !y, y && e.invalidate()
        }), (0, r.jsx)(r.Fragment, {
            children: A.map((t, a) => {
                let n = e[t.project];
                return (0, r.jsx)("group", {
                    ref: e => {
                        B.current[a] = e
                    },
                    visible: !1,
                    children: (0, r.jsxs)("group", {
                        ref: e => {
                            G.current[a] = e
                        },
                        children: [(0, r.jsx)(p.default, {
                            image: S[t.project],
                            focus: n.cover.focus,
                            index: t.project,
                            progress: t.progress,
                            quarter: L.quarter,
                            drive: W(a),
                            lite: !0
                        }), (0, r.jsx)(x, {
                            image: S[t.project],
                            focus: n.cover.focus,
                            design: n.sleeve ? R.get((0, P.sized)(n.sleeve)) : void 0,
                            index: t.project,
                            quarter: L.quarter,
                            drive: W(a),
                            priority: N[a]
                        })]
                    })
                }, a)
            })
        })
    }

    function B({
        onReady: e
    }) {
        let t = (0, u.useThree)(e => e.get),
            r = (0, o.useRef)(null),
            a = (0, o.useRef)(!1);
        return (0, o.useLayoutEffect)(() => {
            let {
                scene: e,
                invalidate: a
            } = t(), o = new Set;
            return e.traverse(e => {
                let t = e.material;
                if (t)
                    for (let e of Array.isArray(t) ? t : [t])
                        for (let t of Object.values(e)) t instanceof n.Texture && t.image && o.add(t)
            }), r.current = [...o], e.visible = !1, a(), () => {
                t().scene.visible = !0
            }
        }, [t]), (0, l.useFrame)(() => {
            let n = r.current;
            if (!n || a.current) return;
            let {
                gl: o,
                scene: i,
                invalidate: l
            } = t();
            for (let e of n.splice(0, 2)) o.initTexture(e);
            n.length ? l() : (a.current = !0, i.visible = !0, l(), e())
        }), null
    }
    let U = new n.Texture,
        G = window.matchMedia("(pointer: coarse)").matches ? 1.25 : 1.5;

    function V({
        high: e,
        onChange: t
    }) {
        let r = (0, o.useRef)({
            sum: 0,
            n: 0,
            bad: 0,
            good: 0
        });
        return (0, l.useFrame)(({
            clock: a
        }, n) => {
            let o = r.current;
            if (a.elapsedTime < 6 || document.hidden || n > .25 || (o.sum += n, o.n += 1, o.sum < 1)) return;
            let i = o.n / o.sum;
            o.sum = o.n = 0, o.bad = i < 45 ? o.bad + 1 : 0, o.good = i > 57 ? o.good + 1 : 0, e && o.bad >= 2 ? (o.bad = 0, t(!1)) : !e && o.good >= 5 && (o.good = 0, t(!0))
        }), null
    }
    let _ = (0, o.memo)(function(e) {
        let {
            onReady: t,
            paused: n = !1,
            ...l
        } = e, s = h(e => e.progress);
        (0, o.useEffect)(() => (0, g.setLoadProgress)(s), [s]);
        let [u, c] = (0, o.useState)(G);
        return (0, r.jsxs)(i.Canvas, {
            dpr: [1, u],
            frameloop: n ? "never" : "demand",
            gl: a.BENT_CANVAS,
            camera: {
                fov: 14,
                position: [0, 0, 10],
                near: .1,
                far: 100
            },
            children: [(0, r.jsx)(V, {
                high: u === G,
                onChange: e => c(e ? G : 1)
            }), (0, r.jsx)(a.default, {}), (0, r.jsx)(j.default, {}), (0, r.jsxs)(o.Suspense, {
                fallback: null,
                children: [(0, r.jsx)(D, { ...l,
                    hidden: l.hidden || n
                }), (0, r.jsx)(B, {
                    onReady: t
                })]
            })]
        })
    });
    e.s(["default", 0, _], 864644)
}, 436345, function(e) {
    e.n(e.i(864644))
}, 993327, e => {
    "use strict";
    var t = e.i(662181);
    let r = window.matchMedia("(max-width: 700px)").matches;
    e.s(["ENTER_SECONDS", 0, 2.2, "FLING_MAX", 0, 5200, "WHEEL_IDLE_MS", 0, 140, "measure", 0, function(e, r) {
        let a = Math.min(e / 1728, r / 1117),
            n = document.querySelector(".vhs-canvas") ? .getBoundingClientRect().top ? ? 0,
            o = (document.querySelector("[data-tape-top]") ? .getBoundingClientRect().bottom ? ? n + .3 * r) - n,
            i = (document.querySelector("[data-tape-bottom]") ? .getBoundingClientRect().top ? ? n + .85 * r) - n,
            l = e < 700,
            s = o + (l ? 28 : 39 * a),
            u = i - (l ? 36 : 73 * a),
            c = Math.max(80, u - s) / ((t.CASE.w + t.PEEK.quarter) / t.TAPE.w),
            d = e => t.CASE.h / t.TAPE.w * e,
            f = e => t.CASE.w / t.TAPE.w * e;
        if (l) {
            let r = Math.min(c, .72 * e * t.TAPE.w / t.CASE.h),
                a = 1.24 * d(r);
            return {
                tapeW: r,
                quarter: !0,
                shownW: d(r),
                shownH: f(r),
                spacing: a,
                arcR: 4 * a,
                centerY: (s + u) / 2
            }
        }
        let h = Math.min(c, .3 * e * t.TAPE.w / t.CASE.h),
            g = 1.3 * d(h),
            m = 4 * g,
            p = m * (1 - Math.cos(g / m));
        return {
            tapeW: h,
            quarter: !0,
            shownW: d(h),
            shownH: f(h),
            spacing: g,
            arcR: m,
            centerY: (s + u) / 2 - p / 2
        }
    }, "mod", 0, (e, t) => (e % t + t) % t, "onArc", 0, function(e, t) {
        let r = e / t;
        return {
            x: t * Math.sin(r),
            drop: t * (1 - Math.cos(r)),
            angle: r
        }
    }, "sized", 0, function(e) {
        if (!r) return e;
        if (e.startsWith("/")) return `/_next/image?url=${encodeURIComponent(e)}&w=640&q=75`;
        try {
            let t = new URL(e);
            if ("cdn.sanity.io" === t.hostname) return t.searchParams.set("w", "640"), t.toString()
        } catch {}
        return e
    }])
}, 592563, e => {
    "use strict";
    e.s(["fontFamily", 0, function(e, t) {
        if ("u" < typeof document) return t;
        let r = getComputedStyle(document.body).getPropertyValue(e).trim();
        return r ? `${r}, ${t}` : t
    }])
}, 662181, e => {
    "use strict";
    e.s(["CARD", 0, {
        x: 0,
        y: -4.9,
        w: 79.6,
        h: 47.4,
        r: 2.2
    }, "CASE", 0, {
        w: 196,
        h: 130,
        t: 30,
        wall: 1
    }, "PEEK", 0, {
        wide: 22,
        quarter: 22
    }, "SCREWS", 0, [
        [-86.5, 46.2],
        [86.5, 46.2],
        [-86.5, -46.2],
        [86.5, -46.2]
    ], "TAPE", 0, {
        w: 187.5,
        h: 102.5,
        t: 25,
        plateau: [24.4, 40.6],
        grip: [-49.6, -31.3],
        doorEdge: 41.5,
        reels: [{
            x: -53.5,
            y: -4.5,
            supply: !0
        }, {
            x: 53.5,
            y: -4.5,
            supply: !1
        }],
        hubR: 13,
        packMax: 35.2,
        flangeR: 37.2,
        tapeZ: [-9.2, 3.5],
        rollers: [{
            x: -81,
            y: 38
        }, {
            x: 81,
            y: 38
        }],
        rollerR: 3.6
    }, "WINDOWS", 0, [{
        x: -67.4,
        y: -4.4,
        w: 43,
        h: 48.8,
        r: 8
    }, {
        x: 67.4,
        y: -4.4,
        w: 43,
        h: 48.8,
        r: 8
    }, {
        x: 0,
        y: -4.9,
        w: 80.6,
        h: 48.4,
        r: 2.8
    }]])
}, 82396, e => {
    "use strict";
    let t = new Set,
        r = !1,
        a = null,
        n = 0,
        o = e => Math.max(-1, Math.min(1, e));

    function i(e) {
        if (null == e.beta || null == e.gamma) return;
        let r = screen.orientation ? .angle ? ? 0,
            i = e.beta,
            l = e.gamma;
        90 === r ? [i, l] = [-e.gamma, e.beta] : (270 === r || -90 === r) && ([i, l] = [e.gamma, -e.beta]);
        let s = performance.now();
        if (!a) {
            a = {
                beta: i,
                gamma: l
            }, n = s;
            return
        }
        let u = Math.min(.1, (s - n) / 1e3);
        n = s;
        let c = 1 - Math.exp(-.25 * u);
        a.beta += (i - a.beta) * c, a.gamma += (l - a.gamma) * c;
        let d = o((l - a.gamma) / 18),
            f = o(-(i - a.beta) / 18);
        t.forEach(e => e(d, f))
    }

    function l() {
        window.addEventListener("deviceorientation", i, !0)
    }
    e.s(["onTilt", 0, function(e) {
        return ! function() {
            if (r || (r = !0, !window.matchMedia("(pointer: coarse)").matches || !("DeviceOrientationEvent" in window))) return;
            let e = window.DeviceOrientationEvent;
            if ("function" != typeof e.requestPermission) return l();
            let t = () => {
                window.removeEventListener("touchend", t), e.requestPermission().then(e => "granted" === e && l()).catch(() => {})
            };
            e.requestPermission().then(e => "granted" === e ? l() : window.addEventListener("touchend", t, {
                passive: !0
            })).catch(() => window.addEventListener("touchend", t, {
                passive: !0
            }))
        }(), t.add(e), () => {
            t.delete(e)
        }
    }])
}, 931067, e => {
    "use strict";

    function t() {
        return (t = Object.assign.bind()).apply(null, arguments)
    }
    e.s(["default", () => t])
}, 755838, (e, t, r) => {
    "use strict";
    var a = e.r(271645),
        n = "function" == typeof Object.is ? Object.is : function(e, t) {
            return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
        },
        o = a.useState,
        i = a.useEffect,
        l = a.useLayoutEffect,
        s = a.useDebugValue;

    function u(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
            var r = t();
            return !n(e, r)
        } catch (e) {
            return !0
        }
    }
    var c = "u" < typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
        return t()
    } : function(e, t) {
        var r = t(),
            a = o({
                inst: {
                    value: r,
                    getSnapshot: t
                }
            }),
            n = a[0].inst,
            c = a[1];
        return l(function() {
            n.value = r, n.getSnapshot = t, u(n) && c({
                inst: n
            })
        }, [e, r, t]), i(function() {
            return u(n) && c({
                inst: n
            }), e(function() {
                u(n) && c({
                    inst: n
                })
            })
        }, [e]), s(r), r
    };
    r.useSyncExternalStore = void 0 !== a.useSyncExternalStore ? a.useSyncExternalStore : c
}, 802239, (e, t, r) => {
    "use strict";
    e.i(247167), t.exports = e.r(755838)
}, 752822, (e, t, r) => {
    "use strict";
    var a = e.r(271645),
        n = e.r(802239),
        o = "function" == typeof Object.is ? Object.is : function(e, t) {
            return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
        },
        i = n.useSyncExternalStore,
        l = a.useRef,
        s = a.useEffect,
        u = a.useMemo,
        c = a.useDebugValue;
    r.useSyncExternalStoreWithSelector = function(e, t, r, a, n) {
        var d = l(null);
        if (null === d.current) {
            var f = {
                hasValue: !1,
                value: null
            };
            d.current = f
        } else f = d.current;
        var h = i(e, (d = u(function() {
            function e(e) {
                if (!s) {
                    if (s = !0, i = e, e = a(e), void 0 !== n && f.hasValue) {
                        var t = f.value;
                        if (n(t, e)) return l = t
                    }
                    return l = e
                }
                if (t = l, o(i, e)) return t;
                var r = a(e);
                return void 0 !== n && n(t, r) ? (i = e, t) : (i = e, l = r)
            }
            var i, l, s = !1,
                u = void 0 === r ? null : r;
            return [function() {
                return e(t())
            }, null === u ? void 0 : function() {
                return e(u())
            }]
        }, [t, r, a, n]))[0], d[1]);
        return s(function() {
            f.hasValue = !0, f.value = h
        }, [h]), c(h), h
    }
}, 430224, (e, t, r) => {
    "use strict";
    e.i(247167), t.exports = e.r(752822)
}, 408155, e => {
    "use strict";
    let t = e => {
        let t, r = new Set,
            a = (e, a) => {
                let n = "function" == typeof e ? e(t) : e;
                if (!Object.is(n, t)) {
                    let e = t;
                    t = (null != a ? a : "object" != typeof n || null === n) ? n : Object.assign({}, t, n), r.forEach(r => r(t, e))
                }
            },
            n = () => t,
            o = {
                setState: a,
                getState: n,
                getInitialState: () => i,
                subscribe: e => (r.add(e), () => r.delete(e))
            },
            i = t = e(a, n, o);
        return o
    };
    e.s(["createStore", 0, e => e ? t(e) : t])
}]);