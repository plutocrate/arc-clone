(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 18576, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        WarningIcon: function() {
            return u
        },
        errorStyles: function() {
            return a
        },
        errorThemeCss: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    e.r(555682);
    let i = e.r(843476);
    e.r(271645);
    let a = {
            container: {
                fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
                height: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            },
            card: {
                marginTop: "-32px",
                maxWidth: "325px",
                padding: "32px 28px",
                textAlign: "left"
            },
            icon: {
                marginBottom: "24px"
            },
            title: {
                fontSize: "24px",
                fontWeight: 500,
                letterSpacing: "-0.02em",
                lineHeight: "32px",
                margin: "0 0 12px 0",
                color: "var(--next-error-title)"
            },
            message: {
                fontSize: "14px",
                fontWeight: 400,
                lineHeight: "21px",
                margin: "0 0 20px 0",
                color: "var(--next-error-message)"
            },
            form: {
                margin: 0
            },
            buttonGroup: {
                display: "flex",
                gap: "8px",
                alignItems: "center"
            },
            button: {
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                height: "32px",
                padding: "0 12px",
                fontSize: "14px",
                fontWeight: 500,
                lineHeight: "20px",
                borderRadius: "6px",
                cursor: "pointer",
                color: "var(--next-error-btn-text)",
                background: "var(--next-error-btn-bg)",
                border: "var(--next-error-btn-border)"
            },
            buttonSecondary: {
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                height: "32px",
                padding: "0 12px",
                fontSize: "14px",
                fontWeight: 500,
                lineHeight: "20px",
                borderRadius: "6px",
                cursor: "pointer",
                color: "var(--next-error-btn-secondary-text)",
                background: "var(--next-error-btn-secondary-bg)",
                border: "var(--next-error-btn-secondary-border)"
            },
            digestFooter: {
                position: "fixed",
                bottom: "32px",
                left: "0",
                right: "0",
                textAlign: "center",
                fontFamily: 'ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace',
                fontSize: "12px",
                lineHeight: "18px",
                fontWeight: 400,
                margin: "0",
                color: "var(--next-error-digest)"
            }
        },
        l = `
:root {
  --next-error-bg: #fff;
  --next-error-text: #171717;
  --next-error-title: #171717;
  --next-error-message: #171717;
  --next-error-digest: #666666;
  --next-error-btn-text: #fff;
  --next-error-btn-bg: #171717;
  --next-error-btn-border: none;
  --next-error-btn-secondary-text: #171717;
  --next-error-btn-secondary-bg: transparent;
  --next-error-btn-secondary-border: 1px solid rgba(0,0,0,0.08);
}
@media (prefers-color-scheme: dark) {
  :root {
    --next-error-bg: #0a0a0a;
    --next-error-text: #ededed;
    --next-error-title: #ededed;
    --next-error-message: #ededed;
    --next-error-digest: #a0a0a0;
    --next-error-btn-text: #0a0a0a;
    --next-error-btn-bg: #ededed;
    --next-error-btn-border: none;
    --next-error-btn-secondary-text: #ededed;
    --next-error-btn-secondary-bg: transparent;
    --next-error-btn-secondary-border: 1px solid rgba(255,255,255,0.14);
  }
}
body { margin: 0; color: var(--next-error-text); background: var(--next-error-bg); }
`.replace(/\n\s*/g, "");

    function u() {
        return (0, i.jsx)("svg", {
            width: "32",
            height: "32",
            viewBox: "-0.2 -1.5 32 32",
            fill: "none",
            style: a.icon,
            children: (0, i.jsx)("path", {
                d: "M16.9328 0C18.0839 0.000116771 19.1334 0.658832 19.634 1.69531L31.4299 26.1309C32.0708 27.4588 31.1036 28.9999 29.6291 29H2.00215C0.527541 29 -0.439628 27.4588 0.201371 26.1309L11.9973 1.69531C12.4979 0.658823 13.5474 7.75066e-05 14.6984 0H16.9328ZM3.59493 26H28.0363L16.9328 3H14.6984L3.59493 26ZM15.8156 19C16.9202 19.0001 17.8156 19.8955 17.8156 21C17.8156 22.1045 16.9202 22.9999 15.8156 23C14.7111 23 13.8156 22.1046 13.8156 21C13.8156 19.8954 14.7111 19 15.8156 19ZM17.3156 16.5H14.3156V8.5H17.3156V16.5Z",
                fill: "var(--next-error-title)"
            })
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 168027, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function() {
            return a
        }
    }), e.r(555682);
    let n = e.r(843476);
    e.r(271645);
    let o = e.r(912354),
        i = e.r(18576),
        a = function({
            error: e
        }) {
            let r = e ? .digest,
                t = !!r;
            return (0, o.handleISRError)({
                error: e
            }), (0, n.jsxs)("html", {
                id: "__next_error__",
                children: [(0, n.jsx)("head", {
                    children: (0, n.jsx)("style", {
                        dangerouslySetInnerHTML: {
                            __html: i.errorThemeCss
                        }
                    })
                }), (0, n.jsxs)("body", {
                    children: [(0, n.jsx)("div", {
                        style: i.errorStyles.container,
                        children: (0, n.jsxs)("div", {
                            style: i.errorStyles.card,
                            children: [(0, n.jsx)(i.WarningIcon, {}), (0, n.jsx)("h1", {
                                style: i.errorStyles.title,
                                children: "This page couldn’t load"
                            }), (0, n.jsx)("p", {
                                style: i.errorStyles.message,
                                children: t ? "A server error occurred. Reload to try again." : "Reload to try again, or go back."
                            }), (0, n.jsxs)("div", {
                                style: i.errorStyles.buttonGroup,
                                children: [(0, n.jsx)("form", {
                                    style: i.errorStyles.form,
                                    children: (0, n.jsx)("button", {
                                        type: "submit",
                                        style: i.errorStyles.button,
                                        children: "Reload"
                                    })
                                }), !t && (0, n.jsx)("button", {
                                    type: "button",
                                    style: i.errorStyles.buttonSecondary,
                                    onClick: () => {
                                        window.history.length > 1 ? window.history.back() : window.location.href = "/"
                                    },
                                    children: "Back"
                                })]
                            })]
                        })
                    }), r && (0, n.jsxs)("p", {
                        style: i.errorStyles.digestFooter,
                        children: ["ERROR ", r]
                    })]
                })]
            })
        };
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 972383, (e, r, t) => {
    "use strict";
    e.i(247167), Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        ErrorBoundary: function() {
            return _
        },
        ErrorBoundaryHandler: function() {
            return y
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    let i = e.r(190809),
        a = e.r(843476),
        l = i._(e.r(271645)),
        u = e.r(590373),
        d = e.r(265713);
    e.r(178377);
    let s = e.r(912354),
        c = e.r(82604),
        f = e.r(8372),
        p = "u" > typeof window && (0, c.isBot)(window.navigator.userAgent);
    class y extends l.default.Component {
        static {
            this.contextType = f.AppRouterContext
        }
        constructor(e) {
            super(e), this.reset = () => {
                this.setState({
                    error: null
                })
            }, this.retry = () => {
                (0, l.startTransition)(() => {
                    this.context ? .refresh(), this.reset()
                })
            }, this.state = {
                error: null,
                previousPathname: this.props.pathname
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, d.isNextRouterError)(e)) throw e;
            return {
                error: {
                    thrownValue: e
                }
            }
        }
        static getDerivedStateFromProps(e, r) {
            let {
                error: t
            } = r;
            return e.pathname !== r.previousPathname && r.error ? {
                error: null,
                previousPathname: e.pathname
            } : {
                error: r.error,
                previousPathname: e.pathname
            }
        }
        render() {
            if (this.state.error && !p) {
                let e = this.state.error.thrownValue;
                return (0, s.handleISRError)({
                    error: e
                }), (0, a.jsxs)(a.Fragment, {
                    children: [this.props.errorStyles, this.props.errorScripts, (0, a.jsx)(this.props.errorComponent, {
                        error: e,
                        reset: this.reset,
                        retry: this.retry
                    })]
                })
            }
            return this.props.children
        }
    }

    function _({
        errorComponent: e,
        errorStyles: r,
        errorScripts: t,
        children: n
    }) {
        let o = (0, u.useUntrackedPathname)();
        return e ? (0, a.jsx)(y, {
            pathname: o,
            errorComponent: e,
            errorStyles: r,
            errorScripts: t,
            children: n
        }) : (0, a.jsx)(a.Fragment, {
            children: n
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 912354, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "handleISRError", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(585270);

    function o({
        error: e
    }) {
        if (n.workAsyncStorage) {
            let r = n.workAsyncStorage.getStore();
            if (r ? .isStaticGeneration) throw e && console.error(e), e
        }
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 178377, (e, r, t) => {
    "use strict";
    e.i(247167), Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        handleHardNavError: function() {
            return a
        },
        useNavFailureHandler: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    e.r(271645);
    let i = e.r(451191);

    function a(e) {
        return "u" > typeof window && !!window.next.__pendingUrl && (0, i.createHrefFromUrl)(new URL(window.location.href)) !== (0, i.createHrefFromUrl)(window.next.__pendingUrl) && (console.error("Error occurred during navigation, falling back to hard navigation", e), window.location.href = window.next.__pendingUrl.toString(), !0)
    }

    function l() {}("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 590373, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "useUntrackedPathname", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(271645),
        o = e.r(261994),
        i = e.r(585270);

    function a() {
        return ! function() {
            if ("u" < typeof window) {
                let e = i.workUnitAsyncStorage.getStore();
                if (!e) return !1;
                switch (e.type) {
                    case "prerender":
                    case "prerender-client":
                    case "prerender-ppr":
                    case "validation-client":
                        let r = e.fallbackRouteParams;
                        return !!r && r.size > 0
                }
            }
            return !1
        }() ? (0, n.useContext)(o.PathnameContext) : null
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 358442, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        RedirectBoundary: function() {
            return p
        },
        RedirectErrorBoundary: function() {
            return f
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    let i = e.r(190809),
        a = e.r(843476),
        l = i._(e.r(271645)),
        u = e.r(976562),
        d = e.r(124063),
        s = e.r(968391);

    function c({
        redirect: e,
        reset: r,
        redirectType: t
    }) {
        let n = (0, u.useRouter)();
        return (0, l.useEffect)(() => {
            l.default.startTransition(() => {
                "push" === t ? n.push(e, {}) : n.replace(e, {}), r()
            })
        }, [e, t, r, n]), null
    }
    class f extends l.default.Component {
        constructor(e) {
            super(e), this.state = {
                redirect: null,
                redirectType: null
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, s.isRedirectError)(e)) {
                let r = (0, d.getURLFromRedirectError)(e),
                    t = (0, d.getRedirectTypeFromError)(e);
                return "handled" in e ? {
                    redirect: null,
                    redirectType: null
                } : {
                    redirect: r,
                    redirectType: t
                }
            }
            throw e
        }
        render() {
            let {
                redirect: e,
                redirectType: r
            } = this.state;
            return null !== e && null !== r ? (0, a.jsx)(c, {
                redirect: e,
                redirectType: r,
                reset: () => this.setState({
                    redirect: null
                })
            }) : this.props.children
        }
    }

    function p({
        children: e
    }) {
        let r = (0, u.useRouter)();
        return (0, a.jsx)(f, {
            router: r,
            children: e
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 270725, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRouterCacheKey", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(813258);

    function o(e, r = !1) {
        return Array.isArray(e) ? `${e[0]}|${e[1]}|${e[2]}` : r && e.startsWith(n.PAGE_SEGMENT_KEY) ? n.PAGE_SEGMENT_KEY : e
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 201244, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "unresolvedThenable", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = {
        then: () => {}
    };
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 954839, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        METADATA_BOUNDARY_NAME: function() {
            return i
        },
        OUTLET_BOUNDARY_NAME: function() {
            return l
        },
        ROOT_LAYOUT_BOUNDARY_NAME: function() {
            return u
        },
        VIEWPORT_BOUNDARY_NAME: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    let i = "__next_metadata_boundary__",
        a = "__next_viewport_boundary__",
        l = "__next_outlet_boundary__",
        u = "__next_root_layout_boundary__"
}, 897367, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        MetadataBoundary: function() {
            return l
        },
        OutletBoundary: function() {
            return d
        },
        RootLayoutBoundary: function() {
            return s
        },
        ViewportBoundary: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(t, o, {
        enumerable: !0,
        get: n[o]
    });
    let i = e.r(954839),
        a = {
            [i.METADATA_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [i.VIEWPORT_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [i.OUTLET_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [i.ROOT_LAYOUT_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            }
        },
        l = a[i.METADATA_BOUNDARY_NAME.slice(0)],
        u = a[i.VIEWPORT_BOUNDARY_NAME.slice(0)],
        d = a[i.OUTLET_BOUNDARY_NAME.slice(0)],
        s = a[i.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]
}, 742732, (e, r, t) => {
    "use strict";
    e.i(247167), Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "HeadManagerContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(555682)._(e.r(271645)).default.createContext({})
}]);