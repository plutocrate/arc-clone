(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 745850, 495634, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["REVEAL_STAGGER_MS", 0, 70, "useIntro", 0, function(e, t, n = !0) {
        let [a, o] = (0, r.useState)(0), [i, s] = (0, r.useState)(!1), [l, u] = (0, r.useState)(!1), c = (0, r.useRef)(0), f = (0, r.useRef)(!1), d = (0, r.useRef)(t);
        return (0, r.useEffect)(() => {
            d.current = t
        }, [t]), (0, r.useEffect)(() => {
            if (!n) return;
            let e = window.setTimeout(() => s(!0), 220);
            return () => window.clearTimeout(e)
        }, [n]), (0, r.useEffect)(() => {
            if (!i) return;
            let e = window.setTimeout(() => {
                f.current = !0, d.current && u(!0)
            }, 1170);
            return () => window.clearTimeout(e)
        }, [i]), (0, r.useEffect)(() => {
            t && f.current && u(!0)
        }, [t]), (0, r.useEffect)(() => {
            let r = 0,
                n = performance.now(),
                a = () => {
                    let i = performance.now(),
                        s = Math.min(.25, (i - n) / 1e3);
                    n = i;
                    let l = 1 - Math.exp(-7 * s),
                        u = t ? 26 : Math.min(26 * e, 25);
                    c.current += (u - c.current) * l, t && 26 - c.current < .35 && (c.current = 26);
                    let f = Math.max(0, Math.round(c.current));
                    o(e => f > e ? f : e), t && 26 === c.current || (r = requestAnimationFrame(a))
                };
            return r = requestAnimationFrame(a), () => cancelAnimationFrame(r)
        }, [e, t]), {
            year: a,
            textIn: i,
            spiralIn: l
        }
    }], 495634);
    var n = e.i(306257),
        a = e.i(58685);
    let o = "hello@arcmarumo.com";

    function i() {
        return (0, t.jsxs)(t.Fragment, {
            children: ["[", (0, t.jsx)("span", {
                className: "pj-live-arrow",
                "aria-hidden": !0,
                children: "←"
            }), "]"]
        })
    }

    function s(e) {
        return window.addEventListener("bwchange", e), () => window.removeEventListener("bwchange", e)
    }
    e.s(["BwToggle", 0, function() {
        let e = (0, r.useSyncExternalStore)(s, () => document.documentElement.classList.contains("bw"), () => !1);
        return (0, t.jsxs)("button", {
            type: "button",
            role: "switch",
            "aria-checked": e,
            className: "vhs-bw-toggle",
            onClick: () => {
                let t = !e;
                document.documentElement.classList.toggle("bw", t);
                try {
                    localStorage.setItem("bw", t ? "1" : "0")
                } catch {}
                window.dispatchEvent(new Event("bwchange"))
            },
            children: ["B&W ", (0, t.jsxs)("span", {
                "aria-hidden": !0,
                children: ["[", e ? "ON" : "OFF", "]"]
            })]
        })
    }, "CONTACT_EMAIL", 0, o, "ContactLink", 0, function({
        label: e = "Contact",
        copiedLabel: n = "Copied",
        email: a = o,
        arrow: s = !1
    }) {
        let [l, u] = (0, r.useState)(!1);
        return (0, t.jsxs)("a", {
            href: `mailto:${a}`,
            onClick: () => {
                navigator.clipboard ? .writeText(a).then(() => {
                    u(!0), window.setTimeout(() => u(!1), 1600)
                }).catch(() => {})
            },
            "aria-live": "polite",
            children: [l ? n : e, s && (0, t.jsx)(i, {})]
        })
    }, "CrtLines", 0, function() {
        let e = (0, r.useRef)(null);
        return (0, r.useEffect)(() => {
            let t = e.current,
                r = t ? .getContext("2d");
            if (!t || !r) return;
            let a = () => {
                let e = Math.min(2, window.devicePixelRatio || 1),
                    a = t.clientWidth,
                    o = t.clientHeight;
                if (!a || !o) return;
                t.width = Math.round(a * e), t.height = Math.round(o * e), r.setTransform(e, 0, 0, e, 0, 0), r.clearRect(0, 0, a, o);
                let i = a / 2,
                    s = o / 2;
                r.fillStyle = "rgba(0, 0, 0, 0.32)";
                let l = 3 * Math.ceil(o * n.K / 3);
                for (let e = -l; e < o + l; e += 3) {
                    r.beginPath();
                    for (let t = 0; t <= a + 12; t += 12) {
                        let a = (t - i) / i,
                            o = s + (e - s) / (1 + n.K * a * a);
                        0 === t ? r.moveTo(t, o) : r.lineTo(t, o)
                    }
                    for (let t = 12 * Math.ceil((a + 12) / 12); t >= 0; t -= 12) {
                        let a = (t - i) / i;
                        r.lineTo(t, s + (e - s) / (1 + n.K * a * a) + 1)
                    }
                    r.fill()
                }
            };
            a();
            let o = new ResizeObserver(a);
            return o.observe(t), () => o.disconnect()
        }, []), (0, t.jsx)("canvas", {
            ref: e,
            className: "vhs-crt-lines",
            "aria-hidden": !0
        })
    }, "Grain", 0, function({
        fixed: e
    }) {
        return (0, t.jsx)("div", {
            className: `grain${e?" grain-fixed":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("div", {
                className: "grain-layer"
            })
        })
    }, "LinkArrow", 0, i, "Reveal", 0, function({
        on: e,
        i: n = 0,
        className: o,
        children: i
    }) {
        let [s, l] = (0, r.useState)(!1);
        (0, r.useEffect)(() => {
            if (void 0 !== e) return;
            let t = requestAnimationFrame(() => l(!0));
            return () => cancelAnimationFrame(t)
        }, [e]);
        let u = (0, a.useScreenReady)(),
            c = e ? ? (s && u);
        return (0, t.jsx)("span", {
            className: `rv${o?` ${o}`:""}`,
            children: (0, t.jsx)("span", {
                className: `rv-i${c?" rv-in":""}`,
                style: {
                    transitionDelay: `${70*n}ms`
                },
                children: i
            })
        })
    }, "TvGlass", 0, function() {
        return (0, t.jsx)("div", {
            className: "tv-glass",
            "aria-hidden": !0
        })
    }], 745850)
}, 111837, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["default", 0, function({
        progress: e,
        ready: n,
        onDone: a
    }) {
        let [o, i] = (0, r.useState)(0), [s, l] = (0, r.useState)(!1), u = (0, r.useRef)(0), c = (0, r.useRef)(a);
        return (0, r.useEffect)(() => {
            c.current = a
        }, [a]), (0, r.useEffect)(() => {
            let t = 0,
                r = performance.now(),
                a = () => {
                    let o = performance.now(),
                        s = Math.min(.25, (o - r) / 1e3);
                    r = o;
                    let l = n ? 100 : Math.min(100 * e, 99);
                    u.current += (l - u.current) * (1 - Math.exp(-5 * s)), n && 100 - u.current < .5 && (u.current = 100);
                    let c = Math.floor(u.current);
                    i(e => c > e ? c : e), u.current < 100 && (t = requestAnimationFrame(a))
                };
            return t = requestAnimationFrame(a), () => cancelAnimationFrame(t)
        }, [e, n]), (0, r.useEffect)(() => {
            if (o < 100) return;
            let e = window.setTimeout(() => l(!0), 350),
                t = window.setTimeout(() => c.current(), 850);
            return () => {
                window.clearTimeout(e), window.clearTimeout(t)
            }
        }, [o]), (0, t.jsxs)("div", {
            className: `vhs-loader${s?" is-out":""}`,
            role: "status",
            "aria-label": `Loading, ${o}%`,
            children: [(0, t.jsx)("p", {
                className: "vhs-loader-label",
                children: "Loading"
            }), (0, t.jsx)("p", {
                className: "vhs-loader-count",
                children: o
            }), (0, t.jsxs)("div", {
                className: "vhs-loader-bar",
                "aria-hidden": !0,
                style: {
                    "--loaded": o / 100
                },
                children: [(0, t.jsx)("i", {
                    className: "vhs-loader-ticks"
                }), (0, t.jsx)("i", {
                    className: "vhs-loader-dashes"
                })]
            })]
        })
    }])
}, 556304, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(618566);
    e.s(["default", 0, function({
        href: e,
        ...a
    }) {
        let o = (0, n.usePathname)() === e;
        return (0, t.jsx)(r.default, {
            href: e,
            "aria-current": o ? "page" : void 0,
            ...a
        })
    }])
}, 521145, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(271645),
        a = e.i(745850),
        o = e.i(111837),
        i = e.i(58685),
        s = e.i(783329),
        l = e.i(569414),
        u = e.i(844294),
        c = e.i(556304);
    e.s(["ProjectChrome", 0, function() {
        let [e, f] = (0, n.useState)(l.navSeen), [d, h] = (0, n.useState)(() => !(0, l.navSeen)()), m = (0, i.usePageLoad)(), p = (0, n.useCallback)(() => {
            h(!1), (0, i.releaseScreen)()
        }, []);
        (0, n.useEffect)(() => {
            (0, l.navSeen)() || (0, i.holdScreen)()
        }, []);
        let g = (0, n.useRef)(null);
        (0, u.useSiteTime)(g);
        let v = (0, u.useSastClock)(),
            w = (0, s.useDevice)(),
            y = {
                "--source-ch": `Source: ${w||"—"}`.length,
                "--first-ch": 7
            };
        return (0, n.useEffect)(() => {
            if (d) return;
            let e = requestAnimationFrame(() => {
                f(!0), (0, l.markNavSeen)()
            });
            return () => cancelAnimationFrame(e)
        }, [d]), (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsxs)("div", {
                className: "vhs-crt",
                "aria-hidden": !0,
                children: [(0, t.jsx)(a.CrtLines, {}), (0, t.jsx)(a.Grain, {}), (0, t.jsx)("div", {
                    className: "vhs-crt-roll"
                })]
            }), (0, t.jsxs)("header", {
                className: "vhs-head pj-chrome",
                style: y,
                children: [(0, t.jsxs)(r.default, {
                    href: "/",
                    className: "vhs-logo",
                    children: [(0, t.jsx)("span", {
                        className: "vhs-logo-mark",
                        children: (0, t.jsx)("span", {
                            className: `vhs-logo-i${e?" is-in":""}`,
                            children: (0, t.jsxs)("picture", {
                                children: [(0, t.jsx)("source", {
                                    media: "(max-width: 700px)",
                                    srcSet: "/brand/arc-bands.svg",
                                    width: 67,
                                    height: 30
                                }), (0, t.jsx)("img", {
                                    src: "/brand/arc-logo.svg",
                                    width: 115,
                                    height: 30,
                                    alt: "Arc — home"
                                })]
                            })
                        })
                    }), (0, t.jsx)("img", {
                        className: "vhs-logo-rule",
                        src: "/brand/logo-rule.svg",
                        width: 115,
                        height: 2,
                        alt: ""
                    }), (0, t.jsxs)("span", {
                        className: "vhs-logo-meta",
                        children: [(0, t.jsx)(a.Reveal, {
                            on: e,
                            i: 1,
                            children: "Year"
                        }), (0, t.jsx)(a.Reveal, {
                            on: e,
                            i: 1,
                            children: (0, t.jsx)("span", {
                                className: "vhs-year",
                                children: "2026"
                            })
                        })]
                    })]
                }), (0, t.jsx)(a.Reveal, {
                    on: e,
                    i: 2,
                    className: "vhs-counter",
                    children: (0, t.jsx)("span", {
                        ref: g,
                        children: "00:00:00"
                    })
                }), (0, t.jsx)(a.Reveal, {
                    on: e,
                    i: 3,
                    className: "vhs-home",
                    children: (0, t.jsx)(c.default, {
                        href: "/",
                        children: "Home"
                    })
                }), (0, t.jsxs)("nav", {
                    className: "vhs-nav",
                    children: [(0, t.jsx)(a.Reveal, {
                        on: e,
                        i: 4,
                        className: "vhs-nav-about",
                        children: (0, t.jsx)(c.default, {
                            href: "/profile",
                            children: "Profile"
                        })
                    }), (0, t.jsx)(a.Reveal, {
                        on: e,
                        i: 4,
                        className: "vhs-nav-gallery",
                        children: (0, t.jsx)(c.default, {
                            href: "/news-watch",
                            children: "News Watch"
                        })
                    }), (0, t.jsx)(a.Reveal, {
                        on: e,
                        i: 4,
                        children: (0, t.jsx)("a", {
                            href: `mailto:${a.CONTACT_EMAIL}`,
                            children: "Contact"
                        })
                    })]
                })]
            }), (0, t.jsxs)("footer", {
                className: "vhs-foot pj-chrome",
                style: y,
                children: [(0, t.jsxs)(a.Reveal, {
                    on: e,
                    i: 9,
                    children: [v || "00:00", (0, t.jsx)("span", {
                        className: "vhs-tz",
                        children: " SAST"
                    })]
                }), (0, t.jsx)(a.Reveal, {
                    on: e,
                    i: 9,
                    className: "vhs-bw",
                    children: (0, t.jsx)(a.BwToggle, {})
                }), (0, t.jsx)(a.Reveal, {
                    on: e,
                    i: 10,
                    className: "vhs-source",
                    children: (0, t.jsxs)("span", {
                        children: ["Source: ", w || "—"]
                    })
                }), (0, t.jsx)(a.Reveal, {
                    on: e,
                    i: 11,
                    className: "vhs-email",
                    children: (0, t.jsx)(a.ContactLink, {
                        label: "Email"
                    })
                })]
            }), d && (0, t.jsx)(o.default, {
                progress: m.progress,
                ready: m.ready,
                onDone: p
            })]
        })
    }])
}, 306257, e => {
    "use strict";
    var t = e.i(271645);
    let r = 0,
        n = null,
        a = "http://www.w3.org/2000/svg";

    function o() {
        let e = navigator.userAgent;
        return !(/safari/i.test(e) && !/chrome|chromium|crios|fxios|edg|android/i.test(e)) && !window.matchMedia("(pointer: coarse)").matches
    }
    e.s(["K", 0, .16, "bendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            a = r.height / 2,
            o = (e - r.left - n) / n,
            i = (t - r.top - a) / a,
            s = o,
            l = i;
        for (let e = 0; e < 5; e++) l = i / (1 + .16 * (s = o / (1 + .16 * l * l)) * s);
        return {
            x: r.left + n + s * n,
            y: r.top + a + l * a
        }
    }, "canBend", 0, o, "unbendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            a = r.height / 2,
            o = (e - r.left - n) / n,
            i = (t - r.top - a) / a;
        return {
            x: r.left + n + o * (1 + .16 * i * i) * n,
            y: r.top + a + i * (1 + .16 * o * o) * a
        }
    }, "useBend", 0, function(e) {
        let i = (0, t.useRef)(1),
            s = (0, t.useRef)(null);
        return (0, t.useEffect)(() => {
            let t = e.current;
            if (!t || !o()) return;
            let l = `crt-bend-${++r}`,
                u = document.createElementNS(a, "filter");
            u.id = l, u.setAttribute("x", "0"), u.setAttribute("y", "0"), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("primitiveUnits", "userSpaceOnUse"), u.setAttribute("color-interpolation-filters", "sRGB");
            let c = document.createElementNS(a, "feImage");
            c.setAttribute("preserveAspectRatio", "none"), c.setAttribute("result", "map");
            let f = document.createElementNS(a, "feDisplacementMap");
            f.setAttribute("in", "SourceGraphic"), f.setAttribute("in2", "map"), f.setAttribute("xChannelSelector", "R"), f.setAttribute("yChannelSelector", "G"), u.append(c, f), (function() {
                if (n ? .isConnected) return n;
                let e = document.createElementNS(a, "svg");
                return e.setAttribute("aria-hidden", "true"), e.setAttribute("width", "0"), e.setAttribute("height", "0"), e.style.position = "absolute", n = document.createElementNS(a, "defs"), e.appendChild(n), document.body.appendChild(e), n
            })().appendChild(u);
            let d = "",
                h = 0,
                m = () => {
                    f.setAttribute("scale", String(h * i.current)), t.style.filter = i.current > .001 ? `url(#${l})` : ""
                };
            s.current = m;
            let p = () => {
                let e = t.offsetWidth,
                    r = t.offsetHeight;
                if (!e || !r || `${e}x${r}` === d) return;
                d = `${e}x${r}`;
                let n = .16 * Math.max(e, r);
                c.setAttribute("x", "0"), c.setAttribute("y", "0"), c.setAttribute("width", String(e)), c.setAttribute("height", String(r)), c.setAttribute("href", function(e, t, r) {
                    let n = document.createElement("canvas");
                    n.width = n.height = 128;
                    let a = n.getContext("2d"),
                        o = a.createImageData(128, 128);
                    for (let n = 0; n < 128; n++) {
                        let a = (n + .5) / 128 * 2 - 1;
                        for (let i = 0; i < 128; i++) {
                            let s = (i + .5) / 128 * 2 - 1,
                                l = .16 * s * a * a * (e / 2),
                                u = .16 * a * s * s * (t / 2),
                                c = (128 * n + i) * 4;
                            o.data[c] = Math.round((.5 + l / r) * 255), o.data[c + 1] = Math.round((.5 + u / r) * 255), o.data[c + 2] = 128, o.data[c + 3] = 255
                        }
                    }
                    return a.putImageData(o, 0, 0), n.toDataURL()
                }(e, r, n)), h = n, m()
            };
            p();
            let g = new ResizeObserver(p);
            return g.observe(t), () => {
                g.disconnect(), s.current = null, u.remove(), t.style.filter = ""
            }
        }, [e]), (0, t.useCallback)(e => {
            i.current = e, s.current ? .()
        }, [])
    }])
}, 783329, 569414, 844294, e => {
    "use strict";
    var t = e.i(271645);
    let r = [
        [1512, 982, "MacBook 14″"],
        [1352, 878, "MacBook 14″"],
        [1800, 1169, "MacBook 14″"],
        [1728, 1117, "MacBook 16″"],
        [1496, 967, "MacBook 16″"],
        [2056, 1329, "MacBook 16″"],
        [1470, 956, "MacBook Air 13″"],
        [1280, 832, "MacBook Air 13″"],
        [1710, 1107, "MacBook Air 13″"],
        [1710, 1112, "MacBook Air 15″"],
        [1440, 932, "MacBook Air 15″"],
        [1440, 900, "MacBook 13″"],
        [1280, 800, "MacBook 13″"],
        [1680, 1050, "MacBook 13″"],
        [1536, 960, "MacBook 16″"]
    ];

    function n() {
        if ("u" < typeof navigator) return "Unknown";
        let e = navigator.userAgent,
            t = navigator.maxTouchPoints > 1;
        if (/iPhone/.test(e)) return "iPhone";
        if (/iPad/.test(e) || /Macintosh/.test(e) && t) return "iPad";
        if (/Android/.test(e)) return /Mobile/.test(e) ? "Android" : "Android Tablet";
        if (/CrOS/.test(e)) return "Chromebook";
        if (/Macintosh/.test(e)) {
            let e = Math.max(screen.width, screen.height),
                t = Math.min(screen.width, screen.height),
                n = r.find(([r, n]) => r === e && n === t);
            return n ? n[2] : e > 2056 ? "Mac Display" : "Mac"
        }
        return /Windows/.test(e) ? "PC" : /Linux/.test(e) ? "Linux" : "Unknown"
    }
    let a = () => () => {};
    e.s(["useDevice", 0, function() {
        return (0, t.useSyncExternalStore)(a, n, () => "")
    }], 783329);
    let o = !1;
    e.s(["markNavSeen", 0, function() {
        o = !0
    }, "navSeen", 0, () => o], 569414);
    let i = new Intl.DateTimeFormat("en-GB", {
            timeZone: "Africa/Johannesburg",
            hour: "2-digit",
            minute: "2-digit",
            hour12: !1
        }),
        s = () => i.format(new Date),
        l = e => {
            let t = window.setInterval(e, 15e3);
            return () => window.clearInterval(t)
        };
    e.s(["useSastClock", 0, function() {
        return (0, t.useSyncExternalStore)(l, s, () => "")
    }, "useSiteTime", 0, function(e, r = !0) {
        (0, t.useLayoutEffect)(() => {
            let t, n = function(e) {
                let t = "arc:visit";
                try {
                    let r = Number(sessionStorage.getItem(t));
                    if (r > 0) return r;
                    if (!e) return null;
                    let n = Date.now();
                    return sessionStorage.setItem(t, String(n)), n
                } catch {
                    return e ? Date.now() : null
                }
            }(r);
            if (null === n) return;
            let a = () => {
                let t = Math.max(0, Math.floor((Date.now() - n) / 1e3)),
                    r = String(Math.floor(t / 3600)).padStart(2, "0"),
                    a = String(Math.floor(t % 3600 / 60)).padStart(2, "0"),
                    o = String(t % 60).padStart(2, "0");
                e.current && (e.current.textContent = `${r}:${a}:${o}`)
            };
            a();
            let o = () => {
                t = window.setTimeout(() => {
                    a(), o()
                }, 1e3 - (Date.now() - n) % 1e3)
            };
            return o(), () => window.clearTimeout(t)
        }, [e, r])
    }], 844294)
}, 916494, e => {
    "use strict";
    let t = /swiftshader|llvmpipe|lavapipe|softpipe|software|basic render|warp/i,
        r = "arc:gpu",
        n = null;
    e.s(["can3D", 0, function() {
        let e = "hardware" === function() {
            if (n) return n;
            try {
                let e = new URLSearchParams(location.search).get("3d");
                if ("0" === e) return n = "software";
                if ("1" === e) return n = "hardware";
                let t = sessionStorage.getItem(r);
                if ("hardware" === t || "software" === t || "none" === t) return n = t
            } catch {}
            let e = "none";
            try {
                let r = document.createElement("canvas").getContext("webgl2", {
                    failIfMajorPerformanceCaveat: !0
                });
                if (r) {
                    let n = r.getExtension("WEBGL_debug_renderer_info"),
                        a = String(r.getParameter(n ? n.UNMASKED_RENDERER_WEBGL : r.RENDERER) ? ? "");
                    e = t.test(a) ? "software" : "hardware", r.getExtension("WEBGL_lose_context") ? .loseContext()
                }
            } catch {
                e = "none"
            }
            try {
                sessionStorage.setItem(r, e)
            } catch {}
            return n = e
        }();
        return !e && "u" > typeof document && document.documentElement.classList.add("lite"), e
    }])
}, 942295, e => {
    "use strict";
    e.s(["EASE", 0, 7, "SETTLE", 0, 4.2, "releaseSpeed", 0, function(e, t, r) {
        return Math.max(-r, Math.min(r, e * Math.exp(-Math.max(0, t - 40) / 45)))
    }, "settleSlot", 0, function(e, t, r, n = .12) {
        let a = Math.round(e / r) * r,
            o = e - t;
        return Math.abs(a - t) < r / 2 && Math.abs(o) > r * n ? t + Math.sign(o) * r : a
    }, "springTo", 0, function(e, t, r, n, a = 7) {
        let o = e - r,
            i = Math.exp(-a * n),
            s = t + a * o;
        return {
            x: r + (o + s * n) * i,
            v: (t - s * a * n) * i
        }
    }])
}, 58685, e => {
    "use strict";
    var t = e.i(271645);
    let r = !0,
        n = new Set,
        a = () => n.forEach(e => e()),
        o = e => (n.add(e), () => n.delete(e));
    e.s(["holdScreen", 0, function() {
        r = !1, a()
    }, "releaseScreen", 0, function() {
        r = !0, a()
    }, "usePageLoad", 0, function() {
        let [e, r] = (0, t.useState)({
            progress: 0,
            ready: !1
        });
        return (0, t.useEffect)(() => {
            if ("complete" === document.readyState) return void r({
                progress: 1,
                ready: !0
            });
            let e = [...document.images],
                t = () => {
                    let t = e.filter(e => e.complete).length;
                    r(r => r.ready ? r : {
                        progress: e.length ? t / e.length : .5,
                        ready: !1
                    })
                },
                n = () => r({
                    progress: 1,
                    ready: !0
                });
            return e.forEach(e => e.addEventListener("load", t)), window.addEventListener("load", n), t(), () => {
                e.forEach(e => e.removeEventListener("load", t)), window.removeEventListener("load", n)
            }
        }, []), e
    }, "useScreenReady", 0, function() {
        return (0, t.useSyncExternalStore)(o, () => r, () => !0)
    }])
}, 522016, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return v
        },
        useLinkStatus: function() {
            return y
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(190809),
        i = e.r(843476),
        s = o._(e.r(271645)),
        l = e.r(195057),
        u = e.r(8372),
        c = e.r(818581),
        f = e.r(718967),
        d = e.r(405550),
        h = e.r(388540),
        m = e.r(91949),
        p = e.r(573668),
        g = e.r(509396);

    function v(t) {
        var r;
        let n, a, o, [v, y] = (0, s.useOptimistic)(m.IDLE_LINK_STATUS),
            x = (0, s.useRef)(null),
            {
                href: b,
                as: S,
                children: E,
                prefetch: j = null,
                passHref: M,
                replace: A,
                shallow: N,
                scroll: R,
                onClick: T,
                onMouseEnter: C,
                onTouchStart: P,
                legacyBehavior: L = !1,
                onNavigate: k,
                transitionTypes: _,
                ref: O,
                unstable_dynamicOnHover: $,
                ...B
            } = t;
        n = E, L && ("string" == typeof n || "number" == typeof n) && (n = (0, i.jsx)("a", {
            children: n
        }));
        let I = s.default.useContext(u.AppRouterContext),
            D = !1 !== j,
            F = !1 === j ? "none" : !0 === j ? "full" : "auto",
            U = "none" !== F ? "auto" === F ? g.FetchStrategy.PPR : g.FetchStrategy.Full : g.FetchStrategy.PPR,
            K = "string" == typeof(r = S || b) ? r : (0, l.formatUrl)(r);
        if (L) {
            if (n ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            a = s.default.Children.only(n)
        }
        let G = L ? a && "object" == typeof a && a.ref : O,
            W, z = s.default.useCallback(e => (null !== I && (x.current = (0, m.mountLinkInstance)(e, K, I, U, D, y, W)), () => {
                x.current && ((0, m.unmountLinkForCurrentNavigation)(x.current), x.current = null), (0, m.unmountPrefetchableInstance)(e)
            }), [D, K, I, U, y, W]),
            q = {
                ref: (0, c.useMergedRef)(z, G),
                onClick(t) {
                    L || "function" != typeof T || T(t), L && a.props && "function" == typeof a.props.onClick && a.props.onClick(t), !I || t.defaultPrevented || function(t, r, n, a, o, i, l, u = "none") {
                        if ("u" > typeof window) {
                            let c, {
                                nodeName: f
                            } = t.currentTarget;
                            if ("A" === f.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, p.isLocalURL)(r)) {
                                a && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), i) {
                                let e = !1;
                                if (i({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: d
                            } = e.r(699781);
                            s.default.startTransition(() => {
                                d(r, a ? "replace" : "push", !1 === o ? h.ScrollBehavior.NoScroll : h.ScrollBehavior.Default, n.current, l, u)
                            })
                        }
                    }(t, K, x, A, R, k, _, F)
                },
                onMouseEnter(e) {
                    L || "function" != typeof C || C(e), L && a.props && "function" == typeof a.props.onMouseEnter && a.props.onMouseEnter(e), I && D && (0, m.onNavigationIntent)(e.currentTarget, !0 === $)
                },
                onTouchStart: function(e) {
                    L || "function" != typeof P || P(e), L && a.props && "function" == typeof a.props.onTouchStart && a.props.onTouchStart(e), I && D && (0, m.onNavigationIntent)(e.currentTarget, !0 === $)
                }
            };
        return (0, f.isAbsoluteUrl)(K) ? q.href = K : L && !M && ("a" !== a.type || "href" in a.props) || (q.href = (0, d.addBasePath)(K)), o = L ? s.default.cloneElement(a, q) : (0, i.jsx)("a", { ...B,
            ...q,
            children: n
        }), (0, i.jsx)(w.Provider, {
            value: v,
            children: o
        })
    }
    let w = (0, s.createContext)(m.IDLE_LINK_STATUS),
        y = () => (0, s.useContext)(w);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(271645);

    function a(e, t) {
        let r = (0, n.useRef)(null),
            a = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = a.current;
                t && (a.current = null, t())
            } else e && (r.current = o(e, n)), t && (a.current = o(t, n))
        }, [e, t])
    }

    function o(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(718967),
        a = e.r(652817);

    function o(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, a.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 998183, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        assign: function() {
            return l
        },
        searchParamsToUrlQuery: function() {
            return o
        },
        urlQueryToSearchParams: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });

    function o(e) {
        let t = {};
        for (let [r, n] of e.entries()) {
            let e = t[r];
            void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
        }
        return t
    }

    function i(e) {
        return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
    }

    function s(e) {
        let t = new URLSearchParams;
        for (let [r, n] of Object.entries(e))
            if (Array.isArray(n))
                for (let e of n) t.append(r, i(e));
            else t.set(r, i(n));
        return t
    }

    function l(e, ...t) {
        for (let r of t) {
            for (let t of r.keys()) e.delete(t);
            for (let [t, n] of r.entries()) e.append(t, n)
        }
        return e
    }
}, 195057, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return s
        },
        formatWithValidation: function() {
            return u
        },
        urlObjectKeys: function() {
            return l
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(190809)._(e.r(998183)),
        i = /https?|ftp|gopher|file/;

    function s(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", a = e.pathname || "", s = e.hash || "", l = e.query || "", u = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? u = t + e.host : r && (u = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (u += ":" + e.port)), l && "object" == typeof l && (l = String(o.urlQueryToSearchParams(l)));
        let c = e.search || l && `?${l}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || i.test(n)) && !1 !== u ? (u = "//" + (u || ""), a && "/" !== a[0] && (a = "/" + a)) : u || (u = ""), s && "#" !== s[0] && (s = "#" + s), c && "?" !== c[0] && (c = "?" + c), a = a.replace(/[?#]/g, encodeURIComponent), c = c.replace("#", "%23"), `${n}${u}${a}${c}${s}`
    }
    let l = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function u(e) {
        return s(e)
    }
}, 718967, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DecodeError: function() {
            return v
        },
        MiddlewareNotFoundError: function() {
            return b
        },
        MissingStaticPage: function() {
            return x
        },
        NormalizeError: function() {
            return w
        },
        PageNotFoundError: function() {
            return y
        },
        SP: function() {
            return p
        },
        ST: function() {
            return g
        },
        WEB_VITALS: function() {
            return o
        },
        execOnce: function() {
            return i
        },
        getDisplayName: function() {
            return f
        },
        getLocationOrigin: function() {
            return u
        },
        getURL: function() {
            return c
        },
        isAbsoluteUrl: function() {
            return l
        },
        isResSent: function() {
            return d
        },
        loadGetInitialProps: function() {
            return m
        },
        normalizeRepeatedSlashes: function() {
            return h
        },
        stringifyError: function() {
            return S
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

    function i(e) {
        let t, r = !1;
        return (...n) => (r || (r = !0, t = e(...n)), t)
    }
    let s = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
        l = e => {
            let t = e.charCodeAt(0);
            return !!(t >= 65 && t <= 90 || t >= 97 && t <= 122) && s.test(e)
        };

    function u() {
        let {
            protocol: e,
            hostname: t,
            port: r
        } = window.location;
        return `${e}//${t}${r?":"+r:""}`
    }

    function c() {
        let {
            href: e
        } = window.location, t = u();
        return e.substring(t.length)
    }

    function f(e) {
        return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
    }

    function d(e) {
        return e.finished || e.headersSent
    }

    function h(e) {
        let t = e.split("?");
        return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
    }
    async function m(e, t) {
        let r = t.res || t.ctx && t.ctx.res;
        if (!e.getInitialProps) return t.ctx && t.Component ? {
            pageProps: await m(t.Component, t.ctx)
        } : {};
        let n = await e.getInitialProps(t);
        if (r && d(r)) return n;
        if (!n) throw Object.defineProperty(Error(`"${f(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
            value: "E1025",
            enumerable: !1,
            configurable: !0
        });
        return n
    }
    let p = "u" > typeof performance,
        g = p && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
    class v extends Error {}
    class w extends Error {}
    class y extends Error {
        constructor(e) {
            super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
        }
    }
    class x extends Error {
        constructor(e, t) {
            super(), this.message = `Failed to load static file for page: ${e} ${t}`
        }
    }
    class b extends Error {
        constructor() {
            super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
        }
    }

    function S(e) {
        return JSON.stringify({
            message: e.message,
            stack: e.stack
        })
    }
}]);