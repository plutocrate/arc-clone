(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 745850, 495634, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["REVEAL_STAGGER_MS", 0, 70, "useIntro", 0, function(e, t, n = !0) {
        let [i, o] = (0, r.useState)(0), [a, s] = (0, r.useState)(!1), [u, l] = (0, r.useState)(!1), c = (0, r.useRef)(0), f = (0, r.useRef)(!1), d = (0, r.useRef)(t);
        return (0, r.useEffect)(() => {
            d.current = t
        }, [t]), (0, r.useEffect)(() => {
            if (!n) return;
            let e = window.setTimeout(() => s(!0), 220);
            return () => window.clearTimeout(e)
        }, [n]), (0, r.useEffect)(() => {
            if (!a) return;
            let e = window.setTimeout(() => {
                f.current = !0, d.current && l(!0)
            }, 1170);
            return () => window.clearTimeout(e)
        }, [a]), (0, r.useEffect)(() => {
            t && f.current && l(!0)
        }, [t]), (0, r.useEffect)(() => {
            let r = 0,
                n = performance.now(),
                i = () => {
                    let a = performance.now(),
                        s = Math.min(.25, (a - n) / 1e3);
                    n = a;
                    let u = 1 - Math.exp(-7 * s),
                        l = t ? 26 : Math.min(26 * e, 25);
                    c.current += (l - c.current) * u, t && 26 - c.current < .35 && (c.current = 26);
                    let f = Math.max(0, Math.round(c.current));
                    o(e => f > e ? f : e), t && 26 === c.current || (r = requestAnimationFrame(i))
                };
            return r = requestAnimationFrame(i), () => cancelAnimationFrame(r)
        }, [e, t]), {
            year: i,
            textIn: a,
            spiralIn: u
        }
    }], 495634);
    var n = e.i(306257),
        i = e.i(58685);
    let o = "hello@arcmarumo.com";

    function a() {
        return (0, t.jsxs)(t.Fragment, {
            children: ["[", (0, t.jsx)("span", {
                className: "pj-live-arrow",
                "aria-hidden": !0,
                children: "←"
            }), "]"]
        })
    }

    function s(e) {
        return window.addEventListener("bwchange", e), () => window.removeEventListener("bwchange", e)
    }
    e.s(["BwToggle", 0, function() {
        let e = (0, r.useSyncExternalStore)(s, () => document.documentElement.classList.contains("bw"), () => !1);
        return (0, t.jsxs)("button", {
            type: "button",
            role: "switch",
            "aria-checked": e,
            className: "vhs-bw-toggle",
            onClick: () => {
                let t = !e;
                document.documentElement.classList.toggle("bw", t);
                try {
                    localStorage.setItem("bw", t ? "1" : "0")
                } catch {}
                window.dispatchEvent(new Event("bwchange"))
            },
            children: ["B&W ", (0, t.jsxs)("span", {
                "aria-hidden": !0,
                children: ["[", e ? "ON" : "OFF", "]"]
            })]
        })
    }, "CONTACT_EMAIL", 0, o, "ContactLink", 0, function({
        label: e = "Contact",
        copiedLabel: n = "Copied",
        email: i = o,
        arrow: s = !1
    }) {
        let [u, l] = (0, r.useState)(!1);
        return (0, t.jsxs)("a", {
            href: `mailto:${i}`,
            onClick: () => {
                navigator.clipboard ? .writeText(i).then(() => {
                    l(!0), window.setTimeout(() => l(!1), 1600)
                }).catch(() => {})
            },
            "aria-live": "polite",
            children: [u ? n : e, s && (0, t.jsx)(a, {})]
        })
    }, "CrtLines", 0, function() {
        let e = (0, r.useRef)(null);
        return (0, r.useEffect)(() => {
            let t = e.current,
                r = t ? .getContext("2d");
            if (!t || !r) return;
            let i = () => {
                let e = Math.min(2, window.devicePixelRatio || 1),
                    i = t.clientWidth,
                    o = t.clientHeight;
                if (!i || !o) return;
                t.width = Math.round(i * e), t.height = Math.round(o * e), r.setTransform(e, 0, 0, e, 0, 0), r.clearRect(0, 0, i, o);
                let a = i / 2,
                    s = o / 2;
                r.fillStyle = "rgba(0, 0, 0, 0.32)";
                let u = 3 * Math.ceil(o * n.K / 3);
                for (let e = -u; e < o + u; e += 3) {
                    r.beginPath();
                    for (let t = 0; t <= i + 12; t += 12) {
                        let i = (t - a) / a,
                            o = s + (e - s) / (1 + n.K * i * i);
                        0 === t ? r.moveTo(t, o) : r.lineTo(t, o)
                    }
                    for (let t = 12 * Math.ceil((i + 12) / 12); t >= 0; t -= 12) {
                        let i = (t - a) / a;
                        r.lineTo(t, s + (e - s) / (1 + n.K * i * i) + 1)
                    }
                    r.fill()
                }
            };
            i();
            let o = new ResizeObserver(i);
            return o.observe(t), () => o.disconnect()
        }, []), (0, t.jsx)("canvas", {
            ref: e,
            className: "vhs-crt-lines",
            "aria-hidden": !0
        })
    }, "Grain", 0, function({
        fixed: e
    }) {
        return (0, t.jsx)("div", {
            className: `grain${e?" grain-fixed":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("div", {
                className: "grain-layer"
            })
        })
    }, "LinkArrow", 0, a, "Reveal", 0, function({
        on: e,
        i: n = 0,
        className: o,
        children: a
    }) {
        let [s, u] = (0, r.useState)(!1);
        (0, r.useEffect)(() => {
            if (void 0 !== e) return;
            let t = requestAnimationFrame(() => u(!0));
            return () => cancelAnimationFrame(t)
        }, [e]);
        let l = (0, i.useScreenReady)(),
            c = e ? ? (s && l);
        return (0, t.jsx)("span", {
            className: `rv${o?` ${o}`:""}`,
            children: (0, t.jsx)("span", {
                className: `rv-i${c?" rv-in":""}`,
                style: {
                    transitionDelay: `${70*n}ms`
                },
                children: a
            })
        })
    }, "TvGlass", 0, function() {
        return (0, t.jsx)("div", {
            className: "tv-glass",
            "aria-hidden": !0
        })
    }], 745850)
}, 780038, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(271645),
        i = e.i(58685),
        o = e.i(942295);

    function a({
        className: e,
        running: r = !0
    }) {
        let i = (0, n.useRef)(null);
        return (0, n.useEffect)(() => {
            let e = i.current,
                t = e ? .getContext("2d");
            if (!e || !t) return;
            let n = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                o = 0,
                a = 0,
                s = null,
                u = () => {
                    e.width = Math.max(1, Math.round(e.clientWidth / 3)), e.height = Math.max(1, Math.round(e.clientHeight / 3)), s = t.createImageData(e.width, e.height)
                },
                l = r => {
                    if (!s) return;
                    let n = s.data,
                        i = e.width,
                        o = r / 1e3 * .25 % 1.4 - .2;
                    for (let t = 0, r = 0; t < n.length; t += 4, r++) {
                        let a = Math.min(255, 255 * Math.random() + 60 * Math.max(0, 1 - 12 * Math.abs(Math.floor(r / i) / e.height - o)));
                        n[t] = n[t + 1] = n[t + 2] = a, n[t + 3] = 255
                    }
                    t.putImageData(s, 0, 0)
                },
                c = e => {
                    e - a >= 41.666666666666664 && (a = e, l(e)), o = requestAnimationFrame(c)
                };
            u(), n || !r ? l(performance.now()) : o = requestAnimationFrame(c);
            let f = new ResizeObserver(() => {
                u(), l(performance.now())
            });
            return f.observe(e), () => {
                f.disconnect(), cancelAnimationFrame(o)
            }
        }, [r]), (0, t.jsx)("canvas", {
            ref: i,
            className: e,
            "aria-hidden": !0
        })
    }
    let s = (e, t, r = "") => `${(e+Math.random()*(t-e)).toFixed(2)}${r}`;
    e.s(["default", 0, function() {
        let e = (0, n.useRef)(null),
            u = (0, i.useScreenReady)();
        return (0, n.useEffect)(() => {
            let t = e.current;
            if (!t || !u) return;
            let r = t.querySelector(".nf-word");
            if (!r) return;
            let n = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                i = 0,
                a = 0,
                l = 0,
                c = 0,
                f = 1,
                d = t.closest(".nf"),
                h = 0,
                m = 0,
                p = (e = 1, t = !1) => {
                    if (!d || n) return;
                    d.classList.remove("is-distort", "is-wild");
                    let r = {
                        "--tear-y": s(10, 80, "%"),
                        "--tear-h": s(4, 9 * e, "%"),
                        "--tear2-y": s(5, 90, "%"),
                        "--tear2-h": s(2, 4 * e, "%"),
                        "--fringe": s(.02 * e, .035 * e, "em")
                    };
                    for (let t = 1; t <= 4; t++) r[`--x${t}`] = s(-1.8 * e, 1.8 * e, "%"), r[`--k${t}`] = s(-5 * e, 5 * e, "deg");
                    for (let [e, t] of Object.entries(r)) d.style.setProperty(e, t);
                    d.offsetWidth, d.classList.add("is-distort"), t && d.classList.add("is-wild"), window.clearTimeout(m), m = window.setTimeout(() => d.classList.remove("is-distort", "is-wild"), 300)
                },
                g = null,
                w = 0,
                v = 0,
                b = e => {
                    if (null === g || !d) return;
                    let t = Math.min(1, (e - g) / 5e3);
                    if (t >= 1) {
                        d.classList.remove("is-distort", "is-wild"), d.classList.add("is-bars");
                        return
                    }
                    e >= v && (p(1 + 3 * t * t, t > .35), v = e + 700 + -630 * t), w = requestAnimationFrame(b)
                },
                y = e => {
                    e.button > 0 || e.target instanceof Element && e.target.closest("a") || (g = performance.now(), v = 0, cancelAnimationFrame(w), w = requestAnimationFrame(b))
                },
                E = () => {
                    null !== g && (g = null, cancelAnimationFrame(w), d ? .classList.remove("is-bars", "is-wild"))
                };
            window.addEventListener("pointerdown", y), window.addEventListener("pointerup", E), window.addEventListener("pointercancel", E), window.addEventListener("blur", E);
            let x = () => {
                    t.style.setProperty("--size", "100px");
                    let e = r.scrollWidth || 1;
                    t.style.setProperty("--size", `${100*t.clientWidth/e}px`);
                    let n = r.offsetHeight || 1,
                        i = .05999999999999994 * n;
                    f = Math.max(1, (.94 * t.clientHeight - r.offsetTop - n + i) / i)
                },
                S = e => {
                    let r = 1 + (f - 1) * e;
                    t.style.setProperty("--k", String(r))
                },
                A = e => {
                    let t = a ? Math.min(.1, (e - a) / 1e3) : 0;
                    a = e, ({
                        x: l,
                        v: c
                    } = (0, o.springTo)(l, c, 1, t, .75)), 1 - l < 5e-4 && (l = 1), S(l), l < .98 && e >= h && (p(), h = e + 2e3), i = l < 1 ? requestAnimationFrame(A) : 0
                };
            x(), n ? S(1) : (S(0), i = requestAnimationFrame(A));
            let M = new ResizeObserver(() => {
                x(), S(n ? 1 : l)
            });
            return M.observe(t), () => {
                M.disconnect(), cancelAnimationFrame(i), window.clearTimeout(m), cancelAnimationFrame(w), window.removeEventListener("pointerdown", y), window.removeEventListener("pointerup", E), window.removeEventListener("pointercancel", E), window.removeEventListener("blur", E), d ? .classList.remove("is-distort", "is-wild", "is-bars")
            }
        }, [u]), (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)(a, {
                className: "nf-static"
            }), (0, t.jsx)("div", {
                className: "nf-bars",
                "aria-hidden": !0
            }), (0, t.jsxs)("div", {
                ref: e,
                className: "nf-stage",
                "aria-hidden": !0,
                style: {
                    "--a": .52,
                    "--b": .58
                },
                children: [(0, t.jsx)("span", {
                    className: "nf-word nf-top",
                    children: "404"
                }), (0, t.jsx)("span", {
                    className: "nf-word nf-slice",
                    children: "404"
                }), (0, t.jsx)("span", {
                    className: "nf-word nf-feet",
                    children: "404"
                })]
            }), (0, t.jsxs)("div", {
                className: "nf-note",
                children: [(0, t.jsx)("h1", {
                    children: "Page not found"
                }), (0, t.jsx)(r.default, {
                    href: "/",
                    className: "nf-back",
                    "data-back": !0,
                    children: "[←]Go back"
                })]
            })]
        })
    }], 780038)
}, 306257, e => {
    "use strict";
    var t = e.i(271645);
    let r = 0,
        n = null,
        i = "http://www.w3.org/2000/svg";

    function o() {
        let e = navigator.userAgent;
        return !(/safari/i.test(e) && !/chrome|chromium|crios|fxios|edg|android/i.test(e)) && !window.matchMedia("(pointer: coarse)").matches
    }
    e.s(["K", 0, .16, "bendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            i = r.height / 2,
            o = (e - r.left - n) / n,
            a = (t - r.top - i) / i,
            s = o,
            u = a;
        for (let e = 0; e < 5; e++) u = a / (1 + .16 * (s = o / (1 + .16 * u * u)) * s);
        return {
            x: r.left + n + s * n,
            y: r.top + i + u * i
        }
    }, "canBend", 0, o, "unbendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            i = r.height / 2,
            o = (e - r.left - n) / n,
            a = (t - r.top - i) / i;
        return {
            x: r.left + n + o * (1 + .16 * a * a) * n,
            y: r.top + i + a * (1 + .16 * o * o) * i
        }
    }, "useBend", 0, function(e) {
        let a = (0, t.useRef)(1),
            s = (0, t.useRef)(null);
        return (0, t.useEffect)(() => {
            let t = e.current;
            if (!t || !o()) return;
            let u = `crt-bend-${++r}`,
                l = document.createElementNS(i, "filter");
            l.id = u, l.setAttribute("x", "0"), l.setAttribute("y", "0"), l.setAttribute("width", "1"), l.setAttribute("height", "1"), l.setAttribute("primitiveUnits", "userSpaceOnUse"), l.setAttribute("color-interpolation-filters", "sRGB");
            let c = document.createElementNS(i, "feImage");
            c.setAttribute("preserveAspectRatio", "none"), c.setAttribute("result", "map");
            let f = document.createElementNS(i, "feDisplacementMap");
            f.setAttribute("in", "SourceGraphic"), f.setAttribute("in2", "map"), f.setAttribute("xChannelSelector", "R"), f.setAttribute("yChannelSelector", "G"), l.append(c, f), (function() {
                if (n ? .isConnected) return n;
                let e = document.createElementNS(i, "svg");
                return e.setAttribute("aria-hidden", "true"), e.setAttribute("width", "0"), e.setAttribute("height", "0"), e.style.position = "absolute", n = document.createElementNS(i, "defs"), e.appendChild(n), document.body.appendChild(e), n
            })().appendChild(l);
            let d = "",
                h = 0,
                m = () => {
                    f.setAttribute("scale", String(h * a.current)), t.style.filter = a.current > .001 ? `url(#${u})` : ""
                };
            s.current = m;
            let p = () => {
                let e = t.offsetWidth,
                    r = t.offsetHeight;
                if (!e || !r || `${e}x${r}` === d) return;
                d = `${e}x${r}`;
                let n = .16 * Math.max(e, r);
                c.setAttribute("x", "0"), c.setAttribute("y", "0"), c.setAttribute("width", String(e)), c.setAttribute("height", String(r)), c.setAttribute("href", function(e, t, r) {
                    let n = document.createElement("canvas");
                    n.width = n.height = 128;
                    let i = n.getContext("2d"),
                        o = i.createImageData(128, 128);
                    for (let n = 0; n < 128; n++) {
                        let i = (n + .5) / 128 * 2 - 1;
                        for (let a = 0; a < 128; a++) {
                            let s = (a + .5) / 128 * 2 - 1,
                                u = .16 * s * i * i * (e / 2),
                                l = .16 * i * s * s * (t / 2),
                                c = (128 * n + a) * 4;
                            o.data[c] = Math.round((.5 + u / r) * 255), o.data[c + 1] = Math.round((.5 + l / r) * 255), o.data[c + 2] = 128, o.data[c + 3] = 255
                        }
                    }
                    return i.putImageData(o, 0, 0), n.toDataURL()
                }(e, r, n)), h = n, m()
            };
            p();
            let g = new ResizeObserver(p);
            return g.observe(t), () => {
                g.disconnect(), s.current = null, l.remove(), t.style.filter = ""
            }
        }, [e]), (0, t.useCallback)(e => {
            a.current = e, s.current ? .()
        }, [])
    }])
}, 942295, e => {
    "use strict";
    e.s(["EASE", 0, 7, "SETTLE", 0, 4.2, "releaseSpeed", 0, function(e, t, r) {
        return Math.max(-r, Math.min(r, e * Math.exp(-Math.max(0, t - 40) / 45)))
    }, "settleSlot", 0, function(e, t, r, n = .12) {
        let i = Math.round(e / r) * r,
            o = e - t;
        return Math.abs(i - t) < r / 2 && Math.abs(o) > r * n ? t + Math.sign(o) * r : i
    }, "springTo", 0, function(e, t, r, n, i = 7) {
        let o = e - r,
            a = Math.exp(-i * n),
            s = t + i * o;
        return {
            x: r + (o + s * n) * a,
            v: (t - s * i * n) * a
        }
    }])
}, 58685, e => {
    "use strict";
    var t = e.i(271645);
    let r = !0,
        n = new Set,
        i = () => n.forEach(e => e()),
        o = e => (n.add(e), () => n.delete(e));
    e.s(["holdScreen", 0, function() {
        r = !1, i()
    }, "releaseScreen", 0, function() {
        r = !0, i()
    }, "usePageLoad", 0, function() {
        let [e, r] = (0, t.useState)({
            progress: 0,
            ready: !1
        });
        return (0, t.useEffect)(() => {
            if ("complete" === document.readyState) return void r({
                progress: 1,
                ready: !0
            });
            let e = [...document.images],
                t = () => {
                    let t = e.filter(e => e.complete).length;
                    r(r => r.ready ? r : {
                        progress: e.length ? t / e.length : .5,
                        ready: !1
                    })
                },
                n = () => r({
                    progress: 1,
                    ready: !0
                });
            return e.forEach(e => e.addEventListener("load", t)), window.addEventListener("load", n), t(), () => {
                e.forEach(e => e.removeEventListener("load", t)), window.removeEventListener("load", n)
            }
        }, []), e
    }, "useScreenReady", 0, function() {
        return (0, t.useSyncExternalStore)(o, () => r, () => !0)
    }])
}, 522016, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return w
        },
        useLinkStatus: function() {
            return b
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(190809),
        a = e.r(843476),
        s = o._(e.r(271645)),
        u = e.r(195057),
        l = e.r(8372),
        c = e.r(818581),
        f = e.r(718967),
        d = e.r(405550),
        h = e.r(388540),
        m = e.r(91949),
        p = e.r(573668),
        g = e.r(509396);

    function w(t) {
        var r;
        let n, i, o, [w, b] = (0, s.useOptimistic)(m.IDLE_LINK_STATUS),
            y = (0, s.useRef)(null),
            {
                href: E,
                as: x,
                children: S,
                prefetch: A = null,
                passHref: M,
                replace: j,
                shallow: L,
                scroll: P,
                onClick: T,
                onMouseEnter: R,
                onTouchStart: C,
                legacyBehavior: N = !1,
                onNavigate: O,
                transitionTypes: _,
                ref: $,
                unstable_dynamicOnHover: F,
                ...k
            } = t;
        n = S, N && ("string" == typeof n || "number" == typeof n) && (n = (0, a.jsx)("a", {
            children: n
        }));
        let I = s.default.useContext(l.AppRouterContext),
            U = !1 !== A,
            D = !1 === A ? "none" : !0 === A ? "full" : "auto",
            B = "none" !== D ? "auto" === D ? g.FetchStrategy.PPR : g.FetchStrategy.Full : g.FetchStrategy.PPR,
            K = "string" == typeof(r = x || E) ? r : (0, u.formatUrl)(r);
        if (N) {
            if (n ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            i = s.default.Children.only(n)
        }
        let q = N ? i && "object" == typeof i && i.ref : $,
            z, W = s.default.useCallback(e => (null !== I && (y.current = (0, m.mountLinkInstance)(e, K, I, B, U, b, z)), () => {
                y.current && ((0, m.unmountLinkForCurrentNavigation)(y.current), y.current = null), (0, m.unmountPrefetchableInstance)(e)
            }), [U, K, I, B, b, z]),
            G = {
                ref: (0, c.useMergedRef)(W, q),
                onClick(t) {
                    N || "function" != typeof T || T(t), N && i.props && "function" == typeof i.props.onClick && i.props.onClick(t), !I || t.defaultPrevented || function(t, r, n, i, o, a, u, l = "none") {
                        if ("u" > typeof window) {
                            let c, {
                                nodeName: f
                            } = t.currentTarget;
                            if ("A" === f.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, p.isLocalURL)(r)) {
                                i && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), a) {
                                let e = !1;
                                if (a({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: d
                            } = e.r(699781);
                            s.default.startTransition(() => {
                                d(r, i ? "replace" : "push", !1 === o ? h.ScrollBehavior.NoScroll : h.ScrollBehavior.Default, n.current, u, l)
                            })
                        }
                    }(t, K, y, j, P, O, _, D)
                },
                onMouseEnter(e) {
                    N || "function" != typeof R || R(e), N && i.props && "function" == typeof i.props.onMouseEnter && i.props.onMouseEnter(e), I && U && (0, m.onNavigationIntent)(e.currentTarget, !0 === F)
                },
                onTouchStart: function(e) {
                    N || "function" != typeof C || C(e), N && i.props && "function" == typeof i.props.onTouchStart && i.props.onTouchStart(e), I && U && (0, m.onNavigationIntent)(e.currentTarget, !0 === F)
                }
            };
        return (0, f.isAbsoluteUrl)(K) ? G.href = K : N && !M && ("a" !== i.type || "href" in i.props) || (G.href = (0, d.addBasePath)(K)), o = N ? s.default.cloneElement(i, G) : (0, a.jsx)("a", { ...k,
            ...G,
            children: n
        }), (0, a.jsx)(v.Provider, {
            value: w,
            children: o
        })
    }
    let v = (0, s.createContext)(m.IDLE_LINK_STATUS),
        b = () => (0, s.useContext)(v);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(271645);

    function i(e, t) {
        let r = (0, n.useRef)(null),
            i = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = i.current;
                t && (i.current = null, t())
            } else e && (r.current = o(e, n)), t && (i.current = o(t, n))
        }, [e, t])
    }

    function o(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(718967),
        i = e.r(652817);

    function o(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, i.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 998183, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        assign: function() {
            return u
        },
        searchParamsToUrlQuery: function() {
            return o
        },
        urlQueryToSearchParams: function() {
            return s
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });

    function o(e) {
        let t = {};
        for (let [r, n] of e.entries()) {
            let e = t[r];
            void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
        }
        return t
    }

    function a(e) {
        return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
    }

    function s(e) {
        let t = new URLSearchParams;
        for (let [r, n] of Object.entries(e))
            if (Array.isArray(n))
                for (let e of n) t.append(r, a(e));
            else t.set(r, a(n));
        return t
    }

    function u(e, ...t) {
        for (let r of t) {
            for (let t of r.keys()) e.delete(t);
            for (let [t, n] of r.entries()) e.append(t, n)
        }
        return e
    }
}, 195057, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return s
        },
        formatWithValidation: function() {
            return l
        },
        urlObjectKeys: function() {
            return u
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(190809)._(e.r(998183)),
        a = /https?|ftp|gopher|file/;

    function s(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", i = e.pathname || "", s = e.hash || "", u = e.query || "", l = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? l = t + e.host : r && (l = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (l += ":" + e.port)), u && "object" == typeof u && (u = String(o.urlQueryToSearchParams(u)));
        let c = e.search || u && `?${u}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || a.test(n)) && !1 !== l ? (l = "//" + (l || ""), i && "/" !== i[0] && (i = "/" + i)) : l || (l = ""), s && "#" !== s[0] && (s = "#" + s), c && "?" !== c[0] && (c = "?" + c), i = i.replace(/[?#]/g, encodeURIComponent), c = c.replace("#", "%23"), `${n}${l}${i}${c}${s}`
    }
    let u = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function l(e) {
        return s(e)
    }
}, 718967, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DecodeError: function() {
            return w
        },
        MiddlewareNotFoundError: function() {
            return E
        },
        MissingStaticPage: function() {
            return y
        },
        NormalizeError: function() {
            return v
        },
        PageNotFoundError: function() {
            return b
        },
        SP: function() {
            return p
        },
        ST: function() {
            return g
        },
        WEB_VITALS: function() {
            return o
        },
        execOnce: function() {
            return a
        },
        getDisplayName: function() {
            return f
        },
        getLocationOrigin: function() {
            return l
        },
        getURL: function() {
            return c
        },
        isAbsoluteUrl: function() {
            return u
        },
        isResSent: function() {
            return d
        },
        loadGetInitialProps: function() {
            return m
        },
        normalizeRepeatedSlashes: function() {
            return h
        },
        stringifyError: function() {
            return x
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

    function a(e) {
        let t, r = !1;
        return (...n) => (r || (r = !0, t = e(...n)), t)
    }
    let s = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
        u = e => {
            let t = e.charCodeAt(0);
            return !!(t >= 65 && t <= 90 || t >= 97 && t <= 122) && s.test(e)
        };

    function l() {
        let {
            protocol: e,
            hostname: t,
            port: r
        } = window.location;
        return `${e}//${t}${r?":"+r:""}`
    }

    function c() {
        let {
            href: e
        } = window.location, t = l();
        return e.substring(t.length)
    }

    function f(e) {
        return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
    }

    function d(e) {
        return e.finished || e.headersSent
    }

    function h(e) {
        let t = e.split("?");
        return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
    }
    async function m(e, t) {
        let r = t.res || t.ctx && t.ctx.res;
        if (!e.getInitialProps) return t.ctx && t.Component ? {
            pageProps: await m(t.Component, t.ctx)
        } : {};
        let n = await e.getInitialProps(t);
        if (r && d(r)) return n;
        if (!n) throw Object.defineProperty(Error(`"${f(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
            value: "E1025",
            enumerable: !1,
            configurable: !0
        });
        return n
    }
    let p = "u" > typeof performance,
        g = p && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
    class w extends Error {}
    class v extends Error {}
    class b extends Error {
        constructor(e) {
            super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
        }
    }
    class y extends Error {
        constructor(e, t) {
            super(), this.message = `Failed to load static file for page: ${e} ${t}`
        }
    }
    class E extends Error {
        constructor() {
            super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
        }
    }

    function x(e) {
        return JSON.stringify({
            message: e.message,
            stack: e.stack
        })
    }
}]);