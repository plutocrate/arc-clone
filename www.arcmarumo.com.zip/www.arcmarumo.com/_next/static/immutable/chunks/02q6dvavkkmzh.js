(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 733247, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        s = e.i(745850),
        i = e.i(770703),
        n = e.i(592563),
        r = e.i(599109),
        l = e.i(942295),
        o = e.i(916494),
        c = e.i(926236),
        d = e.i(82396);
    let h = (0, i.default)(() => e.A(466552), {
        loadableGenerated: {
            modules: [79313]
        },
        ssr: !1
    });

    function m({
        portrait: e,
        date: s,
        engagements: i,
        achievements: A,
        currently: R,
        availability: N
    }) {
        let [C, T] = (0, a.useState)(!1), P = (0, a.useRef)(null), $ = (0, a.useRef)(null), F = (0, a.useRef)(null), q = (0, a.useRef)(null);
        (0, a.useEffect)(() => {
            for (let [e, t] of [
                    [$.current, 20260],
                    [F.current, 70331]
                ]) {
                let a = e ? .getContext("2d");
                e && a && (0, r.drawWear)(a, e.width, e.height, t)
            }
        }, []), (0, a.useEffect)(() => {
            let t = !0,
                a = new Image;
            return a.src = e, Promise.all([a.decode(), document.fonts ? .load(`400 100px ${(0,n.fontFamily)("--font-display","Georgia, serif")}`)]).then(() => {
                var e, s, i;
                let r, l, o, c, d, h, m, f = P.current,
                    p = f ? .getContext("2d");
                t && f && p && (e = p, s = f.width / u.w, i = a, r = u.w * s, l = u.h * s, e.fillStyle = "#000", e.fillRect(0, 0, r, l), e.drawImage(i, -168.1 * s, -45.03 * s, 908.03 * s, 908.03 * s), e.globalCompositeOperation = "multiply", e.fillStyle = "rgb(240,240,240)", e.fillRect(0, 0, r, l), e.globalCompositeOperation = "soft-light", e.fillStyle = "#000", e.fillRect(-239.39 * s, 0, 887.01 * s, 887.01 * s), e.globalCompositeOperation = "overlay", e.globalAlpha = .85, e.fillStyle = e.createPattern(function() {
                    if (k) return k;
                    let e = document.createElement("canvas");
                    e.width = e.height = 256;
                    let t = e.getContext("2d"),
                        a = t.createImageData(256, 256);
                    for (let e = 0; e < a.data.length; e += 4) {
                        let t = 255 * Math.random();
                        a.data[e] = a.data[e + 1] = a.data[e + 2] = t, a.data[e + 3] = 255
                    }
                    return t.putImageData(a, 0, 0), k = e
                }(), "repeat"), e.fillRect(0, 0, r, l), e.globalAlpha = 1, e.globalCompositeOperation = "color-dodge", e.fillStyle = "#ff0000", o = 295.93 * s, e.font = `400 ${o}px ${(0,n.fontFamily)("--font-display","Georgia, serif")}`, e.textAlign = "center", e.textBaseline = "alphabetic", d = (c = e.measureText("ARC")).fontBoundingBoxAscent ? ? .8 * o, h = c.fontBoundingBoxDescent ? ? .2 * o, m = 115.57 * s + (.8 * o - (d + h)) / 2 + d, e.fillText("ARC", r / 2 - 10.16 * s, m), e.globalCompositeOperation = "source-over")
            }).catch(() => {}), () => {
                t = !1
            }
        }, [e]), (0, a.useEffect)(() => {
            let e = q.current,
                t = e ? .closest(".vhs-about");
            if (!e || !t || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
            let a = 0,
                s = 0,
                i = 0,
                n = 0,
                r = 0,
                o = 0,
                c = t.scrollTop,
                h = null,
                m = 0,
                u = 0,
                S = !1,
                E = {
                    x: 0,
                    y: 0
                },
                A = {
                    x: 0,
                    y: 0
                },
                L = t => {
                    let o = Math.min(.1, (t - n) / 1e3);
                    n = t;
                    let c = 1 - Math.exp(-6 * o);
                    E = {
                        x: E.x + (A.x - E.x) * c,
                        y: E.y + (A.y - E.y) * c
                    };
                    let d = Math.abs(A.x - E.x) > .02 || Math.abs(A.y - E.y) > .02,
                        h = (0, l.springTo)(a, s, i, o, S ? y : x);
                    a = h.x, s = h.v, .05 > Math.abs(i - a) && .5 > Math.abs(s) && (a = i, s = 0), e.style.transform = `rotateX(${E.y.toFixed(2)}deg) rotateY(${(a+E.x).toFixed(2)}deg)`, r = a !== i || d ? requestAnimationFrame(L) : 0
                },
                k = () => {
                    r || (n = performance.now(), r = requestAnimationFrame(L))
                },
                R = e => {
                    if (e) {
                        if (T(!1), i += e, window.clearTimeout(o), null !== h) return k();
                        o = window.setTimeout(() => {
                            S = !1, i = 360 * Math.round(i / 360), k()
                        }, M), k()
                    }
                },
                N = null,
                C = !1,
                P = t => {
                    !(t.button > 0) && t.target instanceof Node && e.contains(t.target) && (N = {
                        x: t.clientX,
                        moved: 0
                    })
                },
                $ = e => {
                    if (!N) return;
                    let t = e.clientX - N.x;
                    N.x = e.clientX, N.moved += Math.abs(t), N.moved > g && R(t * w)
                },
                F = () => {
                    N && N.moved > g && (C = !0, window.setTimeout(() => C = !1, 0)), N = null
                },
                B = e => {
                    C && (C = !1, e.preventDefault(), e.stopPropagation())
                },
                D = e => {
                    S = !1, R((Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX) * v)
                },
                I = () => {
                    R((t.scrollTop - c) * v), c = t.scrollTop
                },
                W = e => {
                    h = e.touches[0].clientY, m = 0, u = performance.now(), null !== h && (S = !0)
                },
                H = e => {
                    if (null === h) return;
                    let t = e.touches[0].clientY,
                        a = h - t;
                    R(a * b);
                    let s = performance.now();
                    m = .6 * m + a / Math.max(8, s - u) * 400, u = s, h = t
                },
                O = () => {
                    if (null === h) return;
                    h = null;
                    let e = performance.now() - u < 80 ? m * j * b : 0;
                    e ? R(e) : (i = 360 * Math.round(i / 360), S = !1, k())
                };
            window.addEventListener("wheel", D, {
                passive: !0
            });
            let X = (0, d.onTilt)((e, t) => {
                A = {
                    x: e * f,
                    y: t * p
                }, k()
            });
            return e.addEventListener("pointerdown", P), window.addEventListener("pointermove", $), window.addEventListener("pointerup", F), window.addEventListener("pointercancel", F), e.addEventListener("click", B, !0), t.addEventListener("scroll", I, {
                passive: !0
            }), t.addEventListener("touchstart", W, {
                passive: !0
            }), t.addEventListener("touchmove", H, {
                passive: !0
            }), t.addEventListener("touchend", O), () => {
                window.removeEventListener("wheel", D), X(), e.removeEventListener("pointerdown", P), window.removeEventListener("pointermove", $), window.removeEventListener("pointerup", F), window.removeEventListener("pointercancel", F), e.removeEventListener("click", B, !0), t.removeEventListener("scroll", I), t.removeEventListener("touchstart", W), t.removeEventListener("touchmove", H), t.removeEventListener("touchend", O), window.clearTimeout(o), cancelAnimationFrame(r)
            }
        }, []);
        let [B, D] = (0, a.useState)(!1);
        (0, a.useEffect)(() => (0, c.afterFirstPaint)(() => D((0, o.can3D)())), []);
        let I = (0, a.useId)();
        return (0, t.jsx)("div", {
            className: "vhs-sleeve",
            "data-out": C || void 0,
            children: (0, t.jsxs)("div", {
                ref: q,
                className: "sleeve-spin",
                children: [(0, t.jsx)("div", {
                    className: "sleeve-tape",
                    "aria-hidden": !0,
                    children: B && (0, t.jsx)(h, {
                        out: C,
                        portrait: e
                    })
                }), (0, t.jsxs)("button", {
                    type: "button",
                    className: "sleeve-cover",
                    "aria-pressed": C,
                    "aria-describedby": I,
                    onClick: () => T(e => !e),
                    children: [(0, t.jsx)("span", {
                        id: I,
                        className: "sr-only",
                        children: C ? "Pushes the tape back in" : "Pulls the tape out"
                    }), (0, t.jsx)("canvas", {
                        ref: P,
                        className: "sleeve-print",
                        width: 2 * u.w,
                        height: 2 * u.h
                    }), (0, t.jsx)(E, {}), (0, t.jsx)("img", {
                        className: "sleeve-vhs",
                        src: "/about/cover-vhs.svg",
                        width: 71,
                        height: 38,
                        alt: ""
                    }), (0, t.jsx)("span", {
                        className: "sleeve-date",
                        children: s
                    }), (0, t.jsx)("img", {
                        className: "sleeve-mpa",
                        src: "/about/cover-mpa.svg",
                        width: 139,
                        height: 99,
                        alt: ""
                    }), (0, t.jsx)("canvas", {
                        ref: $,
                        className: "sleeve-wear",
                        width: 2 * u.w,
                        height: 2 * u.h
                    })]
                }), (0, t.jsxs)("div", {
                    className: "sleeve-back",
                    "aria-hidden": !0,
                    children: [(0, t.jsx)(E, {}), (0, t.jsx)("span", {
                        className: "back-title",
                        children: "Now Playing"
                    }), (0, t.jsx)("span", {
                        className: "back-stills",
                        children: S.map(e => (0, t.jsx)("img", {
                            src: e,
                            width: 170,
                            height: 112,
                            alt: ""
                        }, e))
                    }), (0, t.jsxs)("span", {
                        className: "back-block is-starring",
                        children: [(0, t.jsx)("span", {
                            className: "back-label",
                            children: "Starring"
                        }), i.join(" · ")]
                    }), (0, t.jsxs)("span", {
                        className: "back-block is-honours",
                        children: [(0, t.jsx)("span", {
                            className: "back-label",
                            children: "Honours"
                        }), A.join(" · ")]
                    }), (0, t.jsx)("span", {
                        className: "back-sticker",
                        children: N
                    }), (0, t.jsxs)("span", {
                        className: "back-credits",
                        children: ["Arc Home Video presents an Arc production · starring ", i.join(", "), " · design and development Arc · now at ", R.join(", "), " · © 2026 Arc Home Video · all rights reserved · unauthorised duplication, hire or broadcast of this portfolio is not permitted"]
                    }), (0, t.jsx)(L, {}), (0, t.jsxs)("span", {
                        className: "back-specs",
                        children: [(0, t.jsx)("span", {
                            children: "Colour"
                        }), (0, t.jsx)("span", {
                            children: "Hi-Fi Stereo"
                        }), (0, t.jsx)("span", {
                            children: "PAL"
                        })]
                    }), (0, t.jsx)("img", {
                        className: "back-vhs",
                        src: "/about/cover-vhs.svg",
                        width: 71,
                        height: 38,
                        alt: ""
                    }), (0, t.jsx)("canvas", {
                        ref: F,
                        className: "sleeve-wear",
                        width: 2 * u.w,
                        height: 2 * u.h
                    })]
                }), (0, t.jsx)("span", {
                    className: "sleeve-side is-left",
                    "aria-hidden": !0,
                    children: (0, t.jsx)("span", {
                        children: "Arc · Home Video"
                    })
                }), (0, t.jsx)("span", {
                    className: "sleeve-side is-right",
                    "aria-hidden": !0,
                    children: (0, t.jsx)("span", {
                        children: "Arc · Home Video"
                    })
                })]
            })
        })
    }
    let u = {
            w: 572,
            h: 863
        },
        f = 16,
        p = 10,
        v = .75,
        w = .6,
        g = 5,
        x = 12,
        b = 1.2,
        y = 26,
        j = .3,
        M = 160,
        S = ["/about/still-depthfirst.webp", "/about/still-makereign.webp", "/about/still-remyshoots.webp"];

    function E() {
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)("span", {
                className: "sleeve-rule is-top"
            }), (0, t.jsx)("span", {
                className: "sleeve-rule is-bottom"
            }), (0, t.jsx)("img", {
                className: "sleeve-mark",
                src: "/about/cover-arc-mark.svg",
                width: 46,
                height: 12,
                alt: ""
            }), (0, t.jsx)("span", {
                className: "sleeve-home",
                children: "Home Video"
            })]
        })
    }
    let A = (() => {
        let e = 2026,
            t = () => (e = 16807 * e % 0x7fffffff) / 0x7fffffff,
            a = [];
        for (let e = 2; e < 96;) {
            let s = .6 + .6 * Math.floor(3 * t());
            a.push({
                x: e,
                w: s
            }), e += s + .6 + .6 * Math.floor(2 * t())
        }
        return a
    })();

    function L() {
        return (0, t.jsxs)("span", {
            className: "back-barcode",
            children: [(0, t.jsxs)("svg", {
                viewBox: "0 0 98 40",
                preserveAspectRatio: "none",
                "aria-hidden": !0,
                children: [(0, t.jsx)("rect", {
                    width: "98",
                    height: "40",
                    fill: "#fff"
                }), A.map(e => (0, t.jsx)("rect", {
                    x: e.x,
                    y: 3,
                    width: e.w,
                    height: 28,
                    fill: "#000"
                }, e.x))]
            }), (0, t.jsx)("span", {
                children: "0 26 1997 0308 4"
            })]
        })
    }
    let k = null,
        R = {
            "awwwards jury": {
                src: "/certificates/awwwards-jury-2026.webp",
                width: 720,
                height: 960,
                alt: "Awwwards Jury 2026 certificate for Arc Marumo"
            },
            "awwwards honorable mention": {
                src: "/certificates/awwwards-honors-remyshoots.webp",
                width: 720,
                height: 955,
                alt: "Awwwards Honors certificate for RemyShoots, by Arc Marumo, 12 September 2026"
            },
            "cssda website of the day": {
                src: "/certificates/cssda-website-of-the-day-arcmarumo.webp",
                width: 720,
                height: 1018,
                alt: "CSS Design Awards Website of the Day certificate, awarded to Arc Marumo, 22 October 2026"
            },
            "cssda special kudos": {
                src: "/certificates/cssda-special-kudos-remyshoots.webp",
                width: 720,
                height: 1018,
                alt: "CSS Design Awards Special Kudos certificate for RemyShoots, awarded to Arc Marumo, 8 September 2026"
            },
            "cssda best ui design": {
                src: "/certificates/cssda-best-ui-remyshoots.webp",
                width: 720,
                height: 1018,
                alt: "CSS Design Awards Best UI Design certificate for RemyShoots, awarded to Arc Marumo, 8 September 2026"
            },
            "cssda best ux design": {
                src: "/certificates/cssda-best-ux-remyshoots.webp",
                width: 720,
                height: 1018,
                alt: "CSS Design Awards Best UX Design certificate for RemyShoots, awarded to Arc Marumo, 8 September 2026"
            },
            "cssda best innovation": {
                src: "/certificates/cssda-best-innovation-remyshoots.webp",
                width: 720,
                height: 1018,
                alt: "CSS Design Awards Best Innovation certificate for RemyShoots, awarded to Arc Marumo, 8 September 2026"
            }
        },
        N = e => R[e.trim().toLowerCase().replace(/\s+x\d+$/, "")];
    var C = e.i(306257);

    function T() {
        let e = (0, a.useRef)(null);
        return (0, a.useEffect)(() => {
            let t = e.current,
                a = t ? .closest(".vhs-about"),
                s = t ? .getContext("2d");
            if (!t || !a || !s) return;
            let i = window.matchMedia("(hover: hover) and (pointer: fine) and (min-width: 1025px)"),
                n = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                r = new Map,
                l = e => {
                    let t = r.get(e);
                    return t || ((t = new Image).decoding = "async", t.src = e, r.set(e, t)), t
                };
            a.querySelectorAll("[data-cert]").forEach(e => {
                let t = N(e.dataset.cert ? ? "");
                t && i.matches && l(t.src)
            });
            let o = null,
                c = null,
                d = !1,
                h = !1,
                m = 0,
                u = null,
                f = 0,
                p = 0,
                v = 0,
                w = e => {
                    if (t.classList.remove("is-in", "is-out"), !e || n) {
                        "is-in" === e && t.classList.add("is-in");
                        return
                    }
                    t.offsetWidth, t.classList.add(e)
                },
                g = () => {
                    if (!o) return null;
                    let e = (0, C.unbendPoint)(o.x, o.y, a.getBoundingClientRect()),
                        t = document.elementFromPoint(e.x, e.y) ? .closest("[data-cert]"),
                        s = t && a.contains(t) ? N(t.dataset.cert ? ? "") : void 0;
                    return s ? {
                        img: l(s.src),
                        flat: e
                    } : null
                },
                x = e => {
                    let i = p ? Math.min(.05, (e - p) / 1e3) : 0;
                    p = e, v += i;
                    let r = g();
                    d = !!r && r.img === c && h && !m, m && e >= m && (m = 0, h = !1, w(null)), r && !h ? (c = r.img, h = !0, d = !0, u = null, w("is-in")) : !h || m || d || (m = e + 360 * !n, w("is-out"));
                    let l = a.getBoundingClientRect(),
                        o = Math.round(Math.min(300, Math.max(200, .17 * l.width))),
                        b = c,
                        y = b ? .naturalWidth ? Math.round(o * b.naturalHeight / b.naturalWidth) : Math.round(1.33 * o),
                        j = Math.ceil(.045 * y * 2.6) + 4,
                        M = o + 16,
                        S = y + 2 * j;
                    if (r) {
                        let e = {
                            x: Math.min(l.width - M - 8, Math.max(8, r.flat.x - l.left - M / 2)),
                            y: Math.min(l.height - S - 8, Math.max(8, r.flat.y - l.top - S - 12))
                        };
                        if (u) {
                            let t = 1 - Math.exp(-14 * i);
                            u = {
                                x: u.x + (e.x - u.x) * t,
                                y: u.y + (e.y - u.y) * t
                            }
                        } else u = e
                    }
                    let E = Math.min(2, window.devicePixelRatio || 1);
                    if ((t.width !== Math.round(M * E) || t.height !== Math.round(S * E)) && (t.width = Math.round(M * E), t.height = Math.round(S * E), t.style.width = `${M}px`, t.style.height = `${S}px`), u && (t.style.translate = `${u.x}px ${u.y}px`), s.setTransform(E, 0, 0, E, 0, 0), s.clearRect(0, 0, M, S), b ? .complete && b.naturalWidth && h) {
                        let e = n ? 0 : .045 * y,
                            t = 2 * Math.PI / (.62 * o),
                            a = b.naturalWidth / o;
                        for (let i = 0; i < o; i += 2) {
                            let n = Math.min(2, o - i),
                                r = i / o,
                                l = t * i - 4.2 * v,
                                c = e * r * Math.sin(l),
                                d = e * (r * t * Math.cos(l) + Math.sin(l) / o),
                                h = j + c;
                            s.drawImage(b, i * a, 0, n * a, b.naturalHeight, 8 + i, h, n + .6, y);
                            let m = Math.max(-.22, Math.min(.22, -(.9 * d)));
                            m && (s.fillStyle = m > 0 ? `rgba(255,255,255,${m})` : `rgba(0,0,0,${-(1.25*m)})`, s.fillRect(8 + i, h, n + .6, y))
                        }
                    }
                    h || r ? f = requestAnimationFrame(x) : (f = 0, p = 0, u = null)
                },
                b = () => {
                    f || (f = requestAnimationFrame(x))
                },
                y = e => {
                    "mouse" === e.pointerType && i.matches && (o = {
                        x: e.clientX,
                        y: e.clientY
                    }, (f || g()) && b())
                },
                j = () => {
                    o = null
                },
                M = () => {
                    o && i.matches && b()
                };
            return window.addEventListener("pointermove", y, {
                passive: !0
            }), document.documentElement.addEventListener("pointerleave", j), window.addEventListener("wheel", M, {
                passive: !0
            }), () => {
                cancelAnimationFrame(f), window.removeEventListener("pointermove", y), document.documentElement.removeEventListener("pointerleave", j), window.removeEventListener("wheel", M)
            }
        }, []), (0, t.jsx)("canvas", {
            ref: e,
            className: "vhs-cert",
            "aria-hidden": !0
        })
    }
    let P = {
        "$80m client series b": "https://depthfirst.com/post/series-b-announcement",
        "$3m client investment": "https://traded.co/vc/deal/rumor-secures-3-million-investment-from-pete-davidson-and-others-for-event-platform-expansion/"
    };

    function $({
        about: e
    }) {
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)("div", {
                className: "vhs-about-introblock",
                children: (0, t.jsx)("p", {
                    children: (0, t.jsx)(s.Reveal, {
                        i: 1,
                        children: e.intro
                    })
                })
            }), (0, t.jsxs)("div", {
                className: "vhs-about-pair",
                children: [(0, t.jsx)(F, {
                    label: "Engagements",
                    side: "left",
                    items: e.engagements.map(e => ({
                        key: e,
                        node: e
                    }))
                }), (0, t.jsx)(F, {
                    label: "Achievements",
                    side: "right",
                    items: e.achievements.map(e => ({
                        key: e,
                        node: (0, t.jsx)(q, {
                            line: e
                        })
                    }))
                })]
            }), (0, t.jsxs)("div", {
                className: "vhs-about-pair",
                children: [(0, t.jsx)(F, {
                    label: "History",
                    side: "left",
                    className: "is-history",
                    items: e.history.map(e => ({
                        key: e.label,
                        node: (0, t.jsxs)("span", {
                            className: "vhs-about-role",
                            children: [(0, t.jsx)("span", {
                                children: e.label
                            }), (0, t.jsx)("span", {
                                className: "vhs-about-leader",
                                "aria-hidden": !0
                            }), (0, t.jsx)("span", {
                                children: e.years
                            })]
                        })
                    }))
                }), (0, t.jsx)(F, {
                    label: "Socials",
                    side: "right",
                    items: e.socials.map(e => ({
                        key: e.label,
                        node: (0, t.jsx)(B, {
                            social: e
                        })
                    }))
                })]
            })]
        })
    }

    function F({
        label: e,
        side: a,
        items: i,
        className: n
    }) {
        return (0, t.jsxs)("section", {
            className: `vhs-about-col${n?` ${n}`:""}`,
            "data-side": a,
            children: [(0, t.jsx)("h2", {
                className: "vhs-about-line",
                children: (0, t.jsxs)(s.Reveal, {
                    i: 0,
                    children: ["[", e, "]"]
                })
            }), (0, t.jsx)("ul", {
                children: i.map((e, a) => (0, t.jsx)("li", {
                    className: "vhs-about-line",
                    children: (0, t.jsx)(s.Reveal, {
                        i: a + 1,
                        children: e.node
                    })
                }, e.key))
            })]
        })
    }

    function q({
        line: e
    }) {
        let a = P[e.trim().toLowerCase()];
        return a ? (0, t.jsxs)("a", {
            href: a,
            target: "_blank",
            rel: "noopener noreferrer",
            children: [e, (0, t.jsx)(s.LinkArrow, {})]
        }) : N(e) ? (0, t.jsx)("span", {
            "data-cert": e,
            children: e
        }) : (0, t.jsx)(t.Fragment, {
            children: e
        })
    }

    function B({
        social: e
    }) {
        return e.href ? e.href.startsWith("mailto:") ? (0, t.jsx)(s.ContactLink, {
            label: e.label,
            email: e.href.slice(7),
            arrow: !0
        }) : (0, t.jsxs)("a", {
            href: e.href,
            target: "_blank",
            rel: "noopener noreferrer",
            children: [e.label, (0, t.jsx)(s.LinkArrow, {})]
        }) : (0, t.jsx)(t.Fragment, {
            children: e.label
        })
    }
    e.s(["default", 0, function({
        about: e
    }) {
        let s, i = (s = (0, a.useRef)(null), (0, a.useEffect)(() => {
                let e = s.current,
                    t = e ? .closest(".vhs-about");
                if (!e || !t) return;
                let a = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                    i = 0,
                    n = 0,
                    r = 0,
                    o = 0,
                    c = 0,
                    d = null,
                    h = 0,
                    m = 0,
                    u = 1,
                    f = t.querySelector(".vhs-sleeve"),
                    p = {
                        l: 0,
                        r: 0,
                        top: 0,
                        h: 0,
                        w: 0
                    },
                    v = 0,
                    w = 1,
                    g = [],
                    x = () => {
                        e.style.transform = "", f && (f.style.translate = "", f.style.scale = "");
                        let a = [...e.querySelectorAll(".vhs-about-line")];
                        a.forEach(e => e.style.transform = "");
                        let s = t.getBoundingClientRect(),
                            i = t.querySelector(".vhs-sleeve") ? .getBoundingClientRect();
                        if (i && (i.left - s.left, i.right - s.left, i.top - s.top + i.height / 2, i.height / 2, i.width, i.height), i) {
                            p = {
                                l: i.left - s.left,
                                r: i.right - s.left,
                                top: i.top - s.top,
                                h: i.height,
                                w: i.width
                            };
                            let e = document.querySelector(".vhs-head"),
                                t = e ? Math.max(e.getBoundingClientRect().bottom, ...[...e.querySelectorAll("*")].map(e => e.getBoundingClientRect().bottom)) : 0;
                            v = (e ? t - s.top : 0) + 12 - p.top
                        }
                        w = Math.max(1, .55 * s.height), u = e.firstElementChild ? .offsetHeight || 1, g = a.map(e => {
                            let t = e.getBoundingClientRect();
                            return {
                                el: e,
                                x: t.left - s.left,
                                y: t.top - s.top,
                                w: t.width,
                                h: t.height,
                                left: e.closest("[data-side]") ? .getAttribute("data-side") === "left"
                            }
                        }), b()
                    },
                    b = () => {
                        let t = (i % u + u) % u;
                        e.style.transform = `translate3d(0, ${-t}px, 0)`;
                        let a = e => e * e * (3 - 2 * e),
                            s = a(Math.min(1, Math.abs(i) / w)),
                            n = .4 + .6 * s,
                            r = v * (1 - s);
                        f && (f.style.translate = s < 1 ? `0 ${r.toFixed(1)}px` : "", f.style.scale = s < 1 ? n.toFixed(4) : "");
                        let l = p.w * n,
                            o = p.h * n,
                            c = (p.l + p.r) / 2,
                            {
                                l: d,
                                r: h,
                                cy: m,
                                half: x,
                                gap: b,
                                feather: y
                            } = {
                                l: c - l / 2,
                                r: c + l / 2,
                                cy: p.top + r + o / 2,
                                half: o / 2,
                                gap: .07 * l,
                                feather: .22 * o
                            };
                        for (let e of g) {
                            let s = a(Math.min(1, Math.max(0, (x + y - Math.abs(e.y - t + e.h / 2 - m)) / y))),
                                i = ((e.left ? d - b - e.w : h + b) - e.x) * s;
                            e.el.style.transform = s ? `translate3d(${i.toFixed(1)}px, 0, 0)` : ""
                        }
                    },
                    y = e => {
                        let t = Math.min(.1, (e - o) / 1e3);
                        o = e;
                        let a = (0, l.springTo)(i, n, r, t);
                        i = a.x, n = a.v, .1 > Math.abs(r - i) && 1 > Math.abs(n) && (i = r, n = 0), b(), c = i !== r ? requestAnimationFrame(y) : 0
                    },
                    j = e => {
                        e && (r += +e, a ? (i = r, b()) : c || (o = performance.now(), c = requestAnimationFrame(y)))
                    },
                    M = e => {
                        let t = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
                        j(1 === e.deltaMode ? 16 * t : t)
                    },
                    S = e => {
                        d = e.touches[0].clientY, h = 0, m = performance.now()
                    },
                    E = e => {
                        if (null === d) return;
                        let t = e.touches[0].clientY,
                            a = performance.now();
                        h = .6 * h + (d - t) / Math.max(8, a - m) * 400, m = a, j(d - t), d = t
                    },
                    A = () => {
                        null !== d && performance.now() - m < 80 && j(.325 * h), d = null
                    };
                x();
                let L = window.setTimeout(x, 1100);
                document.fonts ? .ready.then(x).catch(() => {});
                let k = new ResizeObserver(() => x());
                return k.observe(t), window.addEventListener("wheel", M, {
                    passive: !0
                }), t.addEventListener("touchstart", S, {
                    passive: !0
                }), t.addEventListener("touchmove", E, {
                    passive: !0
                }), t.addEventListener("touchend", A), () => {
                    window.clearTimeout(L), k.disconnect(), window.removeEventListener("wheel", M), t.removeEventListener("touchstart", S), t.removeEventListener("touchmove", E), t.removeEventListener("touchend", A), cancelAnimationFrame(c)
                }
            }, []), s),
            n = (0, a.useRef)(null);
        return (0, C.useBend)(n), (0, t.jsxs)("section", {
            ref: n,
            className: "vhs-about",
            "aria-label": "Profile",
            children: [(0, t.jsx)("div", {
                className: "vhs-about-text",
                children: (0, t.jsx)("div", {
                    ref: i,
                    className: "vhs-about-reel",
                    children: Array.from({
                        length: 3
                    }, (a, s) => (0, t.jsx)("div", {
                        className: `vhs-about-loop${s?" is-copy":""}`,
                        "aria-hidden": !!s || void 0,
                        inert: s > 0,
                        children: (0, t.jsx)($, {
                            about: e
                        })
                    }, s))
                })
            }), (0, t.jsx)(m, {
                portrait: e.portrait.src,
                date: e.date,
                engagements: e.engagements,
                achievements: e.achievements,
                currently: e.currently,
                availability: e.availability
            }), (0, t.jsx)(T, {})]
        })
    }], 733247)
}, 466552, e => {
    e.v(t => Promise.all(["static/immutable/chunks/16a9xs3qtz5ns.js", "static/immutable/chunks/37n3r0zuw47_4.js", "static/immutable/chunks/0qxtffwpvg0u2.js"].map(t => e.l(t))).then(() => t(79313)))
}, 599109, e => {
    "use strict";
    let t = null;
    e.s(["drawWear", 0, function(e, a, s, i = 20260) {
        let n = i,
            r = () => (n = 16807 * n % 0x7fffffff) / 0x7fffffff,
            l = e => `rgba(238,232,218,${e})`;
        e.fillStyle = "rgba(190,160,110,0.07)", e.fillRect(0, 0, a, s);
        let o = e.createRadialGradient(a / 2, s / 2, .3 * s, a / 2, s / 2, .75 * s);
        o.addColorStop(0, "rgba(0,0,0,0)"), o.addColorStop(1, "rgba(10,6,2,0.35)"), e.fillStyle = o, e.fillRect(0, 0, a, s);
        for (let t = 0; t < 7; t++) {
            let t = r() * a,
                i = r() * s,
                n = 60 + 180 * r(),
                l = e.createRadialGradient(t, i, 0, t, i, n);
            l.addColorStop(0, `rgba(40,28,14,${.06+.08*r()})`), l.addColorStop(1, "rgba(40,28,14,0)"), e.fillStyle = l, e.fillRect(t - n, i - n, 2 * n, 2 * n)
        }
        let c = (t, a, s) => {
            for (let i = 0; i < t; i += 2 + 5 * r()) {
                .12 > r() && (i += 60 * r());
                let t = r() ** 2.2 * 26,
                    [n, o] = a(i, t),
                    c = 1.5 + r() * (t < 6 ? 7 : 3.5),
                    d = .8 + 2.2 * r();
                e.fillStyle = l(t < 5 ? .55 + .4 * r() : .2 + .35 * r()), e.beginPath(), e.ellipse(n, o, s ? d : c, s ? c : d, (r() - .5) * .6, 0, 2 * Math.PI), e.fill()
            }
        };
        for (let [t, i, n, o] of (c(a, (e, t) => [e, 4 + t], !1), c(a, (e, t) => [e, s - 4 - t], !1), c(s, (e, t) => [4 + t, e], !0), c(s, (e, t) => [a - 4 - t, e], !0), e.strokeStyle = l(.55), e.lineWidth = 2.5, e.setLineDash([]), e.beginPath(), [
                [7, 7, a - 7, 7],
                [a - 7, 7, a - 7, s - 7],
                [a - 7, s - 7, 7, s - 7],
                [7, s - 7, 7, 7]
            ]))
            for (let a = 0; a < 40; a++) {
                if (.35 > r()) continue;
                let s = a / 40,
                    l = (a + .4 + .6 * r()) / 40,
                    c = () => (r() - .5) * 3;
                e.moveTo(t + (n - t) * s + c(), i + (o - i) * s + c()), e.lineTo(t + (n - t) * l + c(), i + (o - i) * l + c())
            }
        for (let [t, i] of (e.stroke(), [
                [0, 0],
                [a, 0],
                [0, s],
                [a, s]
            ])) {
            let a = 40 + 50 * r(),
                s = e.createRadialGradient(t, i, 0, t, i, a);
            s.addColorStop(0, l(.85)), s.addColorStop(.45, l(.35)), s.addColorStop(1, l(0)), e.fillStyle = s, e.fillRect(t - a, i - a, 2 * a, 2 * a);
            for (let s = 0; s < 40; s++) {
                let s = r() * Math.PI * 2,
                    n = r() ** 1.5 * a * 1.3;
                e.fillStyle = l(.3 + .5 * r()), e.fillRect(t + Math.cos(s) * n, i + Math.sin(s) * n, 1 + 4 * r(), 1 + 3 * r())
            }
        }
        for (let t = 0; t < 4; t++) {
            let t = .5 > r(),
                i = t ? 0 : a * (.3 + .7 * r()),
                n = t ? s * r() : 0,
                o = t ? (r() - .5) * .9 : Math.PI / 2 + (r() - .5) * .9,
                c = 90 + 260 * r(),
                d = i + Math.cos(o) * c,
                h = n + Math.sin(o) * c,
                m = (i + d) / 2 + (r() - .5) * 30,
                u = (n + h) / 2 + (r() - .5) * 30;
            e.lineCap = "round", e.strokeStyle = "rgba(0,0,0,0.28)", e.lineWidth = 2.2, e.beginPath(), e.moveTo(i + 1.5, n + 1.5), e.quadraticCurveTo(m + 1.5, u + 1.5, d + 1.5, h + 1.5), e.stroke(), e.strokeStyle = l(.32), e.lineWidth = 1.4, e.beginPath(), e.moveTo(i, n), e.quadraticCurveTo(m, u, d, h), e.stroke()
        }
        for (let t = 0; t < 38; t++) {
            let t = r() * a,
                i = r() * s,
                n = r() * Math.PI,
                l = 20 + 180 * r();
            e.strokeStyle = `rgba(255,252,244,${.08+.22*r()})`, e.lineWidth = .5 + r(), e.beginPath(), e.moveTo(t, i), e.quadraticCurveTo(t + Math.cos(n) * l * .5 + (r() - .5) * 16, i + Math.sin(n) * l * .5 + (r() - .5) * 16, t + Math.cos(n) * l, i + Math.sin(n) * l), e.stroke()
        } {
            let t = .66 * a,
                i = .19 * s;
            e.save(), e.translate(t, i), e.rotate(-.05), e.beginPath(), e.moveTo(0, 0);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 * t, (r() - .5) * 4);
            for (let t = 0; t <= 1; t += .1) e.lineTo(120 + (r() - .5) * 6, 64 * t);
            for (let t = 1; t >= 0; t -= .1) e.lineTo(120 * t, 64 + (r() - .5) * 8);
            for (let t = 1; t >= 0; t -= .1) e.lineTo((r() - .5) * 4, 64 * t);
            e.closePath(), e.fillStyle = "rgba(235,225,200,0.13)", e.fill();
            for (let t = 0; t < 12; t++) e.fillStyle = l(.35 + .4 * r()), e.fillRect(120 * r(), 64 * r(), 3 + 22 * r(), 2 + 5 * r());
            e.restore()
        }
        let d = e.createPattern(function() {
            if (t) return t;
            (t = document.createElement("canvas")).width = t.height = 256;
            let e = t.getContext("2d"),
                a = 9001,
                s = () => (a = 16807 * a % 0x7fffffff) / 0x7fffffff;
            for (let t = 0; t < 520; t++) {
                let t = 255 * (s() > .5);
                e.fillStyle = `rgba(${t},${t},${t},${.02+.06*s()})`, e.fillRect(256 * s(), 256 * s(), 1 + 1.6 * s(), 1 + 1.6 * s())
            }
            return t
        }(), "repeat");
        d && (e.save(), e.translate(-Math.floor(256 * r()), -Math.floor(256 * r())), e.fillStyle = d, e.fillRect(0, 0, a + 256, s + 256), e.restore())
    }])
}, 592563, e => {
    "use strict";
    e.s(["fontFamily", 0, function(e, t) {
        if ("u" < typeof document) return t;
        let a = getComputedStyle(document.body).getPropertyValue(e).trim();
        return a ? `${a}, ${t}` : t
    }])
}, 82396, e => {
    "use strict";
    let t = new Set,
        a = !1,
        s = null,
        i = 0,
        n = e => Math.max(-1, Math.min(1, e));

    function r(e) {
        if (null == e.beta || null == e.gamma) return;
        let a = screen.orientation ? .angle ? ? 0,
            r = e.beta,
            l = e.gamma;
        90 === a ? [r, l] = [-e.gamma, e.beta] : (270 === a || -90 === a) && ([r, l] = [e.gamma, -e.beta]);
        let o = performance.now();
        if (!s) {
            s = {
                beta: r,
                gamma: l
            }, i = o;
            return
        }
        let c = Math.min(.1, (o - i) / 1e3);
        i = o;
        let d = 1 - Math.exp(-.25 * c);
        s.beta += (r - s.beta) * d, s.gamma += (l - s.gamma) * d;
        let h = n((l - s.gamma) / 18),
            m = n(-(r - s.beta) / 18);
        t.forEach(e => e(h, m))
    }

    function l() {
        window.addEventListener("deviceorientation", r, !0)
    }
    e.s(["onTilt", 0, function(e) {
        return ! function() {
            if (a || (a = !0, !window.matchMedia("(pointer: coarse)").matches || !("DeviceOrientationEvent" in window))) return;
            let e = window.DeviceOrientationEvent;
            if ("function" != typeof e.requestPermission) return l();
            let t = () => {
                window.removeEventListener("touchend", t), e.requestPermission().then(e => "granted" === e && l()).catch(() => {})
            };
            e.requestPermission().then(e => "granted" === e ? l() : window.addEventListener("touchend", t, {
                passive: !0
            })).catch(() => window.addEventListener("touchend", t, {
                passive: !0
            }))
        }(), t.add(e), () => {
            t.delete(e)
        }
    }])
}]);