(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 745850, 495634, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["REVEAL_STAGGER_MS", 0, 70, "useIntro", 0, function(e, t, n = !0) {
        let [a, s] = (0, r.useState)(0), [i, o] = (0, r.useState)(!1), [l, u] = (0, r.useState)(!1), c = (0, r.useRef)(0), d = (0, r.useRef)(!1), f = (0, r.useRef)(t);
        return (0, r.useEffect)(() => {
            f.current = t
        }, [t]), (0, r.useEffect)(() => {
            if (!n) return;
            let e = window.setTimeout(() => o(!0), 220);
            return () => window.clearTimeout(e)
        }, [n]), (0, r.useEffect)(() => {
            if (!i) return;
            let e = window.setTimeout(() => {
                d.current = !0, f.current && u(!0)
            }, 1170);
            return () => window.clearTimeout(e)
        }, [i]), (0, r.useEffect)(() => {
            t && d.current && u(!0)
        }, [t]), (0, r.useEffect)(() => {
            let r = 0,
                n = performance.now(),
                a = () => {
                    let i = performance.now(),
                        o = Math.min(.25, (i - n) / 1e3);
                    n = i;
                    let l = 1 - Math.exp(-7 * o),
                        u = t ? 26 : Math.min(26 * e, 25);
                    c.current += (u - c.current) * l, t && 26 - c.current < .35 && (c.current = 26);
                    let d = Math.max(0, Math.round(c.current));
                    s(e => d > e ? d : e), t && 26 === c.current || (r = requestAnimationFrame(a))
                };
            return r = requestAnimationFrame(a), () => cancelAnimationFrame(r)
        }, [e, t]), {
            year: a,
            textIn: i,
            spiralIn: l
        }
    }], 495634);
    var n = e.i(306257),
        a = e.i(58685);
    let s = "hello@arcmarumo.com";

    function i() {
        return (0, t.jsxs)(t.Fragment, {
            children: ["[", (0, t.jsx)("span", {
                className: "pj-live-arrow",
                "aria-hidden": !0,
                children: "←"
            }), "]"]
        })
    }

    function o(e) {
        return window.addEventListener("bwchange", e), () => window.removeEventListener("bwchange", e)
    }
    e.s(["BwToggle", 0, function() {
        let e = (0, r.useSyncExternalStore)(o, () => document.documentElement.classList.contains("bw"), () => !1);
        return (0, t.jsxs)("button", {
            type: "button",
            role: "switch",
            "aria-checked": e,
            className: "vhs-bw-toggle",
            onClick: () => {
                let t = !e;
                document.documentElement.classList.toggle("bw", t);
                try {
                    localStorage.setItem("bw", t ? "1" : "0")
                } catch {}
                window.dispatchEvent(new Event("bwchange"))
            },
            children: ["B&W ", (0, t.jsxs)("span", {
                "aria-hidden": !0,
                children: ["[", e ? "ON" : "OFF", "]"]
            })]
        })
    }, "CONTACT_EMAIL", 0, s, "ContactLink", 0, function({
        label: e = "Contact",
        copiedLabel: n = "Copied",
        email: a = s,
        arrow: o = !1
    }) {
        let [l, u] = (0, r.useState)(!1);
        return (0, t.jsxs)("a", {
            href: `mailto:${a}`,
            onClick: () => {
                navigator.clipboard ? .writeText(a).then(() => {
                    u(!0), window.setTimeout(() => u(!1), 1600)
                }).catch(() => {})
            },
            "aria-live": "polite",
            children: [l ? n : e, o && (0, t.jsx)(i, {})]
        })
    }, "CrtLines", 0, function() {
        let e = (0, r.useRef)(null);
        return (0, r.useEffect)(() => {
            let t = e.current,
                r = t ? .getContext("2d");
            if (!t || !r) return;
            let a = () => {
                let e = Math.min(2, window.devicePixelRatio || 1),
                    a = t.clientWidth,
                    s = t.clientHeight;
                if (!a || !s) return;
                t.width = Math.round(a * e), t.height = Math.round(s * e), r.setTransform(e, 0, 0, e, 0, 0), r.clearRect(0, 0, a, s);
                let i = a / 2,
                    o = s / 2;
                r.fillStyle = "rgba(0, 0, 0, 0.32)";
                let l = 3 * Math.ceil(s * n.K / 3);
                for (let e = -l; e < s + l; e += 3) {
                    r.beginPath();
                    for (let t = 0; t <= a + 12; t += 12) {
                        let a = (t - i) / i,
                            s = o + (e - o) / (1 + n.K * a * a);
                        0 === t ? r.moveTo(t, s) : r.lineTo(t, s)
                    }
                    for (let t = 12 * Math.ceil((a + 12) / 12); t >= 0; t -= 12) {
                        let a = (t - i) / i;
                        r.lineTo(t, o + (e - o) / (1 + n.K * a * a) + 1)
                    }
                    r.fill()
                }
            };
            a();
            let s = new ResizeObserver(a);
            return s.observe(t), () => s.disconnect()
        }, []), (0, t.jsx)("canvas", {
            ref: e,
            className: "vhs-crt-lines",
            "aria-hidden": !0
        })
    }, "Grain", 0, function({
        fixed: e
    }) {
        return (0, t.jsx)("div", {
            className: `grain${e?" grain-fixed":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("div", {
                className: "grain-layer"
            })
        })
    }, "LinkArrow", 0, i, "Reveal", 0, function({
        on: e,
        i: n = 0,
        className: s,
        children: i
    }) {
        let [o, l] = (0, r.useState)(!1);
        (0, r.useEffect)(() => {
            if (void 0 !== e) return;
            let t = requestAnimationFrame(() => l(!0));
            return () => cancelAnimationFrame(t)
        }, [e]);
        let u = (0, a.useScreenReady)(),
            c = e ? ? (o && u);
        return (0, t.jsx)("span", {
            className: `rv${s?` ${s}`:""}`,
            children: (0, t.jsx)("span", {
                className: `rv-i${c?" rv-in":""}`,
                style: {
                    transitionDelay: `${70*n}ms`
                },
                children: i
            })
        })
    }, "TvGlass", 0, function() {
        return (0, t.jsx)("div", {
            className: "tv-glass",
            "aria-hidden": !0
        })
    }], 745850)
}, 862356, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645),
        n = e.i(942295);
    e.s(["default", 0, function({
        text: e = null,
        idle: a = null
    }) {
        let s = (0, r.useRef)(null),
            [i, o] = (0, r.useState)(null),
            [l, u] = (0, r.useState)(!0),
            c = e ? ? i ? ? (l ? null : a),
            [d, f] = (0, r.useState)(null),
            [h, m] = (0, r.useState)(null);
        c !== h && (m(c), !c || h && d || f(c));
        let p = !!c && !!d && c !== d;
        (0, r.useEffect)(() => {
            if (!p) return;
            let e = window.setTimeout(() => f(c), 200);
            return () => window.clearTimeout(e)
        }, [p, c]);
        let v = (0, r.useRef)(!1);
        return (0, r.useEffect)(() => {
            if (c) {
                v.current = !0;
                return
            }
            let e = window.setTimeout(() => v.current = !1, 300);
            return () => window.clearTimeout(e)
        }, [c]), (0, r.useEffect)(() => {
            let e = s.current ? .closest(".vhs");
            if (!e) return;
            let t = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                r = {
                    x: 0,
                    y: 0,
                    vx: 0,
                    vy: 0
                },
                a = {
                    x: 0,
                    y: 0
                },
                i = 0,
                l = 0,
                c = () => {
                    let e = s.current;
                    e && (e.style.transform = `translate3d(${r.x.toFixed(1)}px, ${r.y.toFixed(1)}px, 0)`)
                },
                d = e => {
                    let t = Math.min(.05, (e - l) / 1e3);
                    l = e;
                    let s = (0, n.springTo)(r.x, r.vx, a.x, t, 16),
                        o = (0, n.springTo)(r.y, r.vy, a.y, t, 16);
                    r.x = s.x, r.vx = s.v, r.y = o.x, r.vy = o.v;
                    let u = .1 > Math.abs(a.x - r.x) && .1 > Math.abs(a.y - r.y) && Math.abs(r.vx) + Math.abs(r.vy) < 1;
                    u && (r.x = a.x, r.y = a.y, r.vx = r.vy = 0), c(), i = u ? 0 : requestAnimationFrame(d)
                },
                f = n => {
                    let s = "mouse" === n.pointerType ? n.target : null;
                    o(s ? .closest("[data-caption]") ? .getAttribute("data-caption") ? ? null), u(!s || !!s.closest("a, button, [role='dialog'], .vhs-about"));
                    let f = e.getBoundingClientRect();
                    a.x = n.clientX - f.left, a.y = n.clientY - f.top, t || !v.current ? (r.x = a.x, r.y = a.y, r.vx = r.vy = 0, c()) : i || (l = performance.now(), i = requestAnimationFrame(d))
                },
                h = () => {
                    o(null), u(!0)
                };
            return window.addEventListener("pointermove", f), document.documentElement.addEventListener("pointerleave", h), () => {
                window.removeEventListener("pointermove", f), document.documentElement.removeEventListener("pointerleave", h), cancelAnimationFrame(i)
            }
        }, []), (0, t.jsx)("p", {
            ref: s,
            className: `cursor-caption${c&&!p?" is-on":""}${p?" is-swapping":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("span", {
                className: "cursor-caption-i",
                children: d
            })
        })
    }])
}, 133634, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(770703),
        n = e.i(522016),
        a = e.i(618566),
        s = e.i(271645),
        i = e.i(511226),
        o = e.i(916494),
        l = e.i(926236),
        u = e.i(495634),
        c = e.i(783329),
        d = e.i(569414),
        f = e.i(844294),
        h = e.i(172311),
        m = e.i(745850),
        p = e.i(111837),
        v = e.i(862356),
        g = e.i(556304);
    let x = (0, r.default)(() => e.A(28344), {
            loadableGenerated: {
                modules: [436345]
            },
            ssr: !1
        }),
        w = (0, r.default)(() => e.A(820453), {
            loadableGenerated: {
                modules: [374914]
            },
            ssr: !1
        }),
        y = "arc:tape";

    function b({
        k: e,
        children: r,
        className: n,
        delay: a = 0,
        leaving: s,
        outDelay: i = 0
    }) {
        return (0, t.jsx)("span", {
            className: `swap${n?` ${n}`:""}`,
            children: (0, t.jsx)("span", {
                className: `swap-i${s?" swap-out":""}`,
                style: {
                    animationDelay: `${s?i:a}s`
                },
                children: r
            }, s ? `out-${e}` : e)
        })
    }
    e.s(["default", 0, function({
        projects: e
    }) {
        let r = (0, a.useRouter)(),
            S = (0, i.useLoadProgress)(),
            [E, j] = (0, s.useState)(!1),
            N = (0, s.useCallback)(() => {
                window.__ready = !0, j(!0)
            }, []),
            [M] = (0, s.useState)(d.navSeen),
            [A, T] = (0, s.useState)(M),
            R = (0, s.useCallback)(() => T(!0), []),
            [C, P] = (0, s.useState)(() => M ? (0, o.can3D)() ? "3d" : "flat" : null);
        (0, s.useEffect)(() => {
            if (!C) return (0, l.afterFirstPaint)(() => P((0, o.can3D)() ? "3d" : "flat"))
        }, [C]), (0, s.useEffect)(() => {
            if (!C || E) return;
            let e = window.setTimeout(() => {
                console.warn("[deck] not ready after 15s; showing the page without waiting"), j(!0)
            }, 15e3);
            return () => window.clearTimeout(e)
        }, [C, E]);
        let {
            year: k,
            textIn: L,
            spiralIn: $
        } = (0, u.useIntro)(S / 100, E, A), _ = M || L;
        (0, s.useEffect)(() => {
            L && (0, d.markNavSeen)()
        }, [L]);
        let [O, B] = (0, s.useState)(0);
        (0, s.useEffect)(() => {
            try {
                let t = sessionStorage.getItem(y),
                    r = e.findIndex(e => e.slug === t);
                r > 0 && B(r)
            } catch {}
        }, [e]), (0, s.useEffect)(() => {
            try {
                e[O] && sessionStorage.setItem(y, e[O].slug)
            } catch {}
        }, [O, e]);
        let I = (0, f.useSastClock)(),
            D = (0, s.useRef)(null),
            [F, U] = (0, s.useState)(!1);
        (0, s.useEffect)(() => {
            if (!$ || F) return;
            let e = window.setTimeout(() => U(!0), 8e3);
            return () => window.clearTimeout(e)
        }, [$, F]), (0, f.useSiteTime)(D, M || F);
        let G = (0, c.useDevice)(),
            K = {
                "--source-ch": `Source: ${G||"—"}`.length,
                "--first-ch": 7
            },
            W = (0, s.useMemo)(() => e.map(e => ({
                slug: e.slug,
                title: e.title,
                year: e.year,
                cover: {
                    src: e.cover.src,
                    focus: e.cover.focus
                },
                sleeve: e.sleeve ? .src
            })), [e]),
            q = (0, s.useCallback)(t => (0, h.transitionTo)(() => r.push(`/work/${e[t].slug}`)), [r, e]),
            z = e[O] ? ? e[0],
            {
                shown: H,
                leaving: X
            } = function(e) {
                let [t, r] = (0, s.useState)(e), n = (0, s.useRef)(e);
                (0, s.useEffect)(() => {
                    n.current = e
                }, [e]);
                let a = !!e && !!t && e.slug !== t.slug;
                return (0, s.useEffect)(() => {
                    if (!a || !t) return;
                    let e = window.setTimeout(() => {
                        r(n.current)
                    }, 600.0000000000001);
                    return () => window.clearTimeout(e)
                }, [a, t]), {
                    shown: t ? ? e,
                    leaving: a
                }
            }(z),
            [J, Q] = (0, s.useState)(null),
            V = (e, t) => [e.title, String(t + 1).padStart(3, "0"), e.year].filter(Boolean).join(", "),
            Y = (0, s.useRef)(null),
            Z = (0, s.useCallback)(t => {
                let n = e[t];
                Y.current && n && (Y.current.textContent = V(n, t)), n && r.prefetch(`/work/${n.slug}`), U(!0)
            }, [e, r]),
            [ee, et] = (0, s.useState)(null);
        return (0, t.jsxs)("div", {
            className: "tv",
            children: [(0, t.jsxs)("main", {
                className: "vhs",
                children: [(0, t.jsxs)("div", {
                    className: "vhs-crt",
                    "aria-hidden": !0,
                    children: [(0, t.jsx)(m.CrtLines, {}), (0, t.jsx)(m.Grain, {}), (0, t.jsx)("div", {
                        className: "vhs-crt-roll"
                    })]
                }), (0, t.jsxs)("header", {
                    className: "vhs-head",
                    "data-tape-top": !0,
                    style: K,
                    children: [(0, t.jsxs)(n.default, {
                        href: "/",
                        className: "vhs-logo",
                        children: [(0, t.jsx)("span", {
                            className: "vhs-logo-mark",
                            children: (0, t.jsx)("span", {
                                className: `vhs-logo-i${_?" is-in":""}`,
                                children: (0, t.jsxs)("picture", {
                                    children: [(0, t.jsx)("source", {
                                        media: "(max-width: 700px)",
                                        srcSet: "/brand/arc-bands.svg",
                                        width: 67,
                                        height: 30
                                    }), (0, t.jsx)("img", {
                                        src: "/brand/arc-logo.svg",
                                        width: 115,
                                        height: 30,
                                        alt: "Arc — home"
                                    })]
                                })
                            })
                        }), (0, t.jsx)("img", {
                            className: "vhs-logo-rule",
                            src: "/brand/logo-rule.svg",
                            width: 115,
                            height: 2,
                            alt: ""
                        }), (0, t.jsxs)("span", {
                            className: "vhs-logo-meta",
                            children: [(0, t.jsx)(m.Reveal, {
                                on: _,
                                i: 1,
                                children: "Year"
                            }), (0, t.jsx)(m.Reveal, {
                                on: _,
                                i: 1,
                                children: (0, t.jsxs)("span", {
                                    className: "vhs-year",
                                    children: ["20", String(M ? 26 : k).padStart(2, "0")]
                                })
                            })]
                        })]
                    }), (0, t.jsx)(m.Reveal, {
                        on: _,
                        i: 2,
                        className: "vhs-counter",
                        children: (0, t.jsx)("span", {
                            ref: D,
                            children: "00:00:00"
                        })
                    }), (0, t.jsx)(m.Reveal, {
                        on: _,
                        i: 3,
                        className: "vhs-home",
                        children: (0, t.jsx)(n.default, {
                            href: "/",
                            "aria-current": "page",
                            children: "Home"
                        })
                    }), (0, t.jsxs)("nav", {
                        className: "vhs-nav",
                        children: [(0, t.jsx)(m.Reveal, {
                            on: _,
                            i: 5,
                            className: "vhs-nav-about",
                            children: (0, t.jsx)(g.default, {
                                href: "/profile",
                                children: "Profile"
                            })
                        }), (0, t.jsx)(m.Reveal, {
                            on: _,
                            i: 5,
                            className: "vhs-nav-gallery",
                            children: (0, t.jsx)(g.default, {
                                href: "/news-watch",
                                children: "News Watch"
                            })
                        }), (0, t.jsx)(m.Reveal, {
                            on: _,
                            i: 5,
                            children: (0, t.jsx)("a", {
                                href: `mailto:${m.CONTACT_EMAIL}`,
                                children: "Contact"
                            })
                        })]
                    })]
                }), (0, t.jsxs)("section", {
                    className: "vhs-canvas",
                    role: "region",
                    "aria-roledescription": "carousel",
                    "aria-label": "Projects",
                    "aria-describedby": "deck-help",
                    children: [(0, t.jsx)("p", {
                        id: "deck-help",
                        className: "sr-only",
                        children: "Use the left and right arrow keys to move between projects, and Enter to open the one in the centre."
                    }), "flat" === C && (0, t.jsx)(w, {
                        projects: W,
                        intro: $,
                        entered: M,
                        hidden: !1,
                        focusIndex: O,
                        onReady: N,
                        onActive: B,
                        onOpen: q,
                        onSettle: Z,
                        onHover: Q,
                        onLayout: et
                    }), "3d" === C && (0, t.jsx)(x, {
                        projects: W,
                        intro: $,
                        entered: M,
                        hidden: !1,
                        focusIndex: O,
                        onReady: N,
                        onActive: B,
                        onOpen: q,
                        onSettle: Z,
                        onHover: Q,
                        onLayout: et
                    }), z && ee && (0, t.jsx)(n.default, {
                        href: `/work/${z.slug}`,
                        prefetch: !1,
                        className: "vhs-open",
                        "aria-label": `Open ${V(z,O)}`,
                        style: {
                            top: ee.centerY,
                            width: ee.width,
                            height: ee.height
                        }
                    })]
                }), (0, t.jsx)("p", {
                    ref: Y,
                    className: "sr-only",
                    "aria-live": "polite",
                    "aria-atomic": "true"
                }), H && (0, t.jsxs)("section", {
                    className: "vhs-caption",
                    "data-tape-bottom": !0,
                    children: [(0, t.jsx)("h1", {
                        className: "vhs-caption-name",
                        children: (0, t.jsx)(m.Reveal, {
                            on: L,
                            i: 6,
                            children: (0, t.jsx)(n.default, {
                                href: `/work/${z.slug}`,
                                className: "vhs-title-link",
                                prefetch: !1,
                                "aria-label": z.title,
                                tabIndex: -1,
                                draggable: !1,
                                children: (0, t.jsx)(b, {
                                    k: `n-${H.slug}`,
                                    leaving: X,
                                    outDelay: .14,
                                    children: H.title
                                })
                            })
                        })
                    }), (0, t.jsx)(m.Reveal, {
                        on: L,
                        i: 7,
                        className: "vhs-caption-desc",
                        children: (0, t.jsx)(b, {
                            k: `s-${H.slug}`,
                            delay: .07,
                            leaving: X,
                            outDelay: .07,
                            children: H.description
                        })
                    }), (0, t.jsx)(m.Reveal, {
                        on: L,
                        i: 8,
                        className: "vhs-caption-discipline",
                        children: (0, t.jsx)(b, {
                            k: `d-${H.slug}`,
                            delay: .14,
                            leaving: X,
                            children: H.discipline
                        })
                    })]
                }), (0, t.jsxs)("footer", {
                    className: "vhs-foot",
                    style: K,
                    children: [(0, t.jsxs)(m.Reveal, {
                        on: _,
                        i: 9,
                        children: [I || "00:00", (0, t.jsx)("span", {
                            className: "vhs-tz",
                            children: " SAST"
                        })]
                    }), (0, t.jsx)(m.Reveal, {
                        on: _,
                        i: 9,
                        className: "vhs-bw",
                        children: (0, t.jsx)(m.BwToggle, {})
                    }), (0, t.jsx)(m.Reveal, {
                        on: _,
                        i: 10,
                        className: "vhs-source",
                        children: (0, t.jsxs)("span", {
                            children: ["Source: ", G || "—"]
                        })
                    }), (0, t.jsx)(m.Reveal, {
                        on: _,
                        i: 11,
                        className: "vhs-email",
                        children: (0, t.jsx)(m.ContactLink, {
                            label: "Email"
                        })
                    })]
                }), (0, t.jsx)(v.default, {
                    text: null !== J ? "[Play tape]" : null,
                    idle: _ ? "[Scroll/Drag]" : null
                }), !A && (0, t.jsx)(p.default, {
                    progress: S / 100,
                    ready: E,
                    onDone: R
                })]
            }), (0, t.jsx)(m.TvGlass, {})]
        })
    }])
}, 111837, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["default", 0, function({
        progress: e,
        ready: n,
        onDone: a
    }) {
        let [s, i] = (0, r.useState)(0), [o, l] = (0, r.useState)(!1), u = (0, r.useRef)(0), c = (0, r.useRef)(a);
        return (0, r.useEffect)(() => {
            c.current = a
        }, [a]), (0, r.useEffect)(() => {
            let t = 0,
                r = performance.now(),
                a = () => {
                    let s = performance.now(),
                        o = Math.min(.25, (s - r) / 1e3);
                    r = s;
                    let l = n ? 100 : Math.min(100 * e, 99);
                    u.current += (l - u.current) * (1 - Math.exp(-5 * o)), n && 100 - u.current < .5 && (u.current = 100);
                    let c = Math.floor(u.current);
                    i(e => c > e ? c : e), u.current < 100 && (t = requestAnimationFrame(a))
                };
            return t = requestAnimationFrame(a), () => cancelAnimationFrame(t)
        }, [e, n]), (0, r.useEffect)(() => {
            if (s < 100) return;
            let e = window.setTimeout(() => l(!0), 350),
                t = window.setTimeout(() => c.current(), 850);
            return () => {
                window.clearTimeout(e), window.clearTimeout(t)
            }
        }, [s]), (0, t.jsxs)("div", {
            className: `vhs-loader${o?" is-out":""}`,
            role: "status",
            "aria-label": `Loading, ${s}%`,
            children: [(0, t.jsx)("p", {
                className: "vhs-loader-label",
                children: "Loading"
            }), (0, t.jsx)("p", {
                className: "vhs-loader-count",
                children: s
            }), (0, t.jsxs)("div", {
                className: "vhs-loader-bar",
                "aria-hidden": !0,
                style: {
                    "--loaded": s / 100
                },
                children: [(0, t.jsx)("i", {
                    className: "vhs-loader-ticks"
                }), (0, t.jsx)("i", {
                    className: "vhs-loader-dashes"
                })]
            })]
        })
    }])
}, 556304, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(618566);
    e.s(["default", 0, function({
        href: e,
        ...a
    }) {
        let s = (0, n.usePathname)() === e;
        return (0, t.jsx)(r.default, {
            href: e,
            "aria-current": s ? "page" : void 0,
            ...a
        })
    }])
}, 306257, e => {
    "use strict";
    var t = e.i(271645);
    let r = 0,
        n = null,
        a = "http://www.w3.org/2000/svg";

    function s() {
        let e = navigator.userAgent;
        return !(/safari/i.test(e) && !/chrome|chromium|crios|fxios|edg|android/i.test(e)) && !window.matchMedia("(pointer: coarse)").matches
    }
    e.s(["K", 0, .16, "bendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            a = r.height / 2,
            s = (e - r.left - n) / n,
            i = (t - r.top - a) / a,
            o = s,
            l = i;
        for (let e = 0; e < 5; e++) l = i / (1 + .16 * (o = s / (1 + .16 * l * l)) * o);
        return {
            x: r.left + n + o * n,
            y: r.top + a + l * a
        }
    }, "canBend", 0, s, "unbendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            a = r.height / 2,
            s = (e - r.left - n) / n,
            i = (t - r.top - a) / a;
        return {
            x: r.left + n + s * (1 + .16 * i * i) * n,
            y: r.top + a + i * (1 + .16 * s * s) * a
        }
    }, "useBend", 0, function(e) {
        let i = (0, t.useRef)(1),
            o = (0, t.useRef)(null);
        return (0, t.useEffect)(() => {
            let t = e.current;
            if (!t || !s()) return;
            let l = `crt-bend-${++r}`,
                u = document.createElementNS(a, "filter");
            u.id = l, u.setAttribute("x", "0"), u.setAttribute("y", "0"), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("primitiveUnits", "userSpaceOnUse"), u.setAttribute("color-interpolation-filters", "sRGB");
            let c = document.createElementNS(a, "feImage");
            c.setAttribute("preserveAspectRatio", "none"), c.setAttribute("result", "map");
            let d = document.createElementNS(a, "feDisplacementMap");
            d.setAttribute("in", "SourceGraphic"), d.setAttribute("in2", "map"), d.setAttribute("xChannelSelector", "R"), d.setAttribute("yChannelSelector", "G"), u.append(c, d), (function() {
                if (n ? .isConnected) return n;
                let e = document.createElementNS(a, "svg");
                return e.setAttribute("aria-hidden", "true"), e.setAttribute("width", "0"), e.setAttribute("height", "0"), e.style.position = "absolute", n = document.createElementNS(a, "defs"), e.appendChild(n), document.body.appendChild(e), n
            })().appendChild(u);
            let f = "",
                h = 0,
                m = () => {
                    d.setAttribute("scale", String(h * i.current)), t.style.filter = i.current > .001 ? `url(#${l})` : ""
                };
            o.current = m;
            let p = () => {
                let e = t.offsetWidth,
                    r = t.offsetHeight;
                if (!e || !r || `${e}x${r}` === f) return;
                f = `${e}x${r}`;
                let n = .16 * Math.max(e, r);
                c.setAttribute("x", "0"), c.setAttribute("y", "0"), c.setAttribute("width", String(e)), c.setAttribute("height", String(r)), c.setAttribute("href", function(e, t, r) {
                    let n = document.createElement("canvas");
                    n.width = n.height = 128;
                    let a = n.getContext("2d"),
                        s = a.createImageData(128, 128);
                    for (let n = 0; n < 128; n++) {
                        let a = (n + .5) / 128 * 2 - 1;
                        for (let i = 0; i < 128; i++) {
                            let o = (i + .5) / 128 * 2 - 1,
                                l = .16 * o * a * a * (e / 2),
                                u = .16 * a * o * o * (t / 2),
                                c = (128 * n + i) * 4;
                            s.data[c] = Math.round((.5 + l / r) * 255), s.data[c + 1] = Math.round((.5 + u / r) * 255), s.data[c + 2] = 128, s.data[c + 3] = 255
                        }
                    }
                    return a.putImageData(s, 0, 0), n.toDataURL()
                }(e, r, n)), h = n, m()
            };
            p();
            let v = new ResizeObserver(p);
            return v.observe(t), () => {
                v.disconnect(), o.current = null, u.remove(), t.style.filter = ""
            }
        }, [e]), (0, t.useCallback)(e => {
            i.current = e, o.current ? .()
        }, [])
    }])
}, 783329, 569414, 844294, e => {
    "use strict";
    var t = e.i(271645);
    let r = [
        [1512, 982, "MacBook 14″"],
        [1352, 878, "MacBook 14″"],
        [1800, 1169, "MacBook 14″"],
        [1728, 1117, "MacBook 16″"],
        [1496, 967, "MacBook 16″"],
        [2056, 1329, "MacBook 16″"],
        [1470, 956, "MacBook Air 13″"],
        [1280, 832, "MacBook Air 13″"],
        [1710, 1107, "MacBook Air 13″"],
        [1710, 1112, "MacBook Air 15″"],
        [1440, 932, "MacBook Air 15″"],
        [1440, 900, "MacBook 13″"],
        [1280, 800, "MacBook 13″"],
        [1680, 1050, "MacBook 13″"],
        [1536, 960, "MacBook 16″"]
    ];

    function n() {
        if ("u" < typeof navigator) return "Unknown";
        let e = navigator.userAgent,
            t = navigator.maxTouchPoints > 1;
        if (/iPhone/.test(e)) return "iPhone";
        if (/iPad/.test(e) || /Macintosh/.test(e) && t) return "iPad";
        if (/Android/.test(e)) return /Mobile/.test(e) ? "Android" : "Android Tablet";
        if (/CrOS/.test(e)) return "Chromebook";
        if (/Macintosh/.test(e)) {
            let e = Math.max(screen.width, screen.height),
                t = Math.min(screen.width, screen.height),
                n = r.find(([r, n]) => r === e && n === t);
            return n ? n[2] : e > 2056 ? "Mac Display" : "Mac"
        }
        return /Windows/.test(e) ? "PC" : /Linux/.test(e) ? "Linux" : "Unknown"
    }
    let a = () => () => {};
    e.s(["useDevice", 0, function() {
        return (0, t.useSyncExternalStore)(a, n, () => "")
    }], 783329);
    let s = !1;
    e.s(["markNavSeen", 0, function() {
        s = !0
    }, "navSeen", 0, () => s], 569414);
    let i = new Intl.DateTimeFormat("en-GB", {
            timeZone: "Africa/Johannesburg",
            hour: "2-digit",
            minute: "2-digit",
            hour12: !1
        }),
        o = () => i.format(new Date),
        l = e => {
            let t = window.setInterval(e, 15e3);
            return () => window.clearInterval(t)
        };
    e.s(["useSastClock", 0, function() {
        return (0, t.useSyncExternalStore)(l, o, () => "")
    }, "useSiteTime", 0, function(e, r = !0) {
        (0, t.useLayoutEffect)(() => {
            let t, n = function(e) {
                let t = "arc:visit";
                try {
                    let r = Number(sessionStorage.getItem(t));
                    if (r > 0) return r;
                    if (!e) return null;
                    let n = Date.now();
                    return sessionStorage.setItem(t, String(n)), n
                } catch {
                    return e ? Date.now() : null
                }
            }(r);
            if (null === n) return;
            let a = () => {
                let t = Math.max(0, Math.floor((Date.now() - n) / 1e3)),
                    r = String(Math.floor(t / 3600)).padStart(2, "0"),
                    a = String(Math.floor(t % 3600 / 60)).padStart(2, "0"),
                    s = String(t % 60).padStart(2, "0");
                e.current && (e.current.textContent = `${r}:${a}:${s}`)
            };
            a();
            let s = () => {
                t = window.setTimeout(() => {
                    a(), s()
                }, 1e3 - (Date.now() - n) % 1e3)
            };
            return s(), () => window.clearTimeout(t)
        }, [e, r])
    }], 844294)
}, 916494, e => {
    "use strict";
    let t = /swiftshader|llvmpipe|lavapipe|softpipe|software|basic render|warp/i,
        r = "arc:gpu",
        n = null;
    e.s(["can3D", 0, function() {
        let e = "hardware" === function() {
            if (n) return n;
            try {
                let e = new URLSearchParams(location.search).get("3d");
                if ("0" === e) return n = "software";
                if ("1" === e) return n = "hardware";
                let t = sessionStorage.getItem(r);
                if ("hardware" === t || "software" === t || "none" === t) return n = t
            } catch {}
            let e = "none";
            try {
                let r = document.createElement("canvas").getContext("webgl2", {
                    failIfMajorPerformanceCaveat: !0
                });
                if (r) {
                    let n = r.getExtension("WEBGL_debug_renderer_info"),
                        a = String(r.getParameter(n ? n.UNMASKED_RENDERER_WEBGL : r.RENDERER) ? ? "");
                    e = t.test(a) ? "software" : "hardware", r.getExtension("WEBGL_lose_context") ? .loseContext()
                }
            } catch {
                e = "none"
            }
            try {
                sessionStorage.setItem(r, e)
            } catch {}
            return n = e
        }();
        return !e && "u" > typeof document && document.documentElement.classList.add("lite"), e
    }])
}, 511226, e => {
    "use strict";
    var t = e.i(271645);
    let r = 0,
        n = new Set;
    e.s(["setLoadProgress", 0, function(e) {
        e !== r && (r = e, n.forEach(e => e()))
    }, "useLoadProgress", 0, function() {
        return (0, t.useSyncExternalStore)(e => (n.add(e), () => void n.delete(e)), () => r, () => 0)
    }])
}, 942295, e => {
    "use strict";
    e.s(["EASE", 0, 7, "SETTLE", 0, 4.2, "releaseSpeed", 0, function(e, t, r) {
        return Math.max(-r, Math.min(r, e * Math.exp(-Math.max(0, t - 40) / 45)))
    }, "settleSlot", 0, function(e, t, r, n = .12) {
        let a = Math.round(e / r) * r,
            s = e - t;
        return Math.abs(a - t) < r / 2 && Math.abs(s) > r * n ? t + Math.sign(s) * r : a
    }, "springTo", 0, function(e, t, r, n, a = 7) {
        let s = e - r,
            i = Math.exp(-a * n),
            o = t + a * s;
        return {
            x: r + (s + o * n) * i,
            v: (t - o * a * n) * i
        }
    }])
}, 58685, e => {
    "use strict";
    var t = e.i(271645);
    let r = !0,
        n = new Set,
        a = () => n.forEach(e => e()),
        s = e => (n.add(e), () => n.delete(e));
    e.s(["holdScreen", 0, function() {
        r = !1, a()
    }, "releaseScreen", 0, function() {
        r = !0, a()
    }, "usePageLoad", 0, function() {
        let [e, r] = (0, t.useState)({
            progress: 0,
            ready: !1
        });
        return (0, t.useEffect)(() => {
            if ("complete" === document.readyState) return void r({
                progress: 1,
                ready: !0
            });
            let e = [...document.images],
                t = () => {
                    let t = e.filter(e => e.complete).length;
                    r(r => r.ready ? r : {
                        progress: e.length ? t / e.length : .5,
                        ready: !1
                    })
                },
                n = () => r({
                    progress: 1,
                    ready: !0
                });
            return e.forEach(e => e.addEventListener("load", t)), window.addEventListener("load", n), t(), () => {
                e.forEach(e => e.removeEventListener("load", t)), window.removeEventListener("load", n)
            }
        }, []), e
    }, "useScreenReady", 0, function() {
        return (0, t.useSyncExternalStore)(s, () => r, () => !0)
    }])
}, 522016, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return g
        },
        useLinkStatus: function() {
            return w
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let s = e.r(190809),
        i = e.r(843476),
        o = s._(e.r(271645)),
        l = e.r(195057),
        u = e.r(8372),
        c = e.r(818581),
        d = e.r(718967),
        f = e.r(405550),
        h = e.r(388540),
        m = e.r(91949),
        p = e.r(573668),
        v = e.r(509396);

    function g(t) {
        var r;
        let n, a, s, [g, w] = (0, o.useOptimistic)(m.IDLE_LINK_STATUS),
            y = (0, o.useRef)(null),
            {
                href: b,
                as: S,
                children: E,
                prefetch: j = null,
                passHref: N,
                replace: M,
                shallow: A,
                scroll: T,
                onClick: R,
                onMouseEnter: C,
                onTouchStart: P,
                legacyBehavior: k = !1,
                onNavigate: L,
                transitionTypes: $,
                ref: _,
                unstable_dynamicOnHover: O,
                ...B
            } = t;
        n = E, k && ("string" == typeof n || "number" == typeof n) && (n = (0, i.jsx)("a", {
            children: n
        }));
        let I = o.default.useContext(u.AppRouterContext),
            D = !1 !== j,
            F = !1 === j ? "none" : !0 === j ? "full" : "auto",
            U = "none" !== F ? "auto" === F ? v.FetchStrategy.PPR : v.FetchStrategy.Full : v.FetchStrategy.PPR,
            G = "string" == typeof(r = S || b) ? r : (0, l.formatUrl)(r);
        if (k) {
            if (n ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            a = o.default.Children.only(n)
        }
        let K = k ? a && "object" == typeof a && a.ref : _,
            W, q = o.default.useCallback(e => (null !== I && (y.current = (0, m.mountLinkInstance)(e, G, I, U, D, w, W)), () => {
                y.current && ((0, m.unmountLinkForCurrentNavigation)(y.current), y.current = null), (0, m.unmountPrefetchableInstance)(e)
            }), [D, G, I, U, w, W]),
            z = {
                ref: (0, c.useMergedRef)(q, K),
                onClick(t) {
                    k || "function" != typeof R || R(t), k && a.props && "function" == typeof a.props.onClick && a.props.onClick(t), !I || t.defaultPrevented || function(t, r, n, a, s, i, l, u = "none") {
                        if ("u" > typeof window) {
                            let c, {
                                nodeName: d
                            } = t.currentTarget;
                            if ("A" === d.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, p.isLocalURL)(r)) {
                                a && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), i) {
                                let e = !1;
                                if (i({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: f
                            } = e.r(699781);
                            o.default.startTransition(() => {
                                f(r, a ? "replace" : "push", !1 === s ? h.ScrollBehavior.NoScroll : h.ScrollBehavior.Default, n.current, l, u)
                            })
                        }
                    }(t, G, y, M, T, L, $, F)
                },
                onMouseEnter(e) {
                    k || "function" != typeof C || C(e), k && a.props && "function" == typeof a.props.onMouseEnter && a.props.onMouseEnter(e), I && D && (0, m.onNavigationIntent)(e.currentTarget, !0 === O)
                },
                onTouchStart: function(e) {
                    k || "function" != typeof P || P(e), k && a.props && "function" == typeof a.props.onTouchStart && a.props.onTouchStart(e), I && D && (0, m.onNavigationIntent)(e.currentTarget, !0 === O)
                }
            };
        return (0, d.isAbsoluteUrl)(G) ? z.href = G : k && !N && ("a" !== a.type || "href" in a.props) || (z.href = (0, f.addBasePath)(G)), s = k ? o.default.cloneElement(a, z) : (0, i.jsx)("a", { ...B,
            ...z,
            children: n
        }), (0, i.jsx)(x.Provider, {
            value: g,
            children: s
        })
    }
    let x = (0, o.createContext)(m.IDLE_LINK_STATUS),
        w = () => (0, o.useContext)(x);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(271645);

    function a(e, t) {
        let r = (0, n.useRef)(null),
            a = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = a.current;
                t && (a.current = null, t())
            } else e && (r.current = s(e, n)), t && (a.current = s(t, n))
        }, [e, t])
    }

    function s(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(718967),
        a = e.r(652817);

    function s(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, a.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 998183, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        assign: function() {
            return l
        },
        searchParamsToUrlQuery: function() {
            return s
        },
        urlQueryToSearchParams: function() {
            return o
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });

    function s(e) {
        let t = {};
        for (let [r, n] of e.entries()) {
            let e = t[r];
            void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
        }
        return t
    }

    function i(e) {
        return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
    }

    function o(e) {
        let t = new URLSearchParams;
        for (let [r, n] of Object.entries(e))
            if (Array.isArray(n))
                for (let e of n) t.append(r, i(e));
            else t.set(r, i(n));
        return t
    }

    function l(e, ...t) {
        for (let r of t) {
            for (let t of r.keys()) e.delete(t);
            for (let [t, n] of r.entries()) e.append(t, n)
        }
        return e
    }
}, 195057, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return o
        },
        formatWithValidation: function() {
            return u
        },
        urlObjectKeys: function() {
            return l
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let s = e.r(190809)._(e.r(998183)),
        i = /https?|ftp|gopher|file/;

    function o(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", a = e.pathname || "", o = e.hash || "", l = e.query || "", u = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? u = t + e.host : r && (u = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (u += ":" + e.port)), l && "object" == typeof l && (l = String(s.urlQueryToSearchParams(l)));
        let c = e.search || l && `?${l}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || i.test(n)) && !1 !== u ? (u = "//" + (u || ""), a && "/" !== a[0] && (a = "/" + a)) : u || (u = ""), o && "#" !== o[0] && (o = "#" + o), c && "?" !== c[0] && (c = "?" + c), a = a.replace(/[?#]/g, encodeURIComponent), c = c.replace("#", "%23"), `${n}${u}${a}${c}${o}`
    }
    let l = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function u(e) {
        return o(e)
    }
}, 718967, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DecodeError: function() {
            return g
        },
        MiddlewareNotFoundError: function() {
            return b
        },
        MissingStaticPage: function() {
            return y
        },
        NormalizeError: function() {
            return x
        },
        PageNotFoundError: function() {
            return w
        },
        SP: function() {
            return p
        },
        ST: function() {
            return v
        },
        WEB_VITALS: function() {
            return s
        },
        execOnce: function() {
            return i
        },
        getDisplayName: function() {
            return d
        },
        getLocationOrigin: function() {
            return u
        },
        getURL: function() {
            return c
        },
        isAbsoluteUrl: function() {
            return l
        },
        isResSent: function() {
            return f
        },
        loadGetInitialProps: function() {
            return m
        },
        normalizeRepeatedSlashes: function() {
            return h
        },
        stringifyError: function() {
            return S
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let s = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

    function i(e) {
        let t, r = !1;
        return (...n) => (r || (r = !0, t = e(...n)), t)
    }
    let o = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
        l = e => {
            let t = e.charCodeAt(0);
            return !!(t >= 65 && t <= 90 || t >= 97 && t <= 122) && o.test(e)
        };

    function u() {
        let {
            protocol: e,
            hostname: t,
            port: r
        } = window.location;
        return `${e}//${t}${r?":"+r:""}`
    }

    function c() {
        let {
            href: e
        } = window.location, t = u();
        return e.substring(t.length)
    }

    function d(e) {
        return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
    }

    function f(e) {
        return e.finished || e.headersSent
    }

    function h(e) {
        let t = e.split("?");
        return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
    }
    async function m(e, t) {
        let r = t.res || t.ctx && t.ctx.res;
        if (!e.getInitialProps) return t.ctx && t.Component ? {
            pageProps: await m(t.Component, t.ctx)
        } : {};
        let n = await e.getInitialProps(t);
        if (r && f(r)) return n;
        if (!n) throw Object.defineProperty(Error(`"${d(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
            value: "E1025",
            enumerable: !1,
            configurable: !0
        });
        return n
    }
    let p = "u" > typeof performance,
        v = p && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
    class g extends Error {}
    class x extends Error {}
    class w extends Error {
        constructor(e) {
            super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
        }
    }
    class y extends Error {
        constructor(e, t) {
            super(), this.message = `Failed to load static file for page: ${e} ${t}`
        }
    }
    class b extends Error {
        constructor() {
            super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
        }
    }

    function S(e) {
        return JSON.stringify({
            message: e.message,
            stack: e.stack
        })
    }
}]);