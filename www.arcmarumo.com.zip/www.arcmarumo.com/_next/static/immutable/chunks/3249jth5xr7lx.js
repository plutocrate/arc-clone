(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 966849, (e, t, r) => {
    "trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
        configurable: !0,
        get: function() {
            var e = /\((.*)\)/.exec(this.toString());
            return e ? e[1] : void 0
        }
    }), Array.prototype.flat || (Array.prototype.flat = function(e, t) {
        return t = this.concat.apply([], this), e > 1 && t.some(Array.isArray) ? t.flat(e - 1) : t
    }, Array.prototype.flatMap = function(e, t) {
        return this.map(e, t).flat()
    }), Promise.prototype.finally || (Promise.prototype.finally = function(e) {
        if ("function" != typeof e) return this.then(e, e);
        var t = this.constructor || Promise;
        return this.then(function(r) {
            return t.resolve(e()).then(function() {
                return r
            })
        }, function(r) {
            return t.resolve(e()).then(function() {
                throw r
            })
        })
    }), Object.fromEntries || (Object.fromEntries = function(e) {
        return Array.from(e).reduce(function(e, t) {
            return e[t[0]] = t[1], e
        }, {})
    }), Array.prototype.at || (Array.prototype.at = function(e) {
        var t = Math.trunc(e) || 0;
        if (t < 0 && (t += this.length), !(t < 0 || t >= this.length)) return this[t]
    }), Object.hasOwn || (Object.hasOwn = function(e, t) {
        if (null == e) throw TypeError("Cannot convert undefined or null to object");
        return Object.prototype.hasOwnProperty.call(Object(e), t)
    }), "canParse" in URL || (URL.canParse = function(e, t) {
        try {
            return new URL(e, t), !0
        } catch (e) {
            return !1
        }
    })
}, 523911, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(966849), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 198569, (e, t, r) => {
    "use strict";
    let n, o, a, l;
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "hydrate", {
        enumerable: !0,
        get: function() {
            return H
        }
    });
    let i = e.r(555682),
        u = e.r(843476);
    e.r(523911);
    let d = i._(e.r(88014)),
        s = i._(e.r(271645)),
        c = e.r(235326),
        f = e.r(742732),
        p = e.r(597238),
        h = e.r(851323),
        _ = e.r(132120),
        y = e.r(92245),
        b = e.r(699781),
        m = i._(e.r(875530)),
        v = e.r(665716);
    e.r(8372);
    let E = e.r(450590),
        g = e.r(543369),
        w = e.r(732992),
        P = e.r(76138),
        j = c.createFromReadableStream,
        R = c.createFromFetch,
        S = document,
        O = self.__next_instant_test ? self.__next_instant_test : void 0,
        x = new TextEncoder,
        M = !1,
        T = !1,
        A = null;

    function C(e) {
        if (0 === e[0]) a = [];
        else if (1 === e[0]) {
            if (!a) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            l ? l.enqueue(x.encode(e[1])) : a.push(e[1])
        } else if (2 === e[0]) A = e[1];
        else if (3 === e[0]) {
            if (!a) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            let r = atob(e[1]),
                n = new Uint8Array(r.length);
            for (var t = 0; t < r.length; t++) n[t] = r.charCodeAt(t);
            l ? l.enqueue(n) : a.push(n)
        }
    }
    let N = function() {
        l && !T && (l.close(), T = !0, a = void 0), M = !0
    };
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", N, !1) : setTimeout(N);
    let L = self.__next_f = self.__next_f || [];
    L.forEach(C), L.length = 0, L.push = C;
    let I = new ReadableStream({
        start(e) {
            a && (a.forEach(t => {
                e.enqueue("string" == typeof t ? x.encode(t) : t)
            }), M && !T) && (null === e.desiredSize || e.desiredSize < 0 ? O || e.error(Object.defineProperty(Error("The connection to the page was unexpectedly closed, possibly due to the stop button being clicked, loss of Wi-Fi, or an unstable internet connection."), "__NEXT_ERROR_CODE", {
                value: "E117",
                enumerable: !1,
                configurable: !0
            })) : e.close(), T = !0, a = void 0), l = e
        }
    });
    if (O) o = Promise.resolve(R(O, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        unstable_allowPartialStream: !0
    })).then(async e => (0, E.createInitialRSCPayloadFromFallbackPrerender)(await O, e));
    else if (window.__NEXT_CLIENT_RESUME) {
        let e = window.__NEXT_CLIENT_RESUME;
        o = Promise.resolve(R(e, {
            callServer: _.callServer,
            findSourceMapURL: y.findSourceMapURL,
            debugChannel: n
        })).then(async t => (0, E.createInitialRSCPayloadFromFallbackPrerender)(await e, t))
    } else o = j(I, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        startTime: 0
    });

    function D({
        initialRSCPayload: e,
        actionQueue: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        return (0, u.jsx)(m.default, {
            actionQueue: t,
            globalErrorState: e.G,
            webSocket: r,
            staticIndicatorState: n
        })
    }
    let F = s.default.StrictMode;

    function U({
        children: e
    }) {
        return e
    }
    let B = {
        onDefaultTransitionIndicator: function() {
            return () => {}
        },
        onRecoverableError: p.onRecoverableError,
        onCaughtError: h.onCaughtError,
        onUncaughtError: h.onUncaughtError
    };
    async function H(e, t) {
        let r, n, a = await o;
        a.b ? (0, w.setNavigationBuildId)(a.b) : (0, w.setNavigationBuildId)((0, g.getDeploymentId)()), (0, P.initializeRouterTransitionModules)(e);
        let l = Date.now(),
            i = (0, b.createMutableActionQueue)((0, v.createInitialRouterState)({
                navigatedAt: l,
                initialRSCPayload: a,
                initialFlightStreamForCache: null,
                location: window.location
            })),
            c = (0, u.jsx)(F, {
                children: (0, u.jsx)(f.HeadManagerContext.Provider, {
                    value: {
                        appDir: !0
                    },
                    children: (0, u.jsx)(U, {
                        children: (0, u.jsx)(D, {
                            initialRSCPayload: a,
                            actionQueue: i,
                            webSocket: n,
                            staticIndicatorState: r
                        })
                    })
                })
            });
        "__next_error__" === document.documentElement.id ? d.default.createRoot(S, B).render(c) : s.default.startTransition(() => {
            d.default.hydrateRoot(S, c, { ...B,
                formState: A
            })
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 494553, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(423755);
    let n = e.r(396517);
    e.r(597238), window.next.turbopack = !0, self.__webpack_hash__ = "";
    let o = e.r(5526);
    (0, n.appBootstrap)(t => {
        let {
            hydrate: r
        } = e.r(198569);
        r(o, t)
    }), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 974575, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getAssetPrefix", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(312718);

    function o() {
        let e = document.currentScript;
        if (!(e instanceof HTMLScriptElement)) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript to be a <script> element. Received ${e} instead.`), "__NEXT_ERROR_CODE", {
            value: "E783",
            enumerable: !1,
            configurable: !0
        });
        let {
            pathname: t
        } = new URL(e.src), r = t.indexOf("/_next/");
        if (-1 === r) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript src to contain '/_next/'. Received ${e.src} instead.`), "__NEXT_ERROR_CODE", {
            value: "E784",
            enumerable: !1,
            configurable: !0
        });
        return t.slice(0, r)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 922737, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "setAttributesFromProps", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = {
            acceptCharset: "accept-charset",
            className: "class",
            htmlFor: "for",
            httpEquiv: "http-equiv",
            noModule: "noModule"
        },
        o = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];

    function a(e) {
        return ["async", "defer", "noModule"].includes(e)
    }

    function l(e, t) {
        for (let [r, l] of Object.entries(t)) {
            if (!t.hasOwnProperty(r) || o.includes(r) || void 0 === l) continue;
            let i = n[r] || r.toLowerCase();
            "SCRIPT" === e.tagName && a(i) ? e[i] = !!l : e.setAttribute(i, String(l)), (!1 === l || "SCRIPT" === e.tagName && a(i) && (!l || "false" === l)) && (e.setAttribute(i, ""), e.removeAttribute(i))
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 396517, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "appBootstrap", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(974575),
        o = e.r(922737);

    function a(e) {
        var t, r;
        let a = (0, n.getAssetPrefix)();
        t = self.__next_s, r = () => {
            e(a)
        }, t && t.length ? t.reduce((e, [t, r]) => e.then(() => new Promise((e, n) => {
            let a = document.createElement("script");
            r && (0, o.setAttributesFromProps)(a, r), t ? (a.src = t, a.onload = () => e(), a.onerror = n) : r && (a.innerHTML = r.children, setTimeout(e)), document.head.appendChild(a)
        })), Promise.resolve()).catch(e => {
            console.error(e)
        }).then(() => {
            r()
        }) : r()
    }
    window.next = {
        version: "16.3.1",
        appDir: !0
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 762634, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "AppRouterAnnouncer", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(271645),
        o = e.r(174080),
        a = "next-route-announcer";

    function l({
        tree: e
    }) {
        let [t, r] = (0, n.useState)(null);
        (0, n.useEffect)(() => (r(function() {
            let e = document.getElementsByName(a)[0];
            if (e ? .shadowRoot ? .childNodes[0]) return e.shadowRoot.childNodes[0]; {
                let e = document.createElement(a);
                e.style.cssText = "position:absolute";
                let t = document.createElement("div");
                return t.ariaLive = "assertive", t.id = "__next-route-announcer__", t.role = "alert", t.style.cssText = "position:absolute;border:0;height:1px;margin:-1px;padding:0;width:1px;clip:rect(0 0 0 0);overflow:hidden;white-space:nowrap;word-wrap:normal", e.attachShadow({
                    mode: "open"
                }).appendChild(t), document.body.appendChild(e), t
            }
        }()), () => {
            let e = document.getElementsByTagName(a)[0];
            e ? .isConnected && document.body.removeChild(e)
        }), []);
        let [i, u] = (0, n.useState)(""), d = (0, n.useRef)(void 0);
        return (0, n.useEffect)(() => {
            let e = "";
            if (document.title) e = document.title;
            else {
                let t = document.querySelector("h1");
                t && (e = t.innerText || t.textContent || "")
            }
            void 0 !== d.current && d.current !== e && u(e), d.current = e
        }, [e]), t ? (0, o.createPortal)(i, t) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 875530, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return N
        }
    });
    let n = e.r(555682),
        o = e.r(190809),
        a = e.r(843476),
        l = o._(e.r(271645)),
        i = e.r(8372),
        u = e.r(388540),
        d = e.r(451191),
        s = e.r(261994),
        c = e.r(941538),
        f = e.r(494272),
        p = e.r(762634),
        h = e.r(358442),
        _ = e.r(425018),
        y = e.r(201244),
        b = e.r(387250),
        m = e.r(652817),
        v = e.r(734727),
        E = e.r(178377),
        g = e.r(699781),
        w = e.r(124063),
        P = e.r(968391),
        j = e.r(91949),
        R = n._(e.r(794109)),
        S = n._(e.r(168027)),
        O = e.r(897367);
    e.r(543369);
    let x = {};

    function M({
        appRouterState: e
    }) {
        return (0, l.useInsertionEffect)(() => {
            let {
                tree: t,
                pushRef: r,
                canonicalUrl: n,
                renderedSearch: o
            } = e, a = { ...r.preserveCustomHistoryState ? window.history.state : {},
                __NA: !0,
                __PRIVATE_NEXTJS_INTERNALS_TREE: {
                    tree: t,
                    renderedSearch: o
                }
            };
            r.pendingPush && (0, d.createHrefFromUrl)(new URL(window.location.href)) !== n ? (r.pendingPush = !1, window.history.pushState(a, "", n)) : window.history.replaceState(a, "", n), (0, f.setLastCommittedTree)(t)
        }, [e]), (0, l.useEffect)(() => {
            (0, j.pingVisibleLinks)(e.nextUrl, e.tree)
        }, [e.nextUrl, e.tree]), null
    }

    function T(e) {
        null == e && (e = {});
        let t = window.history.state,
            r = t ? .__NA;
        r && (e.__NA = r);
        let n = t ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
        return n && (e.__PRIVATE_NEXTJS_INTERNALS_TREE = n), e
    }

    function A({
        headCacheNode: e
    }) {
        let t = null !== e ? e.head : null,
            r = null !== e ? e.prefetchHead : null,
            n = null !== r ? r : t;
        return (0, l.useDeferredValue)(t, n)
    }

    function C({
        actionQueue: e,
        globalError: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        let o, d = (0, c.useActionQueue)(e),
            {
                canonicalUrl: f
            } = d,
            {
                searchParams: E,
                pathname: j
            } = (0, l.useMemo)(() => {
                let e = new URL(f, "u" < typeof window ? "http://n" : window.location.href);
                return {
                    searchParams: e.searchParams,
                    pathname: (0, m.hasBasePath)(e.pathname) ? (0, b.removeBasePath)(e.pathname) : e.pathname
                }
            }, [f]);
        (0, l.useEffect)(() => {
            let e = (0, v.extractSourcePageFromFlightRouterState)(d.tree);
            void 0 !== e ? window.next.__internal_src_page = e : delete window.next.__internal_src_page
        }, [d.tree]), (0, l.useEffect)(() => {
            function e(e) {
                e.persisted && window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE && (x.pendingMpaPath = void 0, (0, c.dispatchAppRouterAction)({
                    type: u.ACTION_RESTORE,
                    url: new URL(window.location.href),
                    historyState: window.history.state.__PRIVATE_NEXTJS_INTERNALS_TREE
                }))
            }
            return window.addEventListener("pageshow", e), () => {
                window.removeEventListener("pageshow", e)
            }
        }, []), (0, l.useEffect)(() => {
            function e(e) {
                let t = "reason" in e ? e.reason : e.error;
                if ((0, P.isRedirectError)(t)) {
                    e.preventDefault();
                    let r = (0, w.getURLFromRedirectError)(t);
                    "push" === (0, w.getRedirectTypeFromError)(t) ? g.publicAppRouterInstance.push(r, {}): g.publicAppRouterInstance.replace(r, {})
                }
            }
            return window.addEventListener("error", e), window.addEventListener("unhandledrejection", e), () => {
                window.removeEventListener("error", e), window.removeEventListener("unhandledrejection", e)
            }
        }, []);
        let {
            pushRef: S
        } = d;
        if (S.mpaNavigation) {
            if (x.pendingMpaPath !== f) {
                let e = window.location;
                S.pendingPush ? e.assign(f) : e.replace(f), x.pendingMpaPath = f
            }
            throw y.unresolvedThenable
        }(0, l.useEffect)(() => {
            let e = window.history.pushState.bind(window.history),
                t = window.history.replaceState.bind(window.history),
                r = e => {
                    let t = window.location.href,
                        r = window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
                    (0, l.startTransition)(() => {
                        (0, c.dispatchAppRouterAction)({
                            type: u.ACTION_RESTORE,
                            url: new URL(e ? ? t, t),
                            historyState: r
                        })
                    })
                };
            window.history.pushState = function(t, n, o) {
                return t ? .__NA || t ? ._N || (t = T(t), o && r(o)), e(t, n, o)
            }, window.history.replaceState = function(e, n, o) {
                return e ? .__NA || e ? ._N || (e = T(e), o && r(o)), t(e, n, o)
            };
            let n = e => {
                if (e.state) {
                    if (!e.state.__NA) return void window.location.reload();
                    (0, l.startTransition)(() => {
                        (0, g.dispatchTraverseAction)(window.location.href, e.state.__PRIVATE_NEXTJS_INTERNALS_TREE)
                    })
                }
            };
            return window.addEventListener("popstate", n), () => {
                window.history.pushState = e, window.history.replaceState = t, window.removeEventListener("popstate", n)
            }
        }, []);
        let {
            cache: N,
            tree: L,
            nextUrl: I,
            focusAndScrollRef: D,
            previousNextUrl: F
        } = d, U = (0, l.useMemo)(() => (0, _.findHeadInCache)(N, L[1]), [N, L]), B = (0, l.useMemo)(() => (0, v.getSelectedParams)(L), [L]), H = (0, l.useMemo)(() => ({
            parentTree: L,
            parentCacheNode: N,
            parentSegmentPath: null,
            parentParams: {},
            parentLoadingData: null,
            debugNameContext: "/",
            url: f,
            isActive: !0
        }), [L, N, f]), k = (0, l.useMemo)(() => ({
            tree: L,
            focusAndScrollRef: D,
            nextUrl: I,
            previousNextUrl: F
        }), [L, D, I, F]);
        if (null !== U) {
            let [e, t, r] = U;
            o = (0, a.jsx)(A, {
                headCacheNode: e
            }, "u" < typeof window ? r : t)
        } else o = null;
        let X = (0, a.jsxs)(h.RedirectBoundary, {
            children: [o, (0, a.jsx)(O.RootLayoutBoundary, {
                children: N.rsc
            }), (0, a.jsx)(p.AppRouterAnnouncer, {
                tree: L
            })]
        });
        return X = (0, a.jsx)(R.default, {
            errorComponent: t[0],
            errorStyles: t[1],
            children: X
        }), (0, a.jsxs)(a.Fragment, {
            children: [(0, a.jsx)(M, {
                appRouterState: d
            }), null, (0, a.jsx)(s.NavigationPromisesContext.Provider, {
                value: null,
                children: (0, a.jsx)(s.PathParamsContext.Provider, {
                    value: B,
                    children: (0, a.jsx)(s.PathnameContext.Provider, {
                        value: j,
                        children: (0, a.jsx)(s.SearchParamsContext.Provider, {
                            value: E,
                            children: (0, a.jsx)(i.GlobalLayoutRouterContext.Provider, {
                                value: k,
                                children: (0, a.jsx)(i.AppRouterContext.Provider, {
                                    value: g.publicAppRouterInstance,
                                    children: (0, a.jsx)(i.LayoutRouterContext.Provider, {
                                        value: H,
                                        children: X
                                    })
                                })
                            })
                        })
                    })
                })
            })]
        })
    }

    function N({
        actionQueue: e,
        globalErrorState: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        (0, E.useNavFailureHandler)();
        let o = (0, a.jsx)(C, {
            actionQueue: e,
            globalError: t,
            webSocket: r,
            staticIndicatorState: n
        });
        return (0, a.jsx)(R.default, {
            errorComponent: S.default,
            children: o
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 241624, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        GracefulDegradeBoundary: function() {
            return i
        },
        default: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(843476),
        l = e.r(271645);
    class i extends l.Component {
        constructor(e) {
            super(e), this.state = {
                hasError: !1
            }, this.rootHtml = "", this.htmlAttributes = {}, this.htmlRef = (0, l.createRef)()
        }
        static getDerivedStateFromError(e) {
            return {
                hasError: !0
            }
        }
        componentDidMount() {
            let e = this.htmlRef.current;
            this.state.hasError && e && Object.entries(this.htmlAttributes).forEach(([t, r]) => {
                e.setAttribute(t, r)
            })
        }
        render() {
            let {
                hasError: e
            } = this.state;
            return ("u" > typeof window && !this.rootHtml && (this.rootHtml = document.documentElement.innerHTML, this.htmlAttributes = function(e) {
                let t = {};
                for (let r = 0; r < e.attributes.length; r++) {
                    let n = e.attributes[r];
                    t[n.name] = n.value
                }
                return t
            }(document.documentElement)), e) ? (0, a.jsx)("html", {
                ref: this.htmlRef,
                suppressHydrationWarning: !0,
                dangerouslySetInnerHTML: {
                    __html: this.rootHtml
                }
            }) : this.props.children
        }
    }
    let u = i;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794109, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return d
        }
    });
    let n = e.r(555682),
        o = e.r(843476);
    e.r(271645);
    let a = n._(e.r(241624)),
        l = e.r(972383),
        i = e.r(82604),
        u = "u" > typeof window && (0, i.isBot)(window.navigator.userAgent);

    function d({
        children: e,
        errorComponent: t,
        errorStyles: r,
        errorScripts: n
    }) {
        return u ? (0, o.jsx)(a.default, {
            children: e
        }) : (0, o.jsx)(l.ErrorBoundary, {
            errorComponent: t,
            errorStyles: r,
            errorScripts: n,
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 665716, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createInitialRouterState", {
        enumerable: !0,
        get: function() {
            return f
        }
    });
    let n = e.r(451191),
        o = e.r(734727),
        a = e.r(450590),
        l = e.r(595871),
        i = e.r(620896),
        u = e.r(509396),
        d = e.r(179027),
        s = e.r(787288),
        c = e.r(496167);

    function f({
        navigatedAt: e,
        initialRSCPayload: t,
        initialFlightStreamForCache: r,
        location: p
    }) {
        let {
            c: h,
            f: _,
            q: y,
            i: b,
            S: m,
            s: v,
            l: E,
            h: g,
            r: w,
            p: P,
            d: j
        } = t, R = h.join("/"), {
            tree: S,
            seedData: O,
            head: x
        } = (0, a.getFlightDataPartsFromPath)(_[0]), M = p ? (0, n.createHrefFromUrl)(p) : R, T = {
            metadataVaryPath: null,
            treeDivergedFromBase: !1
        }, A = (0, i.convertRootFlightRouterStateToRouteTree)(S, y, T), C = T.metadataVaryPath, N = (0, l.createInitialCacheNodeForHydration)(e, A, O, x, (0, d.computeDynamicStaleAt)(e, j ? ? d.UnknownDynamicStaleTime));
        if (null !== p && null !== C) {
            if ((0, c.discoverKnownRoute)(Date.now(), p.pathname, p.search, null, null, A, C, b, M, m, !1), null !== O && void 0 !== v)
                if (void 0 !== E && null != r) Promise.resolve(E).then(async e => {
                    let t = await (0, s.decodeStageUntilBoundary)(r, e, void 0),
                        n = Date.now(),
                        o = await (0, i.resolveStaleAt)(n, t.s);
                    (0, i.writePrerenderResponseIntoCache)(n, u.FetchStrategy.PPR, t.f, void 0, t.h, t.r ? ? null, o, S, y, !0, i.segmentCacheMap)
                }).catch(() => {});
                else {
                    let e = Date.now();
                    (0, i.resolveStaleAt)(e, v).then(t => {
                        (0, i.writePrerenderResponseIntoCache)(e, u.FetchStrategy.PPR, _, void 0, g, w ? ? null, t, S, y, !1, i.segmentCacheMap)
                    }).catch(() => {}), r ? .cancel()
                }
            else r ? .cancel();
            null != P && (0, i.processRuntimePrefetchStream)(Date.now(), P, S, y).then(e => {
                null !== e && (0, i.writeDynamicRenderResponseIntoCache)(Date.now(), u.FetchStrategy.PPRRuntime, e.flightDatas, e.buildId, e.isResponsePartial, e.headVaryParams, e.rootVaryParamsIterable, e.staleAt, e.navigationSeed, null, i.segmentCacheMap)
            }).catch(() => {})
        }
        return {
            tree: N.route,
            cache: N.node,
            pushRef: {
                pendingPush: !1,
                mpaNavigation: !1,
                preserveCustomHistoryState: !0
            },
            focusAndScrollRef: {
                scrollRef: null,
                forceScroll: !1,
                onlyHashChange: !1,
                hashFragment: null
            },
            canonicalUrl: M,
            renderedSearch: y,
            nextUrl: ((0, o.extractPathFromFlightRouterState)(S) || p ? .pathname) ? ? null,
            previousNextUrl: null,
            debugInfo: null
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 425018, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findHeadInCache", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(813258),
        o = e.r(270725);

    function a(e, t) {
        return function e(t, r, a, l) {
            if (0 === Object.keys(r).length) return [t, a, l];
            let i = Object.keys(r).filter(e => "children" !== e);
            "children" in r && i.unshift("children");
            let u = t.slots;
            if (null !== u)
                for (let t of i) {
                    let [l, i] = r[t];
                    if (l === n.DEFAULT_SEGMENT_KEY) continue;
                    let d = u[t];
                    if (!d) continue;
                    let s = e(d, i, a + "/" + (0, o.createRouterCacheKey)(l), a + "/" + (0, o.createRouterCacheKey)(l, !0));
                    if (s) return s
                }
            return null
        }(e, t, "", "")
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 851323, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        onCaughtError: function() {
            return f
        },
        onUncaughtError: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(555682),
        l = e.r(265713),
        i = e.r(132061),
        u = e.r(528279),
        d = e.r(972383),
        s = a._(e.r(168027)),
        c = {
            decorateDevError: e => e,
            handleClientError: () => {},
            originConsoleError: console.error.bind(console)
        };

    function f(e, t) {
        let r, n = t.errorBoundary ? .constructor;
        if (r = r || n === d.ErrorBoundaryHandler && t.errorBoundary.props.errorComponent === s.default) return p(e);
        (0, i.isBailoutToCSRError)(e) || (0, l.isNextRouterError)(e) || c.originConsoleError(e)
    }

    function p(e) {
        (0, i.isBailoutToCSRError)(e) || (0, l.isNextRouterError)(e) || (0, u.reportGlobalError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 423755, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    let n = (0, e.r(543369).getDeploymentId)();
    globalThis.NEXT_DEPLOYMENT_ID = n, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 816565, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getObjectClassLabel: function() {
            return a
        },
        isPlainObject: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function a(e) {
        return Object.prototype.toString.call(e)
    }

    function l(e) {
        if ("[object Object]" !== a(e)) return !1;
        let t = Object.getPrototypeOf(e);
        return null === t || t.hasOwnProperty("isPrototypeOf")
    }
}, 302023, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return l
        },
        getProperError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(816565);

    function l(e) {
        return "object" == typeof e && null !== e && "name" in e && "message" in e
    }

    function i(e) {
        let t;
        return l(e) ? e : Object.defineProperty(Error((0, a.isPlainObject)(e) ? (t = new WeakSet, JSON.stringify(e, (e, r) => {
            if ("object" == typeof r && null !== r) {
                if (t.has(r)) return "[Circular]";
                t.add(r)
            }
            return r
        })) : e + ""), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        })
    }
}, 528279, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "reportGlobalError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "function" == typeof reportError ? reportError : e => {
        globalThis.console.error(e)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 597238, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isRecoverableError: function() {
            return s
        },
        onRecoverableError: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(555682),
        l = e.r(132061),
        i = a._(e.r(302023)),
        u = e.r(528279),
        d = new WeakSet;

    function s(e) {
        return d.has(e)
    }
    let c = e => {
        let t = (0, i.default)(e) && "cause" in e ? e.cause : e;
        (0, l.isBailoutToCSRError)(t) || (0, u.reportGlobalError)(t)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 462826, (e, t, r) => {
    if (e.i(247167), /(?:^|;\s)__vercel_toolbar=1(?:;|$)/.test(document.cookie)) {
        var n = document.createElement("script");
        n.src = "https://vercel.live/_next-live/feedback/feedback.js", n.setAttribute("data-explicit-opt-in", "true"), n.setAttribute("data-cookie-opt-in", "true"), n.setAttribute("data-deployment-id", globalThis.NEXT_DEPLOYMENT_ID), (document.head || document.documentElement).appendChild(n)
    }
}, 83793, (e, t, r) => {
    t.exports = [e.r(462826), {}]
}, 5526, (e, t, r) => {
    "use strict";
    e.i(247167); {
        let r = e.r(83793);
        t.exports = Array.isArray(r) ? r : [r]
    }
}]);