(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 297017, 662053, 929487, 284442, 318615, e => {
    "use strict";
    let t;
    var r = e.i(270950);
    e.s(["useLoader", () => r.G], 297017);
    var a = e.i(190072);

    function n() {
        let e = document.createElement("canvas");
        e.width = e.height = 1;
        let t = e.getContext("2d");
        return t && (t.fillStyle = "#1a1a1a", t.fillRect(0, 0, 1, 1)), e
    }
    class i extends a.ImageLoader {
        load(e, t, r, a) {
            return super.load(e, t, r, r => {
                console.warn("[3d] a picture didn't load, drawn blank:", e, r), t ? .(n())
            })
        }
    }
    class o extends a.TextureLoader {
        load(e, t, r, a) {
            let i = super.load(e, t, r, r => {
                console.warn("[3d] a picture didn't load, drawn blank:", e, r), i.image = n(), i.needsUpdate = !0, t ? .(i)
            });
            return i
        }
    }
    e.s(["SafeImageLoader", 0, i, "SafeTextureLoader", 0, o], 662053);
    var s = e.i(843476),
        l = a,
        h = e.i(271645),
        u = e.i(94800);

    function f(e) {
        let t, r, n, i = -1,
            o = 0;
        for (let a = 0; a < e.length; ++a) {
            let s = e[a];
            if (void 0 === t && (t = s.array.constructor), t !== s.array.constructor) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."), null;
            if (void 0 === r && (r = s.itemSize), r !== s.itemSize) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."), null;
            if (void 0 === n && (n = s.normalized), n !== s.normalized) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."), null;
            if (-1 === i && (i = s.gpuType), i !== s.gpuType) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."), null;
            o += s.count * r
        }
        let s = new t(o),
            l = new a.BufferAttribute(s, r, n),
            h = 0;
        for (let t = 0; t < e.length; ++t) {
            let a = e[t];
            if (a.isInterleavedBufferAttribute) {
                let e = h / r;
                for (let t = 0, n = a.count; t < n; t++)
                    for (let n = 0; n < r; n++) {
                        let r = a.getComponent(t, n);
                        l.setComponent(t + e, n, r)
                    }
            } else s.set(a.array, h);
            h += a.count * r
        }
        return void 0 !== i && (l.gpuType = i), l
    }
    var c = e.i(662181),
        d = e.i(592563);

    function p(e = 10) {
        let t = document.createElement("canvas");
        t.width = Math.round(c.TAPE.w * e), t.height = Math.round(c.TAPE.h * e);
        let r = t.getContext("2d");
        return r.setTransform(e, 0, 0, -e, t.width / 2, t.height / 2), {
            canvas: t,
            ctx: r,
            scale: e
        }
    }
    let m = [],
        g = !1;

    function v(e, t) {
        let r = {
            priority: e,
            run: t,
            cancelled: !1
        };
        return m.push(r), m.sort((e, t) => e.priority - t.priority),
            function e() {
                if (g || !m.length) return;
                g = !0;
                let t = () => {
                    g = !1;
                    let t = m.shift();
                    t && !t.cancelled && t.run(), e()
                };
                "function" == typeof window.requestIdleCallback ? window.requestIdleCallback(t, {
                    timeout: 300
                }) : window.setTimeout(t, 16)
            }(), () => {
                r.cancelled = !0
            }
    }

    function y(e, t) {
        let {
            width: r,
            height: a
        } = e, n = e.getContext("2d").getImageData(0, 0, r, a).data, i = document.createElement("canvas");
        i.width = r, i.height = a;
        let o = i.getContext("2d"),
            s = o.createImageData(r, a),
            l = s.data,
            h = (e, t) => {
                let i = Math.min(r - 1, Math.max(0, e));
                return n[(Math.min(a - 1, Math.max(0, t)) * r + i) * 4] / 255
            };
        for (let e = 0; e < a; e++)
            for (let a = 0; a < r; a++) {
                let n = h(a + 1, e) - h(a - 1, e),
                    i = h(a, e - 1) - h(a, e + 1),
                    o = -n * t,
                    s = -i * t,
                    u = 1,
                    f = Math.hypot(o, s, 1);
                o /= f, s /= f, u /= f;
                let c = (e * r + a) * 4;
                l[c] = (.5 * o + .5) * 255, l[c + 1] = (.5 * s + .5) * 255, l[c + 2] = (.5 * u + .5) * 255, l[c + 3] = 255
            }
        return o.putImageData(s, 0, 0), i
    }
    let w = null;

    function b() {
        if (w) return w;
        let {
            canvas: e,
            ctx: t
        } = p(9);
        ! function(e) {
            let {
                w: t,
                h: r
            } = c.TAPE;
            e.fillStyle = "rgb(128,128,128)", e.fillRect(-t / 2, -r / 2, t, r);
            let a = (r, a, n) => {
                e.fillStyle = "rgb(70,70,70)";
                for (let i = r + n / 2; i < a; i += n) e.fillRect(-t / 2 + 3.2, i - .16, t - 6.4, .32)
            };
            for (let r of (a(c.TAPE.plateau[0], c.TAPE.plateau[1], .85), a(c.TAPE.grip[0], c.TAPE.grip[1], .85), e.fillStyle = "rgb(40,40,40)", [c.TAPE.plateau[0] - .6, c.TAPE.plateau[1] + .5, c.TAPE.grip[1] + .6, c.TAPE.doorEdge])) e.fillRect(-t / 2 + 1.6, r - .25, t - 3.2, .5);
            for (let t of (e.strokeStyle = "rgb(205,205,205)", e.lineWidth = .7, c.WINDOWS)) {
                var n, i, o, s, l;
                n = t.x - t.w / 2, i = t.y - t.h / 2, o = t.w, s = t.h, l = t.r, e.beginPath(), e.roundRect(n, i, o, s, l), e.stroke()
            }
            for (let [t, r] of (e.lineWidth = .5, e.strokeStyle = "rgb(60,60,60)", c.SCREWS)) e.beginPath(), e.arc(t, r, 3.6, 0, 2 * Math.PI), e.stroke()
        }(t);
        let r = document.createElement("canvas");
        r.width = e.width, r.height = e.height;
        let n = r.getContext("2d");
        n.filter = "blur(1.2px)", n.drawImage(e, 0, 0);
        let i = new a.CanvasTexture(y(r, 5));
        for (let e of [i]) e.colorSpace = a.NoColorSpace, e.wrapS = e.wrapT = a.ClampToEdgeWrapping, e.repeat.set(1 / c.TAPE.w, 1 / c.TAPE.h), e.offset.set(.5, .5), e.anisotropy = 8;
        return w = {
            normal: i
        }
    }
    let x = "rgba(0,0,0,0.16)";

    function M(e, t, r, a, n, i, o, s = "left") {
        e.save(), e.fillStyle = i, e.font = `${n}px ${o}`, e.textAlign = s, e.textBaseline = "alphabetic", t.forEach((t, i) => {
            e.save(), e.translate(r, a - i * n * 1.35), e.scale(1, -1), e.fillText(t, 0, 0), e.restore()
        }), e.restore()
    }

    function E(e, t, r = .35) {
        e.save(), e.lineWidth = r, e.strokeStyle = "rgba(255,255,255,0.55)", e.translate(-.25, .25), t(), e.stroke(), e.translate(.5, -.5), e.strokeStyle = x, t(), e.stroke(), e.restore()
    }
    let T = null;

    function S() {
        if (T) return T;
        let {
            canvas: e,
            ctx: t
        } = p(10), {
            w: r,
            h: n
        } = c.TAPE, i = () => {
            let e = (0, d.fontFamily)("--font-mono", "ui-monospace, monospace");
            t.fillStyle = "#ffffff", t.fillRect(-r / 2, -n / 2, r, n);
            let a = 17,
                i = () => (a = 16807 * a % 0x7fffffff) / 0x7fffffff;
            for (let e = 0; e < 900; e++) t.fillStyle = `rgba(0,0,0,${.015+.03*i()})`, t.beginPath(), t.arc((i() - .5) * r, (i() - .5) * n, .5 + 4 * i(), 0, 2 * Math.PI), t.fill();
            for (let e of c.TAPE.reels)
                for (let r of [c.TAPE.flangeR + 1.2, 16.5]) E(t, () => {
                    t.beginPath(), t.arc(e.x, e.y, r, 0, 2 * Math.PI)
                }, .45);
            t.fillStyle = "rgba(0,0,0,0.08)";
            for (let e = -60; e <= 60; e += 1.1)
                for (let r = -49; r <= -38; r += 1.1) t.fillRect(e, r, .5, .5);
            for (let [e, r, a] of (E(t, () => {
                    t.beginPath(), t.moveTo(-66, -50), t.lineTo(-62, -36.5), t.lineTo(62, -36.5), t.lineTo(66, -50)
                }, .5), t.fillStyle = "rgba(0,0,0,0.75)", [
                    [-34, -46, 1.6],
                    [-20, -46, 1.6],
                    [20, -46, 1.6],
                    [34, -46, 1.6],
                    [0, -40, 1.2]
                ])) t.beginPath(), t.arc(e, r, a, 0, 2 * Math.PI), t.fill();
            for (let e = -64; e <= 64; e += 16) E(t, () => {
                t.beginPath(), t.moveTo(e, 27), t.lineTo(e, 36)
            });
            E(t, () => {
                t.beginPath(), t.roundRect(-70, 25.5, 140, 12.5, 1.2)
            }, .45), M(t, ["SIDE A"], -86, 28, 2, x, e), M(t, ["▲ THIS SIDE UP"], 86, 28, 1.6, x, e, "right"), M(t, ["RECORD ◄"], -72, -32.5, 1.5, x, e), M(t, ["ARC ©'26 · VIDEO CASSETTE"], 72, -32.5, 1.5, x, e, "right")
        };
        i();
        let o = new a.CanvasTexture(e);
        return o.colorSpace = a.SRGBColorSpace, o.anisotropy = 8, document.fonts ? .ready.then(() => {
            i(), o.needsUpdate = !0
        }), T = o, o
    }
    let A = null;

    function C() {
        if (A) return A;
        let e = document.createElement("canvas");
        e.width = e.height = 1024;
        let t = e.getContext("2d"),
            r = 3,
            n = () => (r = 16807 * r % 0x7fffffff) / 0x7fffffff;
        for (let e = 512; e > 0; e -= 1.5) {
            let r = 22 + 16 * n();
            t.fillStyle = `rgb(${r+10},${r+4},${r})`, t.beginPath(), t.arc(512, 512, e, 0, 2 * Math.PI), t.fill()
        }
        let i = new a.CanvasTexture(e);
        return i.colorSpace = a.SRGBColorSpace, i.anisotropy = 8, A = i, i
    }
    let P = null;

    function R() {
        if (P) return P;
        let e = document.createElement("canvas");
        e.width = e.height = 512;
        let t = e.getContext("2d"),
            r = 5,
            n = () => (r = 16807 * r % 0x7fffffff) / 0x7fffffff;
        for (let e = 256; e > 0; e -= 1) {
            let r = 90 + 90 * n();
            t.fillStyle = `rgb(${r},${r},${r})`, t.beginPath(), t.arc(256, 256, e, 0, 2 * Math.PI), t.fill()
        }
        let i = new a.CanvasTexture(e);
        return i.colorSpace = a.NoColorSpace, P = i, i
    }

    function _({
        image: e,
        focus: t,
        index: r,
        w: n,
        h: i,
        quarter: o = !1
    }) {
        let s, l = Math.round(1024 * i / n),
            [h, u] = o ? [l, 1024] : [1024, l],
            f = document.createElement("canvas");
        f.width = h, f.height = u;
        let c = f.getContext("2d"),
            d = 1 + 7919 * r,
            p = () => (d = 16807 * d % 0x7fffffff) / 0x7fffffff,
            m = f,
            g = document.createElement("canvas");
        if (g.width = 1024, g.height = l, (() => {
                d = 1 + 7919 * r, c.globalCompositeOperation = "source-over", c.clearRect(0, 0, h, u), c.fillStyle = "#ece5d5", c.fillRect(0, 0, h, u);
                let a = .059 * Math.min(h, u),
                    n = h - 2 * a,
                    i = u - 2 * a,
                    o = e.width / e.height,
                    s = n / i,
                    l = e.width,
                    f = e.height;
                o > s ? l = e.height * s : f = e.width / s;
                let m = t ? .x ? ? .5,
                    g = t ? .y ? ? .5,
                    v = Math.min(Math.max(m * e.width - l / 2, 0), e.width - l),
                    y = Math.min(Math.max(g * e.height - f / 2, 0), e.height - f);
                c.drawImage(e, v, y, l, f, a, a, n, i), c.globalCompositeOperation = "screen", c.fillStyle = "rgba(60,48,32,0.35)", c.fillRect(a, a, n, i), c.globalCompositeOperation = "multiply", c.fillStyle = "rgba(244,226,190,0.55)", c.fillRect(0, 0, h, u), c.globalCompositeOperation = "saturation", c.fillStyle = "rgba(128,128,128,0.25)", c.fillRect(a, a, n, i), c.globalCompositeOperation = "source-over";
                for (let e = 0; e < 9e3; e++) {
                    let e = 255 * (p() > .5);
                    c.fillStyle = `rgba(${e},${e},${e},${.03+.05*p()})`, c.fillRect(p() * h, p() * u, 1 + 2 * p(), 1 + 2 * p())
                }
                for (let e = 0; e < 70; e++) {
                    let e = .75 > p(),
                        t = e ? .5 > p() ? p() * h * .12 : h - p() * h * .12 : p() * h,
                        r = e ? p() * u : .5 > p() ? p() * u * .15 : u - p() * u * .15;
                    c.fillStyle = `rgba(236,229,213,${.25+.5*p()})`, c.beginPath(), c.ellipse(t, r, 4 + 26 * p(), 2 + 9 * p(), p() * Math.PI, 0, 2 * Math.PI), c.fill()
                }
                for (let e = 0; e < 26; e++) {
                    let e = p() * h,
                        t = p() * u,
                        r = (p() - .5) * .9,
                        a = 40 + 260 * p();
                    c.strokeStyle = `rgba(255,250,240,${.18+.35*p()})`, c.lineWidth = .6 + 1.4 * p(), c.beginPath(), c.moveTo(e, t), c.quadraticCurveTo(e + Math.cos(r) * a * .5, t + Math.sin(r) * a * .5 + (p() - .5) * 20, e + Math.cos(r) * a, t + Math.sin(r) * a), c.stroke()
                }
                let w = h * (.15 + .3 * p()),
                    b = w + h * (.2 + .35 * p());
                c.lineWidth = 3, c.strokeStyle = "rgba(40,30,20,0.28)", c.beginPath(), c.moveTo(w, -5), c.lineTo(b, u + 5), c.stroke(), c.lineWidth = 2, c.strokeStyle = "rgba(255,250,240,0.45)", c.beginPath(), c.moveTo(w + 4, -5), c.lineTo(b + 4, u + 5), c.stroke();
                for (let e = 0; e < 14; e++) {
                    let e = c.createRadialGradient(p() * h, p() * u, 0, p() * h, p() * u, 60 + 180 * p());
                    e.addColorStop(0, `rgba(120,90,40,${.06+.1*p()})`), e.addColorStop(1, "rgba(120,90,40,0)"), c.fillStyle = e, c.fillRect(0, 0, h, u)
                }
                for (let e = 0; e < 160; e++) c.fillStyle = `rgba(30,22,14,${.2+.5*p()})`, c.beginPath(), c.arc(p() * h, p() * u, .6 + 2 * p(), 0, 2 * Math.PI), c.fill();
                c.globalCompositeOperation = "destination-out";
                for (let e = 0; e < 420; e++) {
                    let e = Math.floor(4 * p()),
                        t = p(),
                        r = 7 * p(),
                        a = 0 === e ? t * h : 1 === e ? h - r : 2 === e ? t * h : r,
                        n = 0 === e ? r : 1 === e ? t * u : 2 === e ? u - r : t * u;
                    c.beginPath(), c.arc(a, n, 1.5 + 5 * p(), 0, 2 * Math.PI), c.fill()
                }
                let x = Math.floor(4 * p()),
                    M = h * (.06 + .06 * p()),
                    E = u * (.1 + .12 * p()),
                    [T, S, A, C] = [
                        [0, 0, 1, 1],
                        [h, 0, -1, 1],
                        [h, u, -1, -1],
                        [0, u, 1, -1]
                    ][x];
                c.beginPath(), c.moveTo(T - 2 * A, S - 2 * C), c.lineTo(T + A * M, S - 2 * C);
                for (let e = 1; e < 7; e++) {
                    let t = e / 7;
                    c.lineTo(T + A * M * (1 - t) + (p() - .5) * 10, S + C * E * t + (p() - .5) * 10)
                }
                c.lineTo(T - 2 * A, S + C * E), c.closePath(), c.fill(), c.globalCompositeOperation = "source-over"
            })(), o) {
            (m = document.createElement("canvas")).width = 1024, m.height = l;
            let e = m.getContext("2d");
            e.setTransform(0, 1, -1, 0, 1024, 0), e.drawImage(f, 0, 0)
        }
        let v = new a.CanvasTexture(m);
        v.colorSpace = a.SRGBColorSpace, v.anisotropy = 8;
        let w = new a.CanvasTexture(((s = g.getContext("2d")).filter = "grayscale(1) blur(1.5px)", s.clearRect(0, 0, 1024, l), s.drawImage(m, 0, 0), y(g, 2.2)));
        return w.colorSpace = a.NoColorSpace, w.anisotropy = 8, {
            map: v,
            normal: w
        }
    }
    e.s(["floorTexture", 0, S, "packTexture", 0, C, "shellMaps", 0, b, "stickerTexture", 0, _, "turnedTexture", 0, R, "whenIdle", 0, v], 929487);
    let [I, k] = c.TAPE.tapeZ, F = k - I, U = c.TAPE.t / 2 - 1.6, O = k + 4.3;

    function B(e, t, r, a, n = 0, i = 0) {
        let o = n - t / 2,
            s = n + t / 2,
            l = i - r / 2,
            h = i + r / 2;
        return e.moveTo(o + a, l), e.lineTo(s - a, l), e.absarc(s - a, l + a, a, -Math.PI / 2, 0, !1), e.lineTo(s, h - a), e.absarc(s - a, h - a, a, 0, Math.PI / 2, !1), e.lineTo(o + a, h), e.absarc(o + a, h - a, a, Math.PI / 2, Math.PI, !1), e.lineTo(o, l + a), e.absarc(o + a, l + a, a, Math.PI, 1.5 * Math.PI, !1), e
    }

    function D(e) {
        let t = function(e, t = !1) {
            let r = null !== e[0].index,
                n = new Set(Object.keys(e[0].attributes)),
                i = new Set(Object.keys(e[0].morphAttributes)),
                o = {},
                s = {},
                l = e[0].morphTargetsRelative,
                h = new a.BufferGeometry,
                u = 0;
            for (let a = 0; a < e.length; ++a) {
                let f = e[a],
                    c = 0;
                if (r !== (null !== f.index)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + ". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."), null;
                for (let e in f.attributes) {
                    if (!n.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + '. All geometries must have compatible attributes; make sure "' + e + '" attribute exists among all geometries, or in none of them.'), null;
                    void 0 === o[e] && (o[e] = []), o[e].push(f.attributes[e]), c++
                }
                if (c !== n.size) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + ". Make sure all geometries have the same number of attributes."), null;
                if (l !== f.morphTargetsRelative) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + ". .morphTargetsRelative must be consistent throughout all geometries."), null;
                for (let e in f.morphAttributes) {
                    if (!i.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + ".  .morphAttributes must be consistent throughout all geometries."), null;
                    void 0 === s[e] && (s[e] = []), s[e].push(f.morphAttributes[e])
                }
                if (t) {
                    let e;
                    if (r) e = f.index.count;
                    else {
                        if (void 0 === f.attributes.position) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + a + ". The geometry must have either an index or a position attribute"), null;
                        e = f.attributes.position.count
                    }
                    h.addGroup(u, e, a), u += e
                }
            }
            if (r) {
                let t = 0,
                    r = [];
                for (let a = 0; a < e.length; ++a) {
                    let n = e[a].index;
                    for (let e = 0; e < n.count; ++e) r.push(n.getX(e) + t);
                    t += e[a].attributes.position.count
                }
                h.setIndex(r)
            }
            for (let e in o) {
                let t = f(o[e]);
                if (!t) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " attribute."), null;
                h.setAttribute(e, t)
            }
            for (let e in s) {
                let t = s[e][0].length;
                if (0 !== t) {
                    h.morphAttributes = h.morphAttributes || {}, h.morphAttributes[e] = [];
                    for (let r = 0; r < t; ++r) {
                        let t = [];
                        for (let a = 0; a < s[e].length; ++a) t.push(s[e][a][r]);
                        let a = f(t);
                        if (!a) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " morphAttribute."), null;
                        h.morphAttributes[e].push(a)
                    }
                }
            }
            return h
        }(e.map(e => e.index ? e.toNonIndexed() : e));
        if (!t) throw Error("ClearTape: incompatible geometry attributes");
        return t
    }

    function L(e, t, r, a, n, i) {
        let o = new l.Shape;
        o.absarc(0, 0, e, 0, 2 * Math.PI, !1);
        let s = e - r;
        for (let e = 0; e < a; e++) {
            let r = (e + .5) / a * Math.PI * 2,
                i = Math.PI / a,
                h = r - i + n / 2 / s,
                u = r + i - n / 2 / s,
                f = r - i + n / 2 / t,
                c = r + i - n / 2 / t,
                d = new l.Path;
            d.absarc(0, 0, s, h, u, !1), d.lineTo(Math.cos(c) * t, Math.sin(c) * t), d.absarc(0, 0, t, c, f, !0), d.closePath(), o.holes.push(d)
        }
        return o.holes.push(new l.Path().absarc(0, 0, c.TAPE.hubR - .2, 0, 2 * Math.PI, !0)), new l.ExtrudeGeometry(o, {
            depth: i,
            bevelEnabled: !1,
            curveSegments: 48
        })
    }

    function G(e, t, r, a, n = !1) {
        let i = new l.CylinderGeometry(e, t, r, a, 1, n);
        return i.rotateX(Math.PI / 2), i
    }

    function z(e, t, r, a, n) {
        let i = new l.Vector2().subVectors(r, e),
            o = i.length();
        i.divideScalar(o);
        let s = new l.Vector2(-i.y, i.x),
            h = (t - a) / o,
            u = Math.sqrt(Math.max(0, 1 - h * h)) * n,
            f = new l.Vector2(i.x * h + s.x * u, i.y * h + s.y * u);
        return {
            p1: e.clone().addScaledVector(f, t),
            p2: r.clone().addScaledVector(f, a),
            angle: Math.atan2(f.y, f.x)
        }
    }

    function H(e, t, r, a, n) {
        let i = [];
        for (let o = 0; o <= n; o++) {
            let s = r + (a - r) * o / n;
            i.push(new l.Vector2(e.x + Math.cos(s) * t, e.y + Math.sin(s) * t))
        }
        return i
    }

    function j(e) {
        let t = c.TAPE.hubR;
        return Math.sqrt(t * t + e * (c.TAPE.packMax * c.TAPE.packMax - t * t))
    }
    let W = null,
        N = null,
        V = (0, h.memo)(function({
            image: e,
            focus: t,
            index: r,
            progress: a,
            quarter: n = !1,
            drive: i,
            priority: o = 0,
            lite: f = !1
        }) {
            let d, p, {
                    geo: m,
                    mat: g
                } = (N || (N = {
                    geo: function() {
                        let {
                            w: e,
                            h: t,
                            t: r
                        } = c.TAPE, a = B(new l.Shape, e - 2.3, t - 2.3, 2.0500000000000003);
                        for (let e of c.WINDOWS.slice(0, 2)) a.holes.push(B(new l.Path, e.w + 2.3, e.h + 2.3, e.r + 1.15, e.x, e.y));
                        let n = new l.ExtrudeGeometry(a, {
                            depth: r - 2.3,
                            bevelEnabled: !0,
                            bevelThickness: 1.15,
                            bevelSize: 1.15,
                            bevelSegments: 5,
                            curveSegments: 10
                        });
                        n.translate(0, 0, -(r - 2.3) / 2);
                        let i = D(c.WINDOWS.slice(0, 2).map(e => {
                                let t = new l.ExtrudeGeometry(B(new l.Shape, e.w + 1, e.h + 1, e.r), {
                                    depth: .8,
                                    bevelEnabled: !1,
                                    curveSegments: 10
                                });
                                return t.translate(e.x, e.y, r / 2 - 1.6), t
                            })),
                            o = new l.PlaneGeometry(e - 3, t - 3);
                        o.translate(0, 0, -r / 2 + 1.9);
                        let s = L(c.TAPE.flangeR, 16, 1.8, 6, 3.2, .8);
                        s.translate(0, 0, k + .1);
                        let h = L(c.TAPE.flangeR, 16, 2.4, 6, 4.2, .8);
                        h.rotateZ(Math.PI / 6), h.translate(0, 0, I - .9);
                        let u = G(1, 1, F, 128, !0);
                        u.translate(0, 0, (I + k) / 2);
                        let f = new l.CircleGeometry(1, 128);
                        f.translate(0, 0, k + .02);
                        let d = G(c.TAPE.hubR, c.TAPE.hubR, O - (I - 1), 64, !0);
                        d.translate(0, 0, (O + I - 1) / 2);
                        let p = new l.TorusGeometry(c.TAPE.hubR - .35, .45, 10, 64);
                        p.translate(0, 0, O);
                        let m = D([d, p, ...Array.from({
                                length: 6
                            }, (e, t) => {
                                let r = new l.BoxGeometry(2.4, 1.5, O - I - 1.5);
                                return r.translate(5.7, 0, (O + I) / 2 - .4), r.rotateZ(t / 6 * Math.PI * 2), r
                            })]),
                            g = new l.RingGeometry(6.4, c.TAPE.hubR, 64, 2);
                        g.translate(0, 0, O);
                        let v = G(6.4, 6.4, O - I, 48, !0);
                        v.translate(0, 0, (O + I) / 2);
                        let y = new l.CircleGeometry(6.4, 32);
                        y.translate(0, 0, I + 1);
                        let w = D([v, y]),
                            b = [],
                            x = [],
                            M = [];
                        for (let e of c.TAPE.rollers) {
                            let t = G(c.TAPE.rollerR, c.TAPE.rollerR, F + .4, 36);
                            for (let r of (t.translate(e.x, e.y, (I + k) / 2), b.push(t), [I - .55, k + .55])) {
                                let t = G(c.TAPE.rollerR + 1.1, c.TAPE.rollerR + 1.1, .7, 36);
                                t.translate(e.x, e.y, r), M.push(t)
                            }
                            let a = G(1.05, 1.05, r - 4.6, 20);
                            a.translate(e.x, e.y, -.6), M.push(a)
                        }
                        let E = c.TAPE.reels[1].x,
                            T = new l.BoxGeometry(2 * E, 5.2, .3, 60, 1, 1),
                            S = e => (e / E) ** 2 * 1.5; {
                            let e = T.attributes.position;
                            for (let t = 0; t < e.count; t++) e.setZ(t, e.getZ(t) - S(e.getX(t)));
                            T.computeVertexNormals()
                        }
                        let A = U - .9;
                        for (let e of (T.translate(0, c.TAPE.reels[0].y, A), M.push(T), c.TAPE.reels)) {
                            let t = G(4.4, 4.4, .4, 40);
                            t.translate(e.x, e.y, A - S(e.x) - .1), M.push(t)
                        }
                        class C extends l.Curve {
                            constructor() {
                                super()
                            }
                            getPoint(e, t = new l.Vector3) {
                                let r = e * Math.PI * 18;
                                return t.set(-24 + 12 * e, 29.2 + 1.5 * Math.cos(r), 1.5 + 1.5 * Math.sin(r))
                            }
                        }
                        x.push(new l.TubeGeometry(new C, 220, .22, 6, !1));
                        let P = [],
                            R = new l.BoxGeometry(12, 9, 18.5);
                        R.translate(0, 33.2, -.9), P.push(R);
                        let _ = new l.Shape;
                        _.moveTo(-27.5, 19.2), _.lineTo(-10, 22.2), _.lineTo(10, 22.2), _.lineTo(27.5, 19.2), _.lineTo(28.5, 21.6), _.lineTo(10.5, 24.4), _.lineTo(-10.5, 24.4), _.lineTo(-28.5, 21.6), _.closePath();
                        let z = new l.ExtrudeGeometry(_, {
                            depth: 1.6,
                            bevelEnabled: !1
                        });
                        z.translate(0, 0, k + 1.4), P.push(z);
                        let H = new l.Shape;
                        H.moveTo(86, 10), H.lineTo(90.5, 10), H.lineTo(90.5, 28), H.lineTo(88.4, 28), H.lineTo(88.4, 13), H.lineTo(86, 13), H.closePath();
                        let j = new l.ExtrudeGeometry(H, {
                            depth: 2.2,
                            bevelEnabled: !1
                        });
                        j.translate(0, 0, -4), P.push(j);
                        let W = new l.BoxGeometry(9, 3.2, 8);
                        W.translate(-80, -t / 2 + 3.2, -6.5), P.push(W);
                        let N = [],
                            V = new l.BoxGeometry(6.2, 4.6, .4);
                        V.translate(0, 33.2, 8.5), N.push(V);
                        let $ = [],
                            q = r / 2 - 1.25;
                        for (let [e, t] of c.SCREWS) {
                            let r = G(2.3, 2.3, .9, 32);
                            r.translate(e, t, q);
                            let a = new l.TorusGeometry(2.75, .34, 8, 40);
                            a.translate(e, t, q), $.push(r, a);
                            let n = new l.BoxGeometry(3, .5, .3);
                            n.translate(e, t, q + .35);
                            let i = new l.BoxGeometry(.5, 3, .3);
                            i.translate(e, t, q + .35), N.push(n, i)
                        }
                        let X = function(e, t, r, a = 0, n = 0) {
                            let i = e.attributes.position,
                                o = new Float32Array(2 * i.count);
                            for (let e = 0; e < i.count; e++) o[2 * e] = (i.getX(e) - a + t / 2) / t, o[2 * e + 1] = (i.getY(e) - n + r / 2) / r;
                            return e.setAttribute("uv", new l.BufferAttribute(o, 2)), e
                        }(new l.PlaneGeometry(c.CARD.w, c.CARD.h, 1, 1), c.CARD.w, c.CARD.h);
                        X.translate(c.CARD.x, c.CARD.y, r / 2 + .06);
                        let Y = D(c.WINDOWS.slice(0, 2).map(e => {
                            let t = new l.ShapeGeometry(B(new l.Shape, e.w + 2.3 + 1, e.h + 2.3 + 1, e.r + 1.15, e.x, e.y), 10);
                            return t.rotateY(Math.PI), t.translate(0, 0, -r / 2 + .6), t
                        }));
                        return {
                            shell: n,
                            floor: o,
                            flangeTop: s,
                            flangeBottom: h,
                            packWall: u,
                            packTop: f,
                            hubBody: m,
                            hubCap: g,
                            hubBlack: w,
                            nylon: D(b),
                            chrome: D(x),
                            steel: D(M),
                            molded: D(P),
                            black: D(N),
                            screws: D($),
                            card: X,
                            panes: i,
                            back: Y
                        }
                    }(),
                    mat: ((d = S()).repeat.set((c.TAPE.w - 3) / c.TAPE.w, (c.TAPE.h - 3) / c.TAPE.h), d.offset.set(1.5 / c.TAPE.w, 1.5 / c.TAPE.h), {
                        floorMap: d,
                        floor: new l.MeshStandardMaterial({
                            color: 2500394,
                            map: d,
                            roughness: .6
                        }),
                        flange: new l.MeshPhysicalMaterial({
                            color: 2895409,
                            roughness: .25,
                            clearcoat: .6
                        }),
                        hub: new l.MeshStandardMaterial({
                            color: 0xe6e3dc,
                            roughness: .5,
                            roughnessMap: R()
                        }),
                        chrome: new l.MeshStandardMaterial({
                            color: 0xe4e6ea,
                            metalness: 1,
                            roughness: .14
                        }),
                        steel: new l.MeshStandardMaterial({
                            color: 0xb9bdc3,
                            metalness: 1,
                            roughness: .4
                        }),
                        nylon: new l.MeshStandardMaterial({
                            color: 0xe8e4da,
                            metalness: 0,
                            roughness: .55
                        }),
                        black: new l.MeshStandardMaterial({
                            color: 723724,
                            metalness: .2,
                            roughness: .6
                        }),
                        screws: new l.MeshStandardMaterial({
                            color: 1776413,
                            metalness: .7,
                            roughness: .35
                        }),
                        tape: new l.MeshPhysicalMaterial({
                            color: 2826264,
                            metalness: .35,
                            roughness: .3,
                            clearcoat: .4,
                            side: l.DoubleSide
                        }),
                        pack: new l.MeshPhysicalMaterial({
                            color: 0xffffff,
                            map: C(),
                            metalness: .3,
                            roughness: .34,
                            clearcoat: .5,
                            clearcoatRoughness: .2
                        })
                    })
                }), N),
                y = (W || (p = b(), W = {
                    shell: new l.MeshPhysicalMaterial({
                        color: 1315862,
                        metalness: 0,
                        roughness: .5,
                        normalMap: p.normal,
                        normalScale: new l.Vector2(1.4, 1.4),
                        clearcoat: .25,
                        clearcoatRoughness: .35,
                        envMapIntensity: .9
                    }),
                    glass: new l.MeshPhysicalMaterial({
                        color: 0xffffff,
                        transparent: !0,
                        opacity: .1,
                        depthWrite: !1,
                        roughness: .04,
                        clearcoat: .5,
                        envMapIntensity: 1.4
                    }),
                    molded: new l.MeshStandardMaterial({
                        color: 2039843,
                        roughness: .45
                    })
                }), W),
                w = (0, h.useRef)([]),
                x = j(1 - a),
                M = j(a),
                E = (0, h.useMemo)(() => (function(e, t) {
                    let [r, a] = c.TAPE.rollers, [n, i] = c.TAPE.reels, o = c.TAPE.rollerR + .25, s = z(new l.Vector2(n.x, n.y), e + .25, new l.Vector2(r.x, r.y), o, 1), h = z(new l.Vector2(i.x, i.y), t + .25, new l.Vector2(a.x, a.y), o, -1), u = s.angle;
                    return u < Math.PI / 2 && (u += 2 * Math.PI),
                        function(e, t, r) {
                            let a = [],
                                n = [],
                                i = [],
                                o = e.length,
                                s = e.map((t, r) => {
                                    let a = e[Math.max(0, r - 1)],
                                        n = e[Math.min(o - 1, r + 1)],
                                        i = new l.Vector2().subVectors(n, a).normalize();
                                    return new l.Vector2(-i.y, i.x)
                                });
                            for (let l of [1, -1]) {
                                let h = a.length / 3;
                                e.forEach((e, i) => {
                                    let o = s[i],
                                        h = e.x + .25 * o.x * l,
                                        u = e.y + .25 * o.y * l;
                                    a.push(h, u, t, h, u, r), n.push(o.x * l, o.y * l, 0, o.x * l, o.y * l, 0)
                                });
                                for (let e = 0; e < o - 1; e++) {
                                    let t = h + 2 * e,
                                        r = t + 1,
                                        a = t + 2,
                                        n = t + 3;
                                    1 === l ? i.push(t, r, a, r, n, a) : i.push(t, a, r, r, a, n)
                                }
                            }
                            let h = a.length / 3;
                            e.forEach((e, t) => {
                                let i = s[t];
                                a.push(e.x + .25 * i.x, e.y + .25 * i.y, r, e.x - .25 * i.x, e.y - .25 * i.y, r), n.push(0, 0, 1, 0, 0, 1)
                            });
                            for (let e = 0; e < o - 1; e++) {
                                let t = h + 2 * e,
                                    r = t + 1;
                                i.push(r, r + 2, t, t, r + 2, t + 2)
                            }
                            let u = new l.BufferGeometry;
                            return u.setAttribute("position", new l.Float32BufferAttribute(a, 3)), u.setAttribute("normal", new l.Float32BufferAttribute(n, 3)), u.setIndex(i), u
                        }([s.p1, ...H(r, o, u, Math.PI / 2, 18), ...H(a, o, Math.PI / 2, h.angle, 18), h.p1], I, k)
                })(x, M), [x, M]);
            (0, h.useEffect)(() => () => E.dispose(), [E]);
            let [T, A] = (0, h.useState)(null), P = t ? .x, V = t ? .y;
            (0, h.useEffect)(() => {
                if (f) return;
                let t = null,
                    a = v(o, () => {
                        A(t = _({
                            image: e.image,
                            focus: void 0 === P || void 0 === V ? void 0 : {
                                x: P,
                                y: V
                            },
                            index: r,
                            quarter: n,
                            w: c.CARD.w,
                            h: c.CARD.h
                        }))
                    });
                return () => {
                    a(), t ? .map.dispose(), t ? .normal.dispose()
                }
            }, [e, P, V, r, n, o, f]);
            let $ = (0, h.useRef)(null);
            (0, u.useFrame)((e, t) => {
                let r = Math.min(t, .1),
                    a = [x, M];
                w.current.forEach((e, t) => {
                    e && (e.rotation.z -= i.speed / a[t] * r)
                });
                let o = $.current;
                if (o) {
                    let e, t = ((e = i.out) < .5 ? 2 * e * e : 1 - (-2 * e + 2) ** 2 / 2) * (n ? c.PEEK.quarter : c.PEEK.wide) / 2;
                    o.position.set(n ? t : 0, n ? 0 : t, 0), o.visible = !f || i.out > 5e-4
                }
            });
            let q = !f || n,
                X = !f;
            return (0, s.jsxs)("group", {
                ref: $,
                children: [q && (0, s.jsx)("mesh", {
                    geometry: m.floor,
                    material: g.floor
                }), q && c.TAPE.reels.map((e, t) => {
                    let a = 0 === t ? x : M;
                    return (0, s.jsxs)("group", {
                        position: [e.x, e.y, 0],
                        "rotation-z": 1.3 * t + .7 * r,
                        ref: e => {
                            w.current[t] = e
                        },
                        children: [(0, s.jsx)("mesh", {
                            geometry: m.flangeBottom,
                            material: g.flange
                        }), (0, s.jsx)("mesh", {
                            geometry: m.packWall,
                            material: g.tape,
                            scale: [a, a, 1]
                        }), (0, s.jsx)("mesh", {
                            geometry: m.packTop,
                            material: g.pack,
                            scale: [a, a, 1]
                        }), (0, s.jsx)("mesh", {
                            geometry: m.flangeTop,
                            material: g.flange
                        }), (0, s.jsx)("mesh", {
                            geometry: m.hubBody,
                            material: g.hub
                        }), (0, s.jsx)("mesh", {
                            geometry: m.hubCap,
                            material: g.hub
                        }), (0, s.jsx)("mesh", {
                            geometry: m.hubBlack,
                            material: g.black
                        })]
                    }, t)
                }), X && (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("mesh", {
                        geometry: E,
                        material: g.tape
                    }), (0, s.jsx)("mesh", {
                        geometry: m.nylon,
                        material: g.nylon
                    }), (0, s.jsx)("mesh", {
                        geometry: m.chrome,
                        material: g.chrome
                    }), (0, s.jsx)("mesh", {
                        geometry: m.steel,
                        material: g.steel
                    }), (0, s.jsx)("mesh", {
                        geometry: m.molded,
                        material: y.molded
                    }), (0, s.jsx)("mesh", {
                        geometry: m.black,
                        material: g.black
                    })]
                }), (0, s.jsx)("mesh", {
                    geometry: m.screws,
                    material: g.screws
                }), (0, s.jsx)("mesh", {
                    geometry: m.shell,
                    material: y.shell
                }), q && (0, s.jsx)("mesh", {
                    geometry: m.panes,
                    material: y.glass
                }), q && (0, s.jsx)("mesh", {
                    geometry: m.back,
                    material: g.black
                }), X && (0, s.jsx)("mesh", {
                    geometry: m.card,
                    children: (0, s.jsx)("meshStandardMaterial", {
                        color: T ? "#ffffff" : "#e6dfcf",
                        map: T ? .map ? ? null,
                        normalMap: T ? .normal ? ? null,
                        normalScale: [.8, .8],
                        roughness: .7,
                        alphaTest: .5 * !!T
                    }, T ? "print" : "blank")
                })]
            })
        });
    e.s(["default", 0, V], 284442);
    var $ = e.i(931067),
        q = e.i(848546),
        X = r,
        Y = r,
        Z = r,
        Q = e.i(838194),
        K = a;
    let J = parseInt(a.REVISION.replace(/\D+/g, ""));
    class ee extends K.Mesh {
        constructor(e, t) {
            var r, a;
            const n = (e => e && e.isCubeTexture)(e),
                i = Math.floor(Math.log2((null != (a = n ? null == (r = e.image[0]) ? void 0 : r.width : e.image.width) ? a : 1024) / 4)),
                o = Math.pow(2, i),
                s = 3 * Math.max(o, 112),
                l = `
        varying vec3 vWorldPosition;
        void main() 
        {
            vec4 worldPosition = ( modelMatrix * vec4( position, 1.0 ) );
            vWorldPosition = worldPosition.xyz;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
        `,
                h = [n ? "#define ENVMAP_TYPE_CUBE" : "", `#define CUBEUV_TEXEL_WIDTH ${1/s}`, `#define CUBEUV_TEXEL_HEIGHT ${1/(4*o)}`, `#define CUBEUV_MAX_MIP ${i}.0`].join("\n") + `
        #define ENVMAP_TYPE_CUBE_UV
        varying vec3 vWorldPosition;
        uniform float radius;
        uniform float height;
        uniform float angle;
        #ifdef ENVMAP_TYPE_CUBE
            uniform samplerCube map;
        #else
            uniform sampler2D map;
        #endif
        // From: https://www.shadertoy.com/view/4tsBD7
        float diskIntersectWithBackFaceCulling( vec3 ro, vec3 rd, vec3 c, vec3 n, float r ) 
        {
            float d = dot ( rd, n );
            
            if( d > 0.0 ) { return 1e6; }
            
            vec3  o = ro - c;
            float t = - dot( n, o ) / d;
            vec3  q = o + rd * t;
            
            return ( dot( q, q ) < r * r ) ? t : 1e6;
        }
        // From: https://www.iquilezles.org/www/articles/intersectors/intersectors.htm
        float sphereIntersect( vec3 ro, vec3 rd, vec3 ce, float ra ) 
        {
            vec3 oc = ro - ce;
            float b = dot( oc, rd );
            float c = dot( oc, oc ) - ra * ra;
            float h = b * b - c;
            
            if( h < 0.0 ) { return -1.0; }
            
            h = sqrt( h );
            
            return - b + h;
        }
        vec3 project() 
        {
            vec3 p = normalize( vWorldPosition );
            vec3 camPos = cameraPosition;
            camPos.y -= height;
            float intersection = sphereIntersect( camPos, p, vec3( 0.0 ), radius );
            if( intersection > 0.0 ) {
                
                vec3 h = vec3( 0.0, - height, 0.0 );
                float intersection2 = diskIntersectWithBackFaceCulling( camPos, p, h, vec3( 0.0, 1.0, 0.0 ), radius );
                p = ( camPos + min( intersection, intersection2 ) * p ) / radius;
            } else {
                p = vec3( 0.0, 1.0, 0.0 );
            }
            return p;
        }
        #include <common>
        #include <cube_uv_reflection_fragment>
        void main() 
        {
            vec3 projectedWorldPosition = project();
            
            #ifdef ENVMAP_TYPE_CUBE
                vec3 outcolor = textureCube( map, projectedWorldPosition ).rgb;
            #else
                vec3 direction = normalize( projectedWorldPosition );
                vec2 uv = equirectUv( direction );
                vec3 outcolor = texture2D( map, uv ).rgb;
            #endif
            gl_FragColor = vec4( outcolor, 1.0 );
            #include <tonemapping_fragment>
            #include <${J>=154?"colorspace_fragment":"encodings_fragment"}>
        }
        `,
                u = {
                    map: {
                        value: e
                    },
                    height: {
                        value: (null == t ? void 0 : t.height) || 15
                    },
                    radius: {
                        value: (null == t ? void 0 : t.radius) || 100
                    }
                };
            super(new K.IcosahedronGeometry(1, 16), new K.ShaderMaterial({
                uniforms: u,
                fragmentShader: h,
                vertexShader: l,
                side: K.DoubleSide
            }))
        }
        set radius(e) {
            this.material.uniforms.radius.value = e
        }
        get radius() {
            return this.material.uniforms.radius.value
        }
        set height(e) {
            this.material.uniforms.height.value = e
        }
        get height() {
            return this.material.uniforms.height.value
        }
    }
    var r = r,
        et = a;
    class er extends et.DataTextureLoader {
        constructor(e) {
            super(e), this.type = et.HalfFloatType
        }
        parse(e) {
            let t, r, a, n = function(e, t) {
                    switch (e) {
                        case 1:
                            throw Error("THREE.RGBELoader: Read Error: " + (t || ""));
                        case 2:
                            throw Error("THREE.RGBELoader: Write Error: " + (t || ""));
                        case 3:
                            throw Error("THREE.RGBELoader: Bad File Format: " + (t || ""));
                        default:
                            throw Error("THREE.RGBELoader: Memory Error: " + (t || ""))
                    }
                },
                i = function(e, t, r) {
                    t = t || 1024;
                    let a = e.pos,
                        n = -1,
                        i = 0,
                        o = "",
                        s = String.fromCharCode.apply(null, new Uint16Array(e.subarray(a, a + 128)));
                    for (; 0 > (n = s.indexOf("\n")) && i < t && a < e.byteLength;) o += s, i += s.length, a += 128, s += String.fromCharCode.apply(null, new Uint16Array(e.subarray(a, a + 128)));
                    return -1 < n && (!1 !== r && (e.pos += i + n + 1), o + s.slice(0, n))
                },
                o = new Uint8Array(e);
            o.pos = 0;
            let s = function(e) {
                    let t, r, a = /^\s*GAMMA\s*=\s*(\d+(\.\d+)?)\s*$/,
                        o = /^\s*EXPOSURE\s*=\s*(\d+(\.\d+)?)\s*$/,
                        s = /^\s*FORMAT=(\S+)\s*$/,
                        l = /^\s*\-Y\s+(\d+)\s+\+X\s+(\d+)\s*$/,
                        h = {
                            valid: 0,
                            string: "",
                            comments: "",
                            programtype: "RGBE",
                            format: "",
                            gamma: 1,
                            exposure: 1,
                            width: 0,
                            height: 0
                        };
                    for (!(e.pos >= e.byteLength) && (t = i(e)) || n(1, "no header found"), (r = t.match(/^#\?(\S+)/)) || n(3, "bad initial token"), h.valid |= 1, h.programtype = r[1], h.string += t + "\n"; !1 !== (t = i(e));) {
                        if (h.string += t + "\n", "#" === t.charAt(0)) {
                            h.comments += t + "\n";
                            continue
                        }
                        if ((r = t.match(a)) && (h.gamma = parseFloat(r[1])), (r = t.match(o)) && (h.exposure = parseFloat(r[1])), (r = t.match(s)) && (h.valid |= 2, h.format = r[1]), (r = t.match(l)) && (h.valid |= 4, h.height = parseInt(r[1], 10), h.width = parseInt(r[2], 10)), 2 & h.valid && 4 & h.valid) break
                    }
                    return 2 & h.valid || n(3, "missing format specifier"), 4 & h.valid || n(3, "missing image size specifier"), h
                }(o),
                l = s.width,
                h = s.height,
                u = function(e, t, r) {
                    if (t < 8 || t > 32767 || 2 !== e[0] || 2 !== e[1] || 128 & e[2]) return new Uint8Array(e);
                    t !== (e[2] << 8 | e[3]) && n(3, "wrong scanline width");
                    let a = new Uint8Array(4 * t * r);
                    a.length || n(4, "unable to allocate buffer space");
                    let i = 0,
                        o = 0,
                        s = 4 * t,
                        l = new Uint8Array(4),
                        h = new Uint8Array(s),
                        u = r;
                    for (; u > 0 && o < e.byteLength;) {
                        o + 4 > e.byteLength && n(1), l[0] = e[o++], l[1] = e[o++], l[2] = e[o++], l[3] = e[o++], (2 != l[0] || 2 != l[1] || (l[2] << 8 | l[3]) != t) && n(3, "bad rgbe scanline format");
                        let r = 0,
                            f;
                        for (; r < s && o < e.byteLength;) {
                            let t = (f = e[o++]) > 128;
                            if (t && (f -= 128), (0 === f || r + f > s) && n(3, "bad scanline data"), t) {
                                let t = e[o++];
                                for (let e = 0; e < f; e++) h[r++] = t
                            } else h.set(e.subarray(o, o + f), r), r += f, o += f
                        }
                        for (let e = 0; e < t; e++) {
                            let r = 0;
                            a[i] = h[e + r], r += t, a[i + 1] = h[e + r], r += t, a[i + 2] = h[e + r], r += t, a[i + 3] = h[e + r], i += 4
                        }
                        u--
                    }
                    return a
                }(o.subarray(o.pos), l, h);
            switch (this.type) {
                case et.FloatType:
                    let f = new Float32Array(4 * (a = u.length / 4));
                    for (let e = 0; e < a; e++) ! function(e, t, r, a) {
                        let n = Math.pow(2, e[t + 3] - 128) / 255;
                        r[a + 0] = e[t + 0] * n, r[a + 1] = e[t + 1] * n, r[a + 2] = e[t + 2] * n, r[a + 3] = 1
                    }(u, 4 * e, f, 4 * e);
                    t = f, r = et.FloatType;
                    break;
                case et.HalfFloatType:
                    let c = new Uint16Array(4 * (a = u.length / 4));
                    for (let e = 0; e < a; e++) ! function(e, t, r, a) {
                        let n = Math.pow(2, e[t + 3] - 128) / 255;
                        r[a + 0] = et.DataUtils.toHalfFloat(Math.min(e[t + 0] * n, 65504)), r[a + 1] = et.DataUtils.toHalfFloat(Math.min(e[t + 1] * n, 65504)), r[a + 2] = et.DataUtils.toHalfFloat(Math.min(e[t + 2] * n, 65504)), r[a + 3] = et.DataUtils.toHalfFloat(1)
                    }(u, 4 * e, c, 4 * e);
                    t = c, r = et.HalfFloatType;
                    break;
                default:
                    throw Error("THREE.RGBELoader: Unsupported type: " + this.type)
            }
            return {
                width: l,
                height: h,
                data: t,
                header: s.string,
                gamma: s.gamma,
                exposure: s.exposure,
                type: r
            }
        }
        setDataType(e) {
            return this.type = e, this
        }
        load(e, t, r, a) {
            return super.load(e, function(e, r) {
                switch (e.type) {
                    case et.FloatType:
                    case et.HalfFloatType:
                        "colorSpace" in e ? e.colorSpace = "srgb-linear" : e.encoding = 3e3, e.minFilter = et.LinearFilter, e.magFilter = et.LinearFilter, e.generateMipmaps = !1, e.flipY = !0
                }
                t && t(e, r)
            }, r, a)
        }
    }
    var ea = a,
        en = {},
        ei = function(e, t, r, a, n) {
            var i = new Worker(en[t] || (en[t] = URL.createObjectURL(new Blob([e], {
                type: "text/javascript"
            }))));
            return i.onerror = function(e) {
                return n(e.error, null)
            }, i.onmessage = function(e) {
                return n(null, e.data)
            }, i.postMessage(r, a), i
        },
        eo = Uint8Array,
        es = Uint16Array,
        el = Uint32Array,
        eh = new eo([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
        eu = new eo([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
        ef = new eo([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
        ec = function(e, t) {
            for (var r = new es(31), a = 0; a < 31; ++a) r[a] = t += 1 << e[a - 1];
            for (var n = new el(r[30]), a = 1; a < 30; ++a)
                for (var i = r[a]; i < r[a + 1]; ++i) n[i] = i - r[a] << 5 | a;
            return [r, n]
        },
        ed = ec(eh, 2),
        ep = ed[0],
        em = ed[1];
    ep[28] = 258, em[258] = 28;
    for (var eg = ec(eu, 0), ev = eg[0], ey = eg[1], ew = new es(32768), eb = 0; eb < 32768; ++eb) {
        var ex = (43690 & eb) >>> 1 | (21845 & eb) << 1;
        ex = (61680 & (ex = (52428 & ex) >>> 2 | (13107 & ex) << 2)) >>> 4 | (3855 & ex) << 4, ew[eb] = ((65280 & ex) >>> 8 | (255 & ex) << 8) >>> 1
    }
    for (var eM = function(e, t, r) {
            for (var a, n = e.length, i = 0, o = new es(t); i < n; ++i) ++o[e[i] - 1];
            var s = new es(t);
            for (i = 0; i < t; ++i) s[i] = s[i - 1] + o[i - 1] << 1;
            if (r) {
                a = new es(1 << t);
                var l = 15 - t;
                for (i = 0; i < n; ++i)
                    if (e[i])
                        for (var h = i << 4 | e[i], u = t - e[i], f = s[e[i] - 1]++ << u, c = f | (1 << u) - 1; f <= c; ++f) a[ew[f] >>> l] = h
            } else
                for (a = new es(n), i = 0; i < n; ++i) e[i] && (a[i] = ew[s[e[i] - 1]++] >>> 15 - e[i]);
            return a
        }, eE = new eo(288), eb = 0; eb < 144; ++eb) eE[eb] = 8;
    for (var eb = 144; eb < 256; ++eb) eE[eb] = 9;
    for (var eb = 256; eb < 280; ++eb) eE[eb] = 7;
    for (var eb = 280; eb < 288; ++eb) eE[eb] = 8;
    for (var eT = new eo(32), eb = 0; eb < 32; ++eb) eT[eb] = 5;
    var eS = eM(eE, 9, 0),
        eA = eM(eE, 9, 1),
        eC = eM(eT, 5, 0),
        eP = eM(eT, 5, 1),
        eR = function(e) {
            for (var t = e[0], r = 1; r < e.length; ++r) e[r] > t && (t = e[r]);
            return t
        },
        e_ = function(e, t, r) {
            var a = t / 8 | 0;
            return (e[a] | e[a + 1] << 8) >> (7 & t) & r
        },
        eI = function(e, t) {
            var r = t / 8 | 0;
            return (e[r] | e[r + 1] << 8 | e[r + 2] << 16) >> (7 & t)
        },
        ek = function(e) {
            return (e / 8 | 0) + (7 & e && 1)
        },
        eF = function(e, t, r) {
            (null == t || t < 0) && (t = 0), (null == r || r > e.length) && (r = e.length);
            var a = new(e instanceof es ? es : e instanceof el ? el : eo)(r - t);
            return a.set(e.subarray(t, r)), a
        },
        eU = function(e, t, r) {
            var a = e.length;
            if (!a || r && !r.l && a < 5) return t || new eo(0);
            var n = !t || r,
                i = !r || r.i;
            r || (r = {}), t || (t = new eo(3 * a));
            var o = function(e) {
                    var r = t.length;
                    if (e > r) {
                        var a = new eo(Math.max(2 * r, e));
                        a.set(t), t = a
                    }
                },
                s = r.f || 0,
                l = r.p || 0,
                h = r.b || 0,
                u = r.l,
                f = r.d,
                c = r.m,
                d = r.n,
                p = 8 * a;
            do {
                if (!u) {
                    r.f = s = e_(e, l, 1);
                    var m = e_(e, l + 1, 3);
                    if (l += 3, m)
                        if (1 == m) u = eA, f = eP, c = 9, d = 5;
                        else if (2 == m) {
                        var g = e_(e, l, 31) + 257,
                            v = e_(e, l + 10, 15) + 4,
                            y = g + e_(e, l + 5, 31) + 1;
                        l += 14;
                        for (var w = new eo(y), b = new eo(19), x = 0; x < v; ++x) b[ef[x]] = e_(e, l + 3 * x, 7);
                        l += 3 * v;
                        for (var M = eR(b), E = (1 << M) - 1, T = eM(b, M, 1), x = 0; x < y;) {
                            var S = T[e_(e, l, E)];
                            l += 15 & S;
                            var A = S >>> 4;
                            if (A < 16) w[x++] = A;
                            else {
                                var C = 0,
                                    P = 0;
                                for (16 == A ? (P = 3 + e_(e, l, 3), l += 2, C = w[x - 1]) : 17 == A ? (P = 3 + e_(e, l, 7), l += 3) : 18 == A && (P = 11 + e_(e, l, 127), l += 7); P--;) w[x++] = C
                            }
                        }
                        var R = w.subarray(0, g),
                            _ = w.subarray(g);
                        c = eR(R), d = eR(_), u = eM(R, c, 1), f = eM(_, d, 1)
                    } else throw "invalid block type";
                    else {
                        var A = ek(l) + 4,
                            I = e[A - 4] | e[A - 3] << 8,
                            k = A + I;
                        if (k > a) {
                            if (i) throw "unexpected EOF";
                            break
                        }
                        n && o(h + I), t.set(e.subarray(A, k), h), r.b = h += I, r.p = l = 8 * k;
                        continue
                    }
                    if (l > p) {
                        if (i) throw "unexpected EOF";
                        break
                    }
                }
                n && o(h + 131072);
                for (var F = (1 << c) - 1, U = (1 << d) - 1, O = l;; O = l) {
                    var C = u[eI(e, l) & F],
                        B = C >>> 4;
                    if ((l += 15 & C) > p) {
                        if (i) throw "unexpected EOF";
                        break
                    }
                    if (!C) throw "invalid length/literal";
                    if (B < 256) t[h++] = B;
                    else if (256 == B) {
                        O = l, u = null;
                        break
                    } else {
                        var D = B - 254;
                        if (B > 264) {
                            var x = B - 257,
                                L = eh[x];
                            D = e_(e, l, (1 << L) - 1) + ep[x], l += L
                        }
                        var G = f[eI(e, l) & U],
                            z = G >>> 4;
                        if (!G) throw "invalid distance";
                        l += 15 & G;
                        var _ = ev[z];
                        if (z > 3) {
                            var L = eu[z];
                            _ += eI(e, l) & (1 << L) - 1, l += L
                        }
                        if (l > p) {
                            if (i) throw "unexpected EOF";
                            break
                        }
                        n && o(h + 131072);
                        for (var H = h + D; h < H; h += 4) t[h] = t[h - _], t[h + 1] = t[h + 1 - _], t[h + 2] = t[h + 2 - _], t[h + 3] = t[h + 3 - _];
                        h = H
                    }
                }
                r.l = u, r.p = O, r.b = h, u && (s = 1, r.m = c, r.d = f, r.n = d)
            } while (!s) return h == t.length ? t : eF(t, 0, h)
        },
        eO = function(e, t, r) {
            r <<= 7 & t;
            var a = t / 8 | 0;
            e[a] |= r, e[a + 1] |= r >>> 8
        },
        eB = function(e, t, r) {
            r <<= 7 & t;
            var a = t / 8 | 0;
            e[a] |= r, e[a + 1] |= r >>> 8, e[a + 2] |= r >>> 16
        },
        eD = function(e, t) {
            for (var r = [], a = 0; a < e.length; ++a) e[a] && r.push({
                s: a,
                f: e[a]
            });
            var n = r.length,
                i = r.slice();
            if (!n) return [eN, 0];
            if (1 == n) {
                var o = new eo(r[0].s + 1);
                return o[r[0].s] = 1, [o, 1]
            }
            r.sort(function(e, t) {
                return e.f - t.f
            }), r.push({
                s: -1,
                f: 25001
            });
            var s = r[0],
                l = r[1],
                h = 0,
                u = 1,
                f = 2;
            for (r[0] = {
                    s: -1,
                    f: s.f + l.f,
                    l: s,
                    r: l
                }; u != n - 1;) s = r[r[h].f < r[f].f ? h++ : f++], l = r[h != u && r[h].f < r[f].f ? h++ : f++], r[u++] = {
                s: -1,
                f: s.f + l.f,
                l: s,
                r: l
            };
            for (var c = i[0].s, a = 1; a < n; ++a) i[a].s > c && (c = i[a].s);
            var d = new es(c + 1),
                p = eL(r[u - 1], d, 0);
            if (p > t) {
                var a = 0,
                    m = 0,
                    g = p - t,
                    v = 1 << g;
                for (i.sort(function(e, t) {
                        return d[t.s] - d[e.s] || e.f - t.f
                    }); a < n; ++a) {
                    var y = i[a].s;
                    if (d[y] > t) m += v - (1 << p - d[y]), d[y] = t;
                    else break
                }
                for (m >>>= g; m > 0;) {
                    var w = i[a].s;
                    d[w] < t ? m -= 1 << t - d[w]++ - 1 : ++a
                }
                for (; a >= 0 && m; --a) {
                    var b = i[a].s;
                    d[b] == t && (--d[b], ++m)
                }
                p = t
            }
            return [new eo(d), p]
        },
        eL = function(e, t, r) {
            return -1 == e.s ? Math.max(eL(e.l, t, r + 1), eL(e.r, t, r + 1)) : t[e.s] = r
        },
        eG = function(e) {
            for (var t = e.length; t && !e[--t];);
            for (var r = new es(++t), a = 0, n = e[0], i = 1, o = function(e) {
                    r[a++] = e
                }, s = 1; s <= t; ++s)
                if (e[s] == n && s != t) ++i;
                else {
                    if (!n && i > 2) {
                        for (; i > 138; i -= 138) o(32754);
                        i > 2 && (o(i > 10 ? i - 11 << 5 | 28690 : i - 3 << 5 | 12305), i = 0)
                    } else if (i > 3) {
                        for (o(n), --i; i > 6; i -= 6) o(8304);
                        i > 2 && (o(i - 3 << 5 | 8208), i = 0)
                    }
                    for (; i--;) o(n);
                    i = 1, n = e[s]
                }
            return [r.subarray(0, a), t]
        },
        ez = function(e, t) {
            for (var r = 0, a = 0; a < t.length; ++a) r += e[a] * t[a];
            return r
        },
        eH = function(e, t, r) {
            var a = r.length,
                n = ek(t + 2);
            e[n] = 255 & a, e[n + 1] = a >>> 8, e[n + 2] = 255 ^ e[n], e[n + 3] = 255 ^ e[n + 1];
            for (var i = 0; i < a; ++i) e[n + i + 4] = r[i];
            return (n + 4 + a) * 8
        },
        ej = function(e, t, r, a, n, i, o, s, l, h, u) {
            eO(t, u++, r), ++n[256];
            for (var f, c, d, p, m = eD(n, 15), g = m[0], v = m[1], y = eD(i, 15), w = y[0], b = y[1], x = eG(g), M = x[0], E = x[1], T = eG(w), S = T[0], A = T[1], C = new es(19), P = 0; P < M.length; ++P) C[31 & M[P]]++;
            for (var P = 0; P < S.length; ++P) C[31 & S[P]]++;
            for (var R = eD(C, 7), _ = R[0], I = R[1], k = 19; k > 4 && !_[ef[k - 1]]; --k);
            var F = h + 5 << 3,
                U = ez(n, eE) + ez(i, eT) + o,
                O = ez(n, g) + ez(i, w) + o + 14 + 3 * k + ez(C, _) + (2 * C[16] + 3 * C[17] + 7 * C[18]);
            if (F <= U && F <= O) return eH(t, u, e.subarray(l, l + h));
            if (eO(t, u, 1 + (O < U)), u += 2, O < U) {
                f = eM(g, v, 0), c = g, d = eM(w, b, 0), p = w;
                var B = eM(_, I, 0);
                eO(t, u, E - 257), eO(t, u + 5, A - 1), eO(t, u + 10, k - 4), u += 14;
                for (var P = 0; P < k; ++P) eO(t, u + 3 * P, _[ef[P]]);
                u += 3 * k;
                for (var D = [M, S], L = 0; L < 2; ++L)
                    for (var G = D[L], P = 0; P < G.length; ++P) {
                        var z = 31 & G[P];
                        eO(t, u, B[z]), u += _[z], z > 15 && (eO(t, u, G[P] >>> 5 & 127), u += G[P] >>> 12)
                    }
            } else f = eS, c = eE, d = eC, p = eT;
            for (var P = 0; P < s; ++P)
                if (a[P] > 255) {
                    var z = a[P] >>> 18 & 31;
                    eB(t, u, f[z + 257]), u += c[z + 257], z > 7 && (eO(t, u, a[P] >>> 23 & 31), u += eh[z]);
                    var H = 31 & a[P];
                    eB(t, u, d[H]), u += p[H], H > 3 && (eB(t, u, a[P] >>> 5 & 8191), u += eu[H])
                } else eB(t, u, f[a[P]]), u += c[a[P]];
            return eB(t, u, f[256]), u + c[256]
        },
        eW = new el([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
        eN = new eo(0),
        eV = function(e, t, r, a, n, i) {
            var o = e.length,
                s = new eo(a + o + 5 * (1 + Math.ceil(o / 7e3)) + n),
                l = s.subarray(a, s.length - n),
                h = 0;
            if (!t || o < 8)
                for (var u = 0; u <= o; u += 65535) {
                    var f = u + 65535;
                    f < o ? h = eH(l, h, e.subarray(u, f)) : (l[u] = i, h = eH(l, h, e.subarray(u, o)))
                } else {
                    for (var c = eW[t - 1], d = c >>> 13, p = 8191 & c, m = (1 << r) - 1, g = new es(32768), v = new es(m + 1), y = Math.ceil(r / 3), w = 2 * y, b = function(t) {
                            return (e[t] ^ e[t + 1] << y ^ e[t + 2] << w) & m
                        }, x = new el(25e3), M = new es(288), E = new es(32), T = 0, S = 0, u = 0, A = 0, C = 0, P = 0; u < o; ++u) {
                        var R = b(u),
                            _ = 32767 & u,
                            I = v[R];
                        if (g[_] = I, v[R] = _, C <= u) {
                            var k = o - u;
                            if ((T > 7e3 || A > 24576) && k > 423) {
                                h = ej(e, l, 0, x, M, E, S, A, P, u - P, h), A = T = S = 0, P = u;
                                for (var F = 0; F < 286; ++F) M[F] = 0;
                                for (var F = 0; F < 30; ++F) E[F] = 0
                            }
                            var U = 2,
                                O = 0,
                                B = p,
                                D = _ - I & 32767;
                            if (k > 2 && R == b(u - D))
                                for (var L = Math.min(d, k) - 1, G = Math.min(32767, u), z = Math.min(258, k); D <= G && --B && _ != I;) {
                                    if (e[u + U] == e[u + U - D]) {
                                        for (var H = 0; H < z && e[u + H] == e[u + H - D]; ++H);
                                        if (H > U) {
                                            if (U = H, O = D, H > L) break;
                                            for (var j = Math.min(D, H - 2), W = 0, F = 0; F < j; ++F) {
                                                var N = u - D + F + 32768 & 32767,
                                                    V = g[N],
                                                    $ = N - V + 32768 & 32767;
                                                $ > W && (W = $, I = N)
                                            }
                                        }
                                    }
                                    I = g[_ = I], D += _ - I + 32768 & 32767
                                }
                            if (O) {
                                x[A++] = 0x10000000 | em[U] << 18 | ey[O];
                                var q = 31 & em[U],
                                    X = 31 & ey[O];
                                S += eh[q] + eu[X], ++M[257 + q], ++E[X], C = u + U, ++T
                            } else x[A++] = e[u], ++M[e[u]]
                        }
                    }
                    h = ej(e, l, i, x, M, E, S, A, P, u - P, h), !i && 7 & h && (h = eH(l, h + 1, eN))
                }
            return eF(s, 0, a + ek(h) + n)
        },
        e$ = function() {
            for (var e = new Int32Array(256), t = 0; t < 256; ++t) {
                for (var r = t, a = 9; --a;) r = (1 & r && -0x12477ce0) ^ r >>> 1;
                e[t] = r
            }
            return e
        }(),
        eq = function() {
            var e = -1;
            return {
                p: function(t) {
                    for (var r = e, a = 0; a < t.length; ++a) r = e$[255 & r ^ t[a]] ^ r >>> 8;
                    e = r
                },
                d: function() {
                    return ~e
                }
            }
        },
        eX = function() {
            var e = 1,
                t = 0;
            return {
                p: function(r) {
                    for (var a = e, n = t, i = r.length, o = 0; o != i;) {
                        for (var s = Math.min(o + 2655, i); o < s; ++o) n += a += r[o];
                        a = (65535 & a) + 15 * (a >> 16), n = (65535 & n) + 15 * (n >> 16)
                    }
                    e = a, t = n
                },
                d: function() {
                    return e %= 65521, t %= 65521, (255 & e) << 24 | e >>> 8 << 16 | (255 & t) << 8 | t >>> 8
                }
            }
        },
        eY = function(e, t, r, a, n) {
            return eV(e, null == t.level ? 6 : t.level, null == t.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(e.length)))) : 12 + t.mem, r, a, !n)
        },
        eZ = function(e, t) {
            var r = {};
            for (var a in e) r[a] = e[a];
            for (var a in t) r[a] = t[a];
            return r
        },
        eQ = function(e, t, r) {
            for (var a = e(), n = e.toString(), i = n.slice(n.indexOf("[") + 1, n.lastIndexOf("]")).replace(/ /g, "").split(","), o = 0; o < a.length; ++o) {
                var s = a[o],
                    l = i[o];
                if ("function" == typeof s) {
                    t += ";" + l + "=";
                    var h = s.toString();
                    if (s.prototype)
                        if (-1 != h.indexOf("[native code]")) {
                            var u = h.indexOf(" ", 8) + 1;
                            t += h.slice(u, h.indexOf("(", u))
                        } else
                            for (var f in t += h, s.prototype) t += ";" + l + ".prototype." + f + "=" + s.prototype[f].toString();
                    else t += h
                } else r[l] = s
            }
            return [t, r]
        },
        eK = [],
        eJ = function(e) {
            var t = [];
            for (var r in e)(e[r] instanceof eo || e[r] instanceof es || e[r] instanceof el) && t.push((e[r] = new e[r].constructor(e[r])).buffer);
            return t
        },
        e0 = function(e, t, r, a) {
            if (!eK[r]) {
                for (var n, i = "", o = {}, s = e.length - 1, l = 0; l < s; ++l) i = (n = eQ(e[l], i, o))[0], o = n[1];
                eK[r] = eQ(e[s], i, o)
            }
            var h = eZ({}, eK[r][1]);
            return ei(eK[r][0] + ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" + t.toString() + "}", r, h, eJ(h), a)
        },
        e1 = function() {
            return [eo, es, el, eh, eu, ef, ep, ev, eA, eP, ew, eM, eR, e_, eI, ek, eF, eU, tm, e4, e6]
        },
        e2 = function() {
            return [eo, es, el, eh, eu, ef, em, ey, eS, eE, eC, eT, ew, eW, eN, eM, eO, eB, eD, eL, eG, ez, eH, ej, ek, eF, eV, eY, tc, e4]
        },
        e5 = function() {
            return [tn, ti]
        },
        e3 = function() {
            return [tl]
        },
        e4 = function(e) {
            return postMessage(e, [e.buffer])
        },
        e6 = function(e) {
            return e && e.size && new eo(e.size)
        },
        e8 = function(e) {
            return e.ondata = function(e, t) {
                    return postMessage([e, t], [e.buffer])
                },
                function(t) {
                    return e.push(t.data[0], t.data[1])
                }
        },
        e7 = function(e, t, r, a, n) {
            var i, o = e0(e, a, n, function(e, r) {
                e ? (o.terminate(), t.ondata.call(t, e)) : (r[1] && o.terminate(), t.ondata.call(t, e, r[0], r[1]))
            });
            o.postMessage(r), t.push = function(e, r) {
                if (i) throw "stream finished";
                if (!t.ondata) throw "no stream handler";
                o.postMessage([e, i = r], [e.buffer])
            }, t.terminate = function() {
                o.terminate()
            }
        },
        e9 = function(e, t) {
            return e[t] | e[t + 1] << 8
        },
        te = function(e, t) {
            return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0
        },
        tt = function(e, t) {
            return te(e, t) + 0x100000000 * te(e, t + 4)
        },
        tr = function(e, t, r) {
            for (; r; ++t) e[t] = r, r >>>= 8
        },
        ta = function(e, t) {
            var r = t.filename;
            if (e[0] = 31, e[1] = 139, e[2] = 8, e[8] = t.level < 2 ? 4 : 2 * (9 == t.level), e[9] = 3, 0 != t.mtime && tr(e, 4, Math.floor(new Date(t.mtime || Date.now()) / 1e3)), r) {
                e[3] = 8;
                for (var a = 0; a <= r.length; ++a) e[a + 10] = r.charCodeAt(a)
            }
        },
        tn = function(e) {
            if (31 != e[0] || 139 != e[1] || 8 != e[2]) throw "invalid gzip data";
            var t = e[3],
                r = 10;
            4 & t && (r += e[10] | (e[11] << 8) + 2);
            for (var a = (t >> 3 & 1) + (t >> 4 & 1); a > 0; a -= !e[r++]);
            return r + (2 & t)
        },
        ti = function(e) {
            var t = e.length;
            return (e[t - 4] | e[t - 3] << 8 | e[t - 2] << 16 | e[t - 1] << 24) >>> 0
        },
        to = function(e) {
            return 10 + (e.filename && e.filename.length + 1 || 0)
        },
        ts = function(e, t) {
            var r = t.level,
                a = 0 == r ? 0 : r < 6 ? 1 : 9 == r ? 3 : 2;
            e[0] = 120, e[1] = a << 6 | (a ? 32 - 2 * a : 1)
        },
        tl = function(e) {
            if ((15 & e[0]) != 8 || e[0] >>> 4 > 7 || (e[0] << 8 | e[1]) % 31) throw "invalid zlib data";
            if (32 & e[1]) throw "invalid zlib data: preset dictionaries not supported"
        };

    function th(e, t) {
        return t || "function" != typeof e || (t = e, e = {}), this.ondata = t, e
    }
    var tu = function() {
            function e(e, t) {
                t || "function" != typeof e || (t = e, e = {}), this.ondata = t, this.o = e || {}
            }
            return e.prototype.p = function(e, t) {
                this.ondata(eY(e, this.o, 0, 0, !t), t)
            }, e.prototype.push = function(e, t) {
                if (this.d) throw "stream finished";
                if (!this.ondata) throw "no stream handler";
                this.d = t, this.p(e, t || !1)
            }, e
        }(),
        tf = function(e, t) {
            e7([e2, function() {
                return [e8, tu]
            }], this, th.call(this, e, t), function(e) {
                onmessage = e8(new tu(e.data))
            }, 6)
        };

    function tc(e, t) {
        return eY(e, t || {}, 0, 0)
    }
    var td = function() {
            function e(e) {
                this.s = {}, this.p = new eo(0), this.ondata = e
            }
            return e.prototype.e = function(e) {
                if (this.d) throw "stream finished";
                if (!this.ondata) throw "no stream handler";
                var t = this.p.length,
                    r = new eo(t + e.length);
                r.set(this.p), r.set(e, t), this.p = r
            }, e.prototype.c = function(e) {
                this.d = this.s.i = e || !1;
                var t = this.s.b,
                    r = eU(this.p, this.o, this.s);
                this.ondata(eF(r, t, this.s.b), this.d), this.o = eF(r, this.s.b - 32768), this.s.b = this.o.length, this.p = eF(this.p, this.s.p / 8 | 0), this.s.p &= 7
            }, e.prototype.push = function(e, t) {
                this.e(e), this.c(t)
            }, e
        }(),
        tp = function(e) {
            this.ondata = e, e7([e1, function() {
                return [e8, td]
            }], this, 0, function() {
                onmessage = e8(new td)
            }, 7)
        };

    function tm(e, t) {
        return eU(e, t)
    }(function() {
        function e(e, t) {
            this.c = eq(), this.l = 0, this.v = 1, tu.call(this, e, t)
        }
        e.prototype.push = function(e, t) {
            tu.prototype.push.call(this, e, t)
        }, e.prototype.p = function(e, t) {
            this.c.p(e), this.l += e.length;
            var r = eY(e, this.o, this.v && to(this.o), t && 8, !t);
            this.v && (ta(r, this.o), this.v = 0), t && (tr(r, r.length - 8, this.c.d()), tr(r, r.length - 4, this.l)), this.ondata(r, t)
        }
    })();
    var tg = function() {
            function e(e) {
                this.v = 1, td.call(this, e)
            }
            return e.prototype.push = function(e, t) {
                if (td.prototype.e.call(this, e), this.v) {
                    var r = this.p.length > 3 ? tn(this.p) : 4;
                    if (r >= this.p.length && !t) return;
                    this.p = this.p.subarray(r), this.v = 0
                }
                if (t) {
                    if (this.p.length < 8) throw "invalid gzip stream";
                    this.p = this.p.subarray(0, -8)
                }
                td.prototype.c.call(this, t)
            }, e
        }(),
        tv = function(e) {
            this.ondata = e, e7([e1, e5, function() {
                return [e8, td, tg]
            }], this, 0, function() {
                onmessage = e8(new tg)
            }, 9)
        },
        ty = (function() {
            function e(e, t) {
                this.c = eX(), this.v = 1, tu.call(this, e, t)
            }
            e.prototype.push = function(e, t) {
                tu.prototype.push.call(this, e, t)
            }, e.prototype.p = function(e, t) {
                this.c.p(e);
                var r = eY(e, this.o, this.v && 2, t && 4, !t);
                this.v && (ts(r, this.o), this.v = 0), t && tr(r, r.length - 4, this.c.d()), this.ondata(r, t)
            }
        }(), function() {
            function e(e) {
                this.v = 1, td.call(this, e)
            }
            return e.prototype.push = function(e, t) {
                if (td.prototype.e.call(this, e), this.v) {
                    if (this.p.length < 2 && !t) return;
                    this.p = this.p.subarray(2), this.v = 0
                }
                if (t) {
                    if (this.p.length < 4) throw "invalid zlib stream";
                    this.p = this.p.subarray(0, -4)
                }
                td.prototype.c.call(this, t)
            }, e
        }()),
        tw = function(e) {
            this.ondata = e, e7([e1, e3, function() {
                return [e8, td, ty]
            }], this, 0, function() {
                onmessage = e8(new ty)
            }, 11)
        };

    function tb(e, t) {
        return eU((tl(e), e.subarray(2, -4)), t)
    }
    var tx = function() {
        function e(e) {
            this.G = tg, this.I = td, this.Z = ty, this.ondata = e
        }
        return e.prototype.push = function(e, t) {
            if (!this.ondata) throw "no stream handler";
            if (this.s) this.s.push(e, t);
            else {
                if (this.p && this.p.length) {
                    var r = new eo(this.p.length + e.length);
                    r.set(this.p), r.set(e, this.p.length)
                } else this.p = e;
                if (this.p.length > 2) {
                    var a = this,
                        n = function() {
                            a.ondata.apply(a, arguments)
                        };
                    this.s = 31 == this.p[0] && 139 == this.p[1] && 8 == this.p[2] ? new this.G(n) : (15 & this.p[0]) != 8 || this.p[0] >> 4 > 7 || (this.p[0] << 8 | this.p[1]) % 31 ? new this.I(n) : new this.Z(n), this.s.push(this.p, t), this.p = null
                }
            }
        }, e
    }();
    (function(e) {
        this.G = tv, this.I = tp, this.Z = tw, this.ondata = e
    }).prototype.push = function(e, t) {
        tx.prototype.push.call(this, e, t)
    };
    var tM = "u" > typeof TextEncoder && new TextEncoder,
        tE = "u" > typeof TextDecoder && new TextDecoder,
        tT = 0;
    try {
        tE.decode(eN, {
            stream: !0
        }), tT = 1
    } catch (e) {}
    var tS = function(e) {
        for (var t = "", r = 0;;) {
            var a = e[r++],
                n = (a > 127) + (a > 223) + (a > 239);
            if (r + n > e.length) return [t, eF(e, r - 1)];
            n ? 3 == n ? t += String.fromCharCode(55296 | (a = ((15 & a) << 18 | (63 & e[r++]) << 12 | (63 & e[r++]) << 6 | 63 & e[r++]) - 65536) >> 10, 56320 | 1023 & a) : 1 & n ? t += String.fromCharCode((31 & a) << 6 | 63 & e[r++]) : t += String.fromCharCode((15 & a) << 12 | (63 & e[r++]) << 6 | 63 & e[r++]) : t += String.fromCharCode(a)
        }
    };

    function tA(e, t) {
        if (t) {
            for (var r = new eo(e.length), a = 0; a < e.length; ++a) r[a] = e.charCodeAt(a);
            return r
        }
        if (tM) return tM.encode(e);
        for (var n = e.length, i = new eo(e.length + (e.length >> 1)), o = 0, s = function(e) {
                i[o++] = e
            }, a = 0; a < n; ++a) {
            if (o + 5 > i.length) {
                var l = new eo(o + 8 + (n - a << 1));
                l.set(i), i = l
            }
            var h = e.charCodeAt(a);
            h < 128 || t ? s(h) : (h < 2048 ? s(192 | h >> 6) : (h > 55295 && h < 57344 ? (s(240 | (h = 65536 + (1047552 & h) | 1023 & e.charCodeAt(++a)) >> 18), s(128 | h >> 12 & 63)) : s(224 | h >> 12), s(128 | h >> 6 & 63)), s(128 | 63 & h))
        }
        return eF(i, 0, o)
    }(function(e) {
        this.ondata = e, tT ? this.t = new TextDecoder : this.p = eN
    }).prototype.push = function(e, t) {
        if (!this.ondata) throw "no callback";
        if (t = !!t, this.t) {
            if (this.ondata(this.t.decode(e, {
                    stream: !0
                }), t), t) {
                if (this.t.decode().length) throw "invalid utf-8 data";
                this.t = null
            }
            return
        }
        if (!this.p) throw "stream finished";
        var r = new eo(this.p.length + e.length);
        r.set(this.p), r.set(e, this.p.length);
        var a = tS(r),
            n = a[0],
            i = a[1];
        if (t) {
            if (i.length) throw "invalid utf-8 data";
            this.p = null
        } else this.p = i;
        this.ondata(n, t)
    }, (function(e) {
        this.ondata = e
    }).prototype.push = function(e, t) {
        if (!this.ondata) throw "no callback";
        if (this.d) throw "stream finished";
        this.ondata(tA(e), this.d = t || !1)
    };
    var tC = function(e) {
            return 1 == e ? 3 : e < 6 ? 2 : +(9 == e)
        },
        tP = function(e, t, r) {
            for (var a = t + r; 1 != e9(e, t); t += 4 + e9(e, t + 2))
                if (t + 4 > a) throw "invalid zip file";
            return [tt(e, t + 12), tt(e, t + 4), tt(e, t + 20)]
        },
        tR = function(e) {
            var t = 0;
            if (e)
                for (var r in e) {
                    var a = e[r].length;
                    if (a > 65535) throw "extra field too long";
                    t += a + 4
                }
            return t
        },
        t_ = function(e, t, r, a, n, i, o, s) {
            var l = a.length,
                h = r.extra,
                u = s && s.length,
                f = tR(h);
            tr(e, t, null != o ? 0x2014b50 : 0x4034b50), t += 4, null != o && (e[t++] = 20, e[t++] = r.os), e[t] = 20, t += 2, e[t++] = r.flag << 1 | (null == i && 8), e[t++] = n && 8, e[t++] = 255 & r.compression, e[t++] = r.compression >> 8;
            var c = new Date(null == r.mtime ? Date.now() : r.mtime),
                d = c.getFullYear() - 1980;
            if (d < 0 || d > 119) throw "date not in range 1980-2099";
            if (tr(e, t, d << 25 | c.getMonth() + 1 << 21 | c.getDate() << 16 | c.getHours() << 11 | c.getMinutes() << 5 | c.getSeconds() >>> 1), t += 4, null != i && (tr(e, t, r.crc), tr(e, t + 4, i), tr(e, t + 8, r.size)), tr(e, t + 12, l), tr(e, t + 14, f), t += 16, null != o && (tr(e, t, u), tr(e, t + 6, r.attrs), tr(e, t + 10, o), t += 14), e.set(a, t), t += l, f)
                for (var p in h) {
                    var m = h[p],
                        g = m.length;
                    tr(e, t, +p), tr(e, t + 2, g), e.set(m, t + 4), t += 4 + g
                }
            return u && (e.set(s, t), t += u), t
        },
        tI = function(e, t, r, a, n) {
            tr(e, t, 0x6054b50), tr(e, t + 8, r), tr(e, t + 10, r), tr(e, t + 12, a), tr(e, t + 16, n)
        },
        tk = function() {
            function e(e) {
                this.filename = e, this.c = eq(), this.size = 0, this.compression = 0
            }
            return e.prototype.process = function(e, t) {
                this.ondata(null, e, t)
            }, e.prototype.push = function(e, t) {
                if (!this.ondata) throw "no callback - add to ZIP archive before pushing";
                this.c.p(e), this.size += e.length, t && (this.crc = this.c.d()), this.process(e, t || !1)
            }, e
        }();

    function tF(e, t) {
        var r = this;
        t || (t = {}), tk.call(this, e), this.d = new tu(t, function(e, t) {
            r.ondata(null, e, t)
        }), this.compression = 8, this.flag = tC(t.level)
    }

    function tU(e, t) {
        var r = this;
        t || (t = {}), tk.call(this, e), this.d = new tf(t, function(e, t, a) {
            r.ondata(e, t, a)
        }), this.compression = 8, this.flag = tC(t.level), this.terminate = this.d.terminate
    }

    function tO(e) {
        this.ondata = e, this.u = [], this.d = 1
    }
    tF.prototype.process = function(e, t) {
        try {
            this.d.push(e, t)
        } catch (e) {
            this.ondata(e, null, t)
        }
    }, tF.prototype.push = function(e, t) {
        tk.prototype.push.call(this, e, t)
    }, tU.prototype.process = function(e, t) {
        this.d.push(e, t)
    }, tU.prototype.push = function(e, t) {
        tk.prototype.push.call(this, e, t)
    }, tO.prototype.add = function(e) {
        var t = this;
        if (2 & this.d) throw "stream finished";
        var r = tA(e.filename),
            a = r.length,
            n = e.comment,
            i = n && tA(n),
            o = a != e.filename.length || i && n.length != i.length,
            s = a + tR(e.extra) + 30;
        if (a > 65535) throw "filename too long";
        var l = new eo(s);
        t_(l, 0, e, r, o);
        var h = [l],
            u = function() {
                for (var e = 0, r = h; e < r.length; e++) {
                    var a = r[e];
                    t.ondata(null, a, !1)
                }
                h = []
            },
            f = this.d;
        this.d = 0;
        var c = this.u.length,
            d = eZ(e, {
                f: r,
                u: o,
                o: i,
                t: function() {
                    e.terminate && e.terminate()
                },
                r: function() {
                    if (u(), f) {
                        var e = t.u[c + 1];
                        e ? e.r() : t.d = 1
                    }
                    f = 1
                }
            }),
            p = 0;
        e.ondata = function(r, a, n) {
            if (r) t.ondata(r, a, n), t.terminate();
            else if (p += a.length, h.push(a), n) {
                var i = new eo(16);
                tr(i, 0, 0x8074b50), tr(i, 4, e.crc), tr(i, 8, p), tr(i, 12, e.size), h.push(i), d.c = p, d.b = s + p + 16, d.crc = e.crc, d.size = e.size, f && d.r(), f = 1
            } else f && u()
        }, this.u.push(d)
    }, tO.prototype.end = function() {
        var e = this;
        if (2 & this.d) {
            if (1 & this.d) throw "stream finishing";
            throw "stream finished"
        }
        this.d ? this.e() : this.u.push({
            r: function() {
                1 & e.d && (e.u.splice(-1, 1), e.e())
            },
            t: function() {}
        }), this.d = 3
    }, tO.prototype.e = function() {
        for (var e = 0, t = 0, r = 0, a = 0, n = this.u; a < n.length; a++) {
            var i = n[a];
            r += 46 + i.f.length + tR(i.extra) + (i.o ? i.o.length : 0)
        }
        for (var o = new eo(r + 22), s = 0, l = this.u; s < l.length; s++) {
            var i = l[s];
            t_(o, e, i, i.f, i.u, i.c, t, i.o), e += 46 + i.f.length + tR(i.extra) + (i.o ? i.o.length : 0), t += i.b
        }
        tI(o, e, this.u.length, r, t), this.ondata(null, o, !0), this.d = 2
    }, tO.prototype.terminate = function() {
        for (var e = 0, t = this.u; e < t.length; e++) t[e].t();
        this.d = 2
    };
    var tB = function() {
        function e() {}
        return e.prototype.push = function(e, t) {
            this.ondata(null, e, t)
        }, e.compression = 0, e
    }();

    function tD() {
        var e = this;
        this.i = new td(function(t, r) {
            e.ondata(null, t, r)
        })
    }

    function tL(e, t) {
        var r = this;
        t < 32e4 ? this.i = new td(function(e, t) {
            r.ondata(null, e, t)
        }) : (this.i = new tp(function(e, t, a) {
            r.ondata(e, t, a)
        }), this.terminate = this.i.terminate)
    }

    function tG(e) {
        this.onfile = e, this.k = [], this.o = {
            0: tB
        }, this.p = eN
    }
    tD.prototype.push = function(e, t) {
        try {
            this.i.push(e, t)
        } catch (r) {
            this.ondata(r, e, t)
        }
    }, tD.compression = 8, tL.prototype.push = function(e, t) {
        this.i.terminate && (e = eF(e, 0)), this.i.push(e, t)
    }, tL.compression = 8, tG.prototype.push = function(e, t) {
        var r = this;
        if (!this.onfile) throw "no callback";
        if (!this.p) throw "stream finished";
        if (this.c > 0) {
            var a = Math.min(this.c, e.length),
                n = e.subarray(0, a);
            if (this.c -= a, this.d ? this.d.push(n, !this.c) : this.k[0].push(n), (e = e.subarray(a)).length) return this.push(e, t)
        } else {
            var i = 0,
                o = 0,
                s = void 0,
                l = void 0;
            this.p.length ? e.length ? ((l = new eo(this.p.length + e.length)).set(this.p), l.set(e, this.p.length)) : l = this.p : l = e;
            for (var h = l.length, u = this.c, f = u && this.d, c = this; o < h - 4 && "break" !== function() {
                    var e = te(l, o);
                    if (0x4034b50 == e) {
                        i = 1, s = o, c.d = null, c.c = 0;
                        var t = e9(l, o + 6),
                            a = e9(l, o + 8),
                            n = 8 & t,
                            f = e9(l, o + 26),
                            d = e9(l, o + 28);
                        if (h > o + 30 + f + d) {
                            var p, m, g = [];
                            c.k.unshift(g), i = 2;
                            var v = te(l, o + 18),
                                y = te(l, o + 22),
                                w = function(e, t) {
                                    if (t) {
                                        for (var r = "", a = 0; a < e.length; a += 16384) r += String.fromCharCode.apply(null, e.subarray(a, a + 16384));
                                        return r
                                    }
                                    if (tE) return tE.decode(e);
                                    var n = tS(e),
                                        i = n[0];
                                    if (n[1].length) throw "invalid utf-8 data";
                                    return i
                                }(l.subarray(o + 30, o += 30 + f), !(2048 & t));
                            0xffffffff == v ? (v = (p = n ? [-2] : tP(l, o, d))[0], y = p[1]) : n && (v = -1), o += d, c.c = v;
                            var b = {
                                name: w,
                                compression: a,
                                start: function() {
                                    if (!b.ondata) throw "no callback";
                                    if (v) {
                                        var e = r.o[a];
                                        if (!e) throw "unknown compression type " + a;
                                        (m = v < 0 ? new e(w) : new e(w, v, y)).ondata = function(e, t, r) {
                                            b.ondata(e, t, r)
                                        };
                                        for (var t = 0; t < g.length; t++) {
                                            var n = g[t];
                                            m.push(n, !1)
                                        }
                                        r.k[0] == g && r.c ? r.d = m : m.push(eN, !0)
                                    } else b.ondata(null, eN, !0)
                                },
                                terminate: function() {
                                    m && m.terminate && m.terminate()
                                }
                            };
                            v >= 0 && (b.size = v, b.originalSize = y), c.onfile(b)
                        }
                        return "break"
                    }
                    if (u) {
                        if (0x8074b50 == e) return s = o += 12 + (-2 == u && 8), i = 3, c.c = 0, "break";
                        else if (0x2014b50 == e) return s = o -= 4, i = 3, c.c = 0, "break"
                    }
                }(); ++o);
            if (this.p = eN, u < 0) {
                var d = i ? l.subarray(0, s - 12 - (-2 == u && 8) - (0x8074b50 == te(l, s - 16) && 4)) : l.subarray(0, o);
                f ? f.push(d, !!i) : this.k[+(2 == i)].push(d)
            }
            if (2 & i) return this.push(l.subarray(o), t);
            this.p = l.subarray(o)
        }
        if (t) {
            if (this.c) throw "invalid zip file";
            this.p = null
        }
    }, tG.prototype.register = function(e) {
        this.o[e.compression] = e
    };
    let tz = J >= 152;
    class tH extends ea.DataTextureLoader {
        constructor(e) {
            super(e), this.type = ea.HalfFloatType
        }
        parse(e) {
            let t = {
                l: 0,
                c: 0,
                lc: 0
            };

            function r(e, r, a, n, i) {
                for (; a < e;) r = r << 8 | S(n, i), a += 8;
                t.l = r >> (a -= e) & (1 << e) - 1, t.c = r, t.lc = a
            }
            let a = Array(59),
                n = {
                    c: 0,
                    lc: 0
                };

            function i(e, t, r, a) {
                e = e << 8 | S(r, a), t += 8, n.c = e, n.lc = t
            }
            let o = {
                c: 0,
                lc: 0
            };

            function s(e, t, r, a, s, l, h, u, f, c) {
                if (e == t) {
                    a < 8 && (i(r, a, s, h), r = n.c, a = n.lc);
                    var d = r >> (a -= 8),
                        d = new Uint8Array([d])[0];
                    if (f.value + d > c) return !1;
                    for (var p = u[f.value - 1]; d-- > 0;) u[f.value++] = p
                } else {
                    if (!(f.value < c)) return !1;
                    u[f.value++] = e
                }
                o.c = r, o.lc = a
            }

            function l(e) {
                var t = 65535 & e;
                return t > 32767 ? t - 65536 : t
            }
            let h = {
                a: 0,
                b: 0
            };

            function u(e, t) {
                var r = l(e),
                    a = l(t),
                    n = r + (1 & a) + (a >> 1),
                    i = n - a;
                h.a = n, h.b = i
            }

            function f(e, t) {
                var r = 65535 & t,
                    a = (65535 & e) - (r >> 1) & 65535;
                h.a = r + a - 32768 & 65535, h.b = a
            }

            function c(e, l, h, u, f, c) {
                var d = h.value,
                    p = T(l, h),
                    m = T(l, h);
                h.value += 4;
                var g = T(l, h);
                if (h.value += 4, p < 0 || p >= 65537 || m < 0 || m >= 65537) throw "Something wrong with HUF_ENCSIZE";
                for (var v = Array(65537), y = Array(16384), w = 0; w < 16384; w++) y[w] = {}, y[w].len = 0, y[w].lit = 0, y[w].p = null;
                var b = u - (h.value - d);
                if (! function(e, n, i, o, s, l) {
                        for (var h = 0, u = 0; o <= s; o++) {
                            if (n.value - n.value > i) return !1;
                            r(6, h, u, e, n);
                            var f = t.l;
                            if (h = t.c, u = t.lc, l[o] = f, 63 == f) {
                                if (n.value - n.value > i) throw "Something wrong with hufUnpackEncTable";
                                r(8, h, u, e, n);
                                var c = t.l + 6;
                                if (h = t.c, u = t.lc, o + c > s + 1) throw "Something wrong with hufUnpackEncTable";
                                for (; c--;) l[o++] = 0;
                                o--
                            } else if (f >= 59) {
                                var c = f - 59 + 2;
                                if (o + c > s + 1) throw "Something wrong with hufUnpackEncTable";
                                for (; c--;) l[o++] = 0;
                                o--
                            }
                        }! function(e) {
                            for (var t = 0; t <= 58; ++t) a[t] = 0;
                            for (var t = 0; t < 65537; ++t) a[e[t]] += 1;
                            for (var r = 0, t = 58; t > 0; --t) {
                                var n = r + a[t] >> 1;
                                a[t] = r, r = n
                            }
                            for (var t = 0; t < 65537; ++t) {
                                var i = e[t];
                                i > 0 && (e[t] = i | a[i]++ << 6)
                            }
                        }(l)
                    }(e, h, b, p, m, v), g > 8 * (u - (h.value - d))) throw "Something wrong with hufUncompress";
                ! function(e, t, r, a) {
                    for (; t <= r; t++) {
                        var n = e[t] >> 6,
                            i = 63 & e[t];
                        if (n >> i) throw "Invalid table entry";
                        if (i > 14) {
                            var o = a[n >> i - 14];
                            if (o.len) throw "Invalid table entry";
                            if (o.lit++, o.p) {
                                var s = o.p;
                                o.p = Array(o.lit);
                                for (var l = 0; l < o.lit - 1; ++l) o.p[l] = s[l]
                            } else o.p = [, ];
                            o.p[o.lit - 1] = t
                        } else if (i)
                            for (var h = 0, l = 1 << 14 - i; l > 0; l--) {
                                var o = a[(n << 14 - i) + h];
                                if (o.len || o.p) throw "Invalid table entry";
                                o.len = i, o.lit = t, h++
                            }
                    }
                }(v, p, m, y),
                function(e, t, r, a, l, h, u, f, c, d) {
                    for (var p = 0, m = 0, g = Math.trunc(l.value + (h + 7) / 8); l.value < g;)
                        for (i(p, m, r, l), p = n.c, m = n.lc; m >= 14;) {
                            var v = t[p >> m - 14 & 16383];
                            if (v.len) m -= v.len, s(v.lit, u, p, m, r, a, l, c, d, f), p = o.c, m = o.lc;
                            else {
                                if (!v.p) throw "hufDecode issues";
                                for (y = 0; y < v.lit; y++) {
                                    for (var y, w = 63 & e[v.p[y]]; m < w && l.value < g;) i(p, m, r, l), p = n.c, m = n.lc;
                                    if (m >= w && e[v.p[y]] >> 6 == (p >> m - w & (1 << w) - 1)) {
                                        m -= w, s(v.p[y], u, p, m, r, a, l, c, d, f), p = o.c, m = o.lc;
                                        break
                                    }
                                }
                                if (y == v.lit) throw "hufDecode issues"
                            }
                        }
                    var b = 8 - h & 7;
                    for (p >>= b, m -= b; m > 0;) {
                        var v = t[p << 14 - m & 16383];
                        if (v.len) m -= v.len, s(v.lit, u, p, m, r, a, l, c, d, f), p = o.c, m = o.lc;
                        else throw "hufDecode issues"
                    }
                }(v, y, e, l, h, g, m, c, f, {
                    value: 0
                })
            }

            function d(e) {
                for (var t = 1; t < e.length; t++) {
                    var r = e[t - 1] + e[t] - 128;
                    e[t] = r
                }
            }

            function p(e, t) {
                for (var r = 0, a = Math.floor((e.length + 1) / 2), n = 0, i = e.length - 1; !(n > i) && (t[n++] = e[r++], !(n > i));) {;
                    t[n++] = e[a++]
                }
            }

            function m(e) {
                for (var t = e.byteLength, r = [], a = 0, n = new DataView(e); t > 0;) {
                    var i = n.getInt8(a++);
                    if (i < 0) {
                        var o = -i;
                        t -= o + 1;
                        for (var s = 0; s < o; s++) r.push(n.getUint8(a++))
                    } else {
                        var o = i;
                        t -= 2;
                        for (var l = n.getUint8(a++), s = 0; s < o + 1; s++) r.push(l)
                    }
                }
                return r
            }

            function g(e) {
                return new DataView(e.array.buffer, e.offset.value, e.size)
            }

            function v(e) {
                var t = new Uint8Array(m(e.viewer.buffer.slice(e.offset.value, e.offset.value + e.size))),
                    r = new Uint8Array(t.length);
                return d(t), p(t, r), new DataView(r.buffer)
            }

            function y(e) {
                var t = tb(e.array.slice(e.offset.value, e.offset.value + e.size)),
                    r = new Uint8Array(t.length);
                return d(t), p(t, r), new DataView(r.buffer)
            }

            function w(e) {
                for (var t = e.viewer, r = {
                        value: e.offset.value
                    }, a = new Uint16Array(e.width * e.scanlineBlockSize * (e.channels * e.type)), n = new Uint8Array(8192), i = 0, o = Array(e.channels), s = 0; s < e.channels; s++) o[s] = {}, o[s].start = i, o[s].end = o[s].start, o[s].nx = e.width, o[s].ny = e.lines, o[s].size = e.type, i += o[s].nx * o[s].ny * o[s].size;
                var l = I(t, r),
                    d = I(t, r);
                if (d >= 8192) throw "Something is wrong with PIZ_COMPRESSION BITMAP_SIZE";
                if (l <= d)
                    for (var s = 0; s < d - l + 1; s++) n[s + l] = A(t, r);
                var p = new Uint16Array(65536),
                    m = function(e, t) {
                        for (var r = 0, a = 0; a < 65536; ++a)(0 == a || e[a >> 3] & 1 << (7 & a)) && (t[r++] = a);
                        for (var n = r - 1; r < 65536;) t[r++] = 0;
                        return n
                    }(n, p),
                    g = T(t, r);
                c(e.array, t, r, g, a, i);
                for (var s = 0; s < e.channels; ++s)
                    for (var v = o[s], y = 0; y < o[s].size; ++y) ! function(e, t, r, a, n, i, o) {
                        for (var s = o < 16384, l = r > n ? n : r, c = 1; c <= l;) c <<= 1;
                        for (c >>= 1, d = c, c >>= 1; c >= 1;) {
                            for (var d, p, m, g, v, y = 0, w = 0 + i * (n - d), b = i * c, x = i * d, M = a * c, E = a * d; y <= w; y += x) {
                                for (var T = y, S = y + a * (r - d); T <= S; T += E) {
                                    var A = T + M,
                                        C = T + b,
                                        P = C + M;
                                    s ? (u(e[T + t], e[C + t]), p = h.a, g = h.b, u(e[A + t], e[P + t]), m = h.a, v = h.b, u(p, m), e[T + t] = h.a, e[A + t] = h.b, u(g, v)) : (f(e[T + t], e[C + t]), p = h.a, g = h.b, f(e[A + t], e[P + t]), m = h.a, v = h.b, f(p, m), e[T + t] = h.a, e[A + t] = h.b, f(g, v)), e[C + t] = h.a, e[P + t] = h.b
                                }
                                if (r & c) {
                                    var C = T + b;
                                    s ? u(e[T + t], e[C + t]) : f(e[T + t], e[C + t]), p = h.a, e[C + t] = h.b, e[T + t] = p
                                }
                            }
                            if (n & c)
                                for (var T = y, S = y + a * (r - d); T <= S; T += E) {
                                    var A = T + M;
                                    s ? u(e[T + t], e[A + t]) : f(e[T + t], e[A + t]), p = h.a, e[A + t] = h.b, e[T + t] = p
                                }
                            d = c, c >>= 1
                        }
                    }(a, v.start + y, v.nx, v.size, v.ny, v.nx * v.size, m);
                for (var w = i, b = 0; b < w; ++b) a[b] = p[a[b]];
                for (var x = 0, M = new Uint8Array(a.buffer.byteLength), E = 0; E < e.lines; E++)
                    for (var S = 0; S < e.channels; S++) {
                        var v = o[S],
                            C = v.nx * v.size,
                            P = new Uint8Array(a.buffer, 2 * v.end, 2 * C);
                        M.set(P, x), x += 2 * C, v.end += C
                    }
                return new DataView(M.buffer)
            }

            function b(e) {
                var t = tb(e.array.slice(e.offset.value, e.offset.value + e.size));
                let r = e.lines * e.channels * e.width,
                    a = 1 == e.type ? new Uint16Array(r) : new Uint32Array(r),
                    n = 0,
                    i = 0,
                    o = [, , , , ];
                for (let r = 0; r < e.lines; r++)
                    for (let r = 0; r < e.channels; r++) {
                        let r = 0;
                        switch (e.type) {
                            case 1:
                                o[0] = n, o[1] = o[0] + e.width, n = o[1] + e.width;
                                for (let n = 0; n < e.width; ++n) r += t[o[0]++] << 8 | t[o[1]++], a[i] = r, i++;
                                break;
                            case 2:
                                o[0] = n, o[1] = o[0] + e.width, o[2] = o[1] + e.width, n = o[2] + e.width;
                                for (let n = 0; n < e.width; ++n) r += t[o[0]++] << 24 | t[o[1]++] << 16 | t[o[2]++] << 8, a[i] = r, i++
                        }
                    }
                return new DataView(a.buffer)
            }

            function x(e) {
                var t = e.viewer,
                    r = {
                        value: e.offset.value
                    },
                    a = new Uint8Array(e.width * e.lines * (e.channels * e.type * 2)),
                    n = {
                        version: C(t, r),
                        unknownUncompressedSize: C(t, r),
                        unknownCompressedSize: C(t, r),
                        acCompressedSize: C(t, r),
                        dcCompressedSize: C(t, r),
                        rleCompressedSize: C(t, r),
                        rleUncompressedSize: C(t, r),
                        rleRawSize: C(t, r),
                        totalAcUncompressedCount: C(t, r),
                        totalDcUncompressedCount: C(t, r),
                        acCompression: C(t, r)
                    };
                if (n.version < 2) throw "EXRLoader.parse: " + B.compression + " version " + n.version + " is unsupported";
                for (var i = [], o = I(t, r) - 2; o > 0;) {
                    var s = M(t.buffer, r),
                        l = A(t, r),
                        h = l >> 2 & 3,
                        u = new Int8Array([(l >> 4) - 1])[0],
                        f = A(t, r);
                    i.push({
                        name: s,
                        index: u,
                        type: f,
                        compression: h
                    }), o -= s.length + 3
                }
                for (var d = B.channels, p = Array(e.channels), g = 0; g < e.channels; ++g) {
                    var v = p[g] = {},
                        w = d[g];
                    v.name = w.name, v.compression = 0, v.decoded = !1, v.type = w.pixelType, v.pLinear = w.pLinear, v.width = e.width, v.height = e.lines
                }
                for (var b = {
                        idx: [, , , ]
                    }, x = 0; x < e.channels; ++x)
                    for (var v = p[x], g = 0; g < i.length; ++g) {
                        var E = i[g];
                        v.name == E.name && (v.compression = E.compression, E.index >= 0 && (b.idx[E.index] = x), v.offset = x)
                    }
                if (n.acCompressedSize > 0) switch (n.acCompression) {
                    case 0:
                        var T = new Uint16Array(n.totalAcUncompressedCount);
                        c(e.array, t, r, n.acCompressedSize, T, n.totalAcUncompressedCount);
                        break;
                    case 1:
                        var S = e.array.slice(r.value, r.value + n.totalAcUncompressedCount),
                            P = tb(S),
                            T = new Uint16Array(P.buffer);
                        r.value += n.totalAcUncompressedCount
                }
                if (n.dcCompressedSize > 0) {
                    var R = new Uint16Array(y({
                        array: e.array,
                        offset: r,
                        size: n.dcCompressedSize
                    }).buffer);
                    r.value += n.dcCompressedSize
                }
                if (n.rleRawSize > 0) {
                    var S = e.array.slice(r.value, r.value + n.rleCompressedSize),
                        P = tb(S),
                        k = m(P.buffer);
                    r.value += n.rleCompressedSize
                }
                for (var F = 0, U = Array(p.length), g = 0; g < U.length; ++g) U[g] = [];
                for (var O = 0; O < e.lines; ++O)
                    for (var D = 0; D < p.length; ++D) U[D].push(F), F += p[D].width * e.type * 2;
                ! function(e, t, r, a, n, i) {
                    var o = new DataView(i.buffer),
                        s = r[e.idx[0]].width,
                        l = r[e.idx[0]].height,
                        h = Math.floor(s / 8),
                        u = Math.ceil(s / 8),
                        f = Math.ceil(l / 8),
                        c = s - (u - 1) * 8,
                        d = l - (f - 1) * 8,
                        p = {
                            value: 0
                        },
                        m = [, , , ],
                        g = [, , , ],
                        v = [, , , ],
                        y = [, , , ],
                        w = [, , , ];
                    for (let r = 0; r < 3; ++r) w[r] = t[e.idx[r]], m[r] = r < 1 ? 0 : m[r - 1] + u * f, g[r] = new Float32Array(64), v[r] = new Uint16Array(64), y[r] = new Uint16Array(64 * u);
                    for (let t = 0; t < f; ++t) {
                        var b, x, M = 8;
                        t == f - 1 && (M = d);
                        var E = 8;
                        for (let e = 0; e < u; ++e) {
                            e == u - 1 && (E = c);
                            for (let e = 0; e < 3; ++e) {
                                v[e].fill(0), v[e][0] = n[m[e]++],
                                    function(e, t, r) {
                                        for (var a, n = 1; n < 64;) 65280 == (a = t[e.value]) ? n = 64 : a >> 8 == 255 ? n += 255 & a : (r[n] = a, n++), e.value++
                                    }(p, a, v[e]), b = v[e], (x = g[e])[0] = _(b[0]), x[1] = _(b[1]), x[2] = _(b[5]), x[3] = _(b[6]), x[4] = _(b[14]), x[5] = _(b[15]), x[6] = _(b[27]), x[7] = _(b[28]), x[8] = _(b[2]), x[9] = _(b[4]), x[10] = _(b[7]), x[11] = _(b[13]), x[12] = _(b[16]), x[13] = _(b[26]), x[14] = _(b[29]), x[15] = _(b[42]), x[16] = _(b[3]), x[17] = _(b[8]), x[18] = _(b[12]), x[19] = _(b[17]), x[20] = _(b[25]), x[21] = _(b[30]), x[22] = _(b[41]), x[23] = _(b[43]), x[24] = _(b[9]), x[25] = _(b[11]), x[26] = _(b[18]), x[27] = _(b[24]), x[28] = _(b[31]), x[29] = _(b[40]), x[30] = _(b[44]), x[31] = _(b[53]), x[32] = _(b[10]), x[33] = _(b[19]), x[34] = _(b[23]), x[35] = _(b[32]), x[36] = _(b[39]), x[37] = _(b[45]), x[38] = _(b[52]), x[39] = _(b[54]), x[40] = _(b[20]), x[41] = _(b[22]), x[42] = _(b[33]), x[43] = _(b[38]), x[44] = _(b[46]), x[45] = _(b[51]), x[46] = _(b[55]), x[47] = _(b[60]), x[48] = _(b[21]), x[49] = _(b[34]), x[50] = _(b[37]), x[51] = _(b[47]), x[52] = _(b[50]), x[53] = _(b[56]), x[54] = _(b[59]), x[55] = _(b[61]), x[56] = _(b[35]), x[57] = _(b[36]), x[58] = _(b[48]), x[59] = _(b[49]), x[60] = _(b[57]), x[61] = _(b[58]), x[62] = _(b[62]), x[63] = _(b[63]),
                                    function(e) {
                                        let t = .5 * Math.cos(3.14159 / 16),
                                            r = .5 * Math.cos(3.14159 / 8),
                                            a = .5 * Math.cos(3 * 3.14159 / 16),
                                            n = .5 * Math.cos(3 * 3.14159 / 8);
                                        for (var i = [, , , , ], o = [, , , , ], s = [, , , , ], l = [, , , , ], h = 0; h < 8; ++h) {
                                            var u = 8 * h;
                                            i[0] = r * e[u + 2], i[1] = n * e[u + 2], i[2] = r * e[u + 6], i[3] = n * e[u + 6], o[0] = t * e[u + 1] + a * e[u + 3] + .2777854612564676 * e[u + 5] + .09754573032714427 * e[u + 7], o[1] = a * e[u + 1] - .09754573032714427 * e[u + 3] - t * e[u + 5] - .2777854612564676 * e[u + 7], o[2] = .2777854612564676 * e[u + 1] - t * e[u + 3] + .09754573032714427 * e[u + 5] + a * e[u + 7], o[3] = .09754573032714427 * e[u + 1] - .2777854612564676 * e[u + 3] + a * e[u + 5] - t * e[u + 7], s[0] = .35355362513961314 * (e[u + 0] + e[u + 4]), s[3] = .35355362513961314 * (e[u + 0] - e[u + 4]), s[1] = i[0] + i[3], s[2] = i[1] - i[2], l[0] = s[0] + s[1], l[1] = s[3] + s[2], l[2] = s[3] - s[2], l[3] = s[0] - s[1], e[u + 0] = l[0] + o[0], e[u + 1] = l[1] + o[1], e[u + 2] = l[2] + o[2], e[u + 3] = l[3] + o[3], e[u + 4] = l[3] - o[3], e[u + 5] = l[2] - o[2], e[u + 6] = l[1] - o[1], e[u + 7] = l[0] - o[0]
                                        }
                                        for (var f = 0; f < 8; ++f) i[0] = r * e[16 + f], i[1] = n * e[16 + f], i[2] = r * e[48 + f], i[3] = n * e[48 + f], o[0] = t * e[8 + f] + a * e[24 + f] + .2777854612564676 * e[40 + f] + .09754573032714427 * e[56 + f], o[1] = a * e[8 + f] - .09754573032714427 * e[24 + f] - t * e[40 + f] - .2777854612564676 * e[56 + f], o[2] = .2777854612564676 * e[8 + f] - t * e[24 + f] + .09754573032714427 * e[40 + f] + a * e[56 + f], o[3] = .09754573032714427 * e[8 + f] - .2777854612564676 * e[24 + f] + a * e[40 + f] - t * e[56 + f], s[0] = .35355362513961314 * (e[f] + e[32 + f]), s[3] = .35355362513961314 * (e[f] - e[32 + f]), s[1] = i[0] + i[3], s[2] = i[1] - i[2], l[0] = s[0] + s[1], l[1] = s[3] + s[2], l[2] = s[3] - s[2], l[3] = s[0] - s[1], e[0 + f] = l[0] + o[0], e[8 + f] = l[1] + o[1], e[16 + f] = l[2] + o[2], e[24 + f] = l[3] + o[3], e[32 + f] = l[3] - o[3], e[40 + f] = l[2] - o[2], e[48 + f] = l[1] - o[1], e[56 + f] = l[0] - o[0]
                                    }(g[e])
                            }
                            for (var T = g, S = 0; S < 64; ++S) {
                                var A = T[0][S],
                                    C = T[1][S],
                                    P = T[2][S];
                                T[0][S] = A + 1.5747 * P, T[1][S] = A - .1873 * C - .4682 * P, T[2][S] = A + 1.8556 * C
                            }
                            for (let t = 0; t < 3; ++t) ! function(e, t, r) {
                                for (var a, n = 0; n < 64; ++n) {
                                    t[r + n] = ea.DataUtils.toHalfFloat((a = e[n]) <= 1 ? Math.sign(a) * Math.pow(Math.abs(a), 2.2) : Math.sign(a) * Math.pow(9.025013291561939, Math.abs(a) - 1))
                                }
                            }(g[t], y[t], 64 * e)
                        }
                        let i = 0;
                        for (let a = 0; a < 3; ++a) {
                            let n = r[e.idx[a]].type;
                            for (let e = 8 * t; e < 8 * t + M; ++e) {
                                i = w[a][e];
                                for (let t = 0; t < h; ++t) {
                                    let r = 64 * t + (7 & e) * 8;
                                    o.setUint16(i + 0 * n, y[a][r + 0], !0), o.setUint16(i + 2 * n, y[a][r + 1], !0), o.setUint16(i + 4 * n, y[a][r + 2], !0), o.setUint16(i + 6 * n, y[a][r + 3], !0), o.setUint16(i + 8 * n, y[a][r + 4], !0), o.setUint16(i + 10 * n, y[a][r + 5], !0), o.setUint16(i + 12 * n, y[a][r + 6], !0), o.setUint16(i + 14 * n, y[a][r + 7], !0), i += 16 * n
                                }
                            }
                            if (h != u)
                                for (let e = 8 * t; e < 8 * t + M; ++e) {
                                    let t = w[a][e] + 8 * h * 2 * n,
                                        r = 64 * h + (7 & e) * 8;
                                    for (let e = 0; e < E; ++e) o.setUint16(t + 2 * e * n, y[a][r + e], !0)
                                }
                        }
                    }
                    for (var R = new Uint16Array(s), o = new DataView(i.buffer), I = 0; I < 3; ++I) {
                        r[e.idx[I]].decoded = !0;
                        var k = r[e.idx[I]].type;
                        if (2 == r[I].type)
                            for (var F = 0; F < l; ++F) {
                                let e = w[I][F];
                                for (var U = 0; U < s; ++U) R[U] = o.getUint16(e + 2 * U * k, !0);
                                for (var U = 0; U < s; ++U) o.setFloat32(e + 2 * U * k, _(R[U]), !0)
                            }
                    }
                }(b, U, p, T, R, a);
                for (var g = 0; g < p.length; ++g) {
                    var v = p[g];
                    if (!v.decoded)
                        if (2 === v.compression)
                            for (var L = 0, G = 0, O = 0; O < e.lines; ++O) {
                                for (var z = U[g][L], H = 0; H < v.width; ++H) {
                                    for (var j = 0; j < 2 * v.type; ++j) a[z++] = k[G + j * v.width * v.height];
                                    G++
                                }
                                L++
                            } else throw "EXRLoader.parse: unsupported channel compression"
                }
                return new DataView(a.buffer)
            }

            function M(e, t) {
                for (var r = new Uint8Array(e), a = 0; 0 != r[t.value + a];) a += 1;
                var n = new TextDecoder().decode(r.slice(t.value, t.value + a));
                return t.value = t.value + a + 1, n
            }

            function E(e, t) {
                var r = e.getInt32(t.value, !0);
                return t.value = t.value + 4, r
            }

            function T(e, t) {
                var r = e.getUint32(t.value, !0);
                return t.value = t.value + 4, r
            }

            function S(e, t) {
                var r = e[t.value];
                return t.value = t.value + 1, r
            }

            function A(e, t) {
                var r = e.getUint8(t.value);
                return t.value = t.value + 1, r
            }
            let C = function(e, t) {
                let r;
                return r = "getBigInt64" in DataView.prototype ? Number(e.getBigInt64(t.value, !0)) : e.getUint32(t.value + 4, !0) + Number(e.getUint32(t.value, !0) << 32), t.value += 8, r
            };

            function P(e, t) {
                var r = e.getFloat32(t.value, !0);
                return t.value += 4, r
            }

            function R(e, t) {
                return ea.DataUtils.toHalfFloat(P(e, t))
            }

            function _(e) {
                var t = (31744 & e) >> 10,
                    r = 1023 & e;
                return (e >> 15 ? -1 : 1) * (t ? 31 === t ? r ? NaN : 1 / 0 : Math.pow(2, t - 15) * (1 + r / 1024) : r / 1024 * 6103515625e-14)
            }

            function I(e, t) {
                var r = e.getUint16(t.value, !0);
                return t.value += 2, r
            }

            function k(e, t) {
                return _(I(e, t))
            }
            let F = new DataView(e),
                U = new Uint8Array(e),
                O = {
                    value: 0
                },
                B = function(e, t, r) {
                    let a = {};
                    if (0x1312f76 != e.getUint32(0, !0)) throw "THREE.EXRLoader: provided file doesn't appear to be in OpenEXR format.";
                    a.version = e.getUint8(4);
                    let n = e.getUint8(5);
                    a.spec = {
                        singleTile: !!(2 & n),
                        longName: !!(4 & n),
                        deepFormat: !!(8 & n),
                        multiPart: !!(16 & n)
                    }, r.value = 8;
                    for (var i = !0; i;) {
                        var o = M(t, r);
                        if (0 == o) i = !1;
                        else {
                            var s = M(t, r),
                                l = T(e, r),
                                h = function(e, t, r, a, n) {
                                    var i, o, s, l, h, u, f;
                                    if ("string" === a || "stringvector" === a || "iccProfile" === a) return i = new TextDecoder().decode(new Uint8Array(t).slice(r.value, r.value + n)), r.value = r.value + n, i;
                                    if ("chlist" === a) return function(e, t, r, a) {
                                        for (var n = r.value, i = []; r.value < n + a - 1;) {
                                            var o = M(t, r),
                                                s = E(e, r),
                                                l = A(e, r);
                                            r.value += 3;
                                            var h = E(e, r),
                                                u = E(e, r);
                                            i.push({
                                                name: o,
                                                pixelType: s,
                                                pLinear: l,
                                                xSampling: h,
                                                ySampling: u
                                            })
                                        }
                                        return r.value += 1, i
                                    }(e, t, r, n);
                                    if ("chromaticities" === a) return o = P(e, r), s = P(e, r), l = P(e, r), h = P(e, r), u = P(e, r), {
                                        redX: o,
                                        redY: s,
                                        greenX: l,
                                        greenY: h,
                                        blueX: u,
                                        blueY: P(e, r),
                                        whiteX: P(e, r),
                                        whiteY: P(e, r)
                                    };
                                    if ("compression" === a) return ["NO_COMPRESSION", "RLE_COMPRESSION", "ZIPS_COMPRESSION", "ZIP_COMPRESSION", "PIZ_COMPRESSION", "PXR24_COMPRESSION", "B44_COMPRESSION", "B44A_COMPRESSION", "DWAA_COMPRESSION", "DWAB_COMPRESSION"][A(e, r)];
                                    if ("box2i" === a) return f = T(e, r), {
                                        xMin: f,
                                        yMin: T(e, r),
                                        xMax: T(e, r),
                                        yMax: T(e, r)
                                    };
                                    else if ("lineOrder" === a) return ["INCREASING_Y"][A(e, r)];
                                    else if ("float" === a) return P(e, r);
                                    else if ("v2f" === a) return [P(e, r), P(e, r)];
                                    else if ("v3f" === a) return [P(e, r), P(e, r), P(e, r)];
                                    else if ("int" === a) return E(e, r);
                                    else if ("rational" === a) return [E(e, r), T(e, r)];
                                    else if ("timecode" === a) return [T(e, r), T(e, r)];
                                    else return "preview" === a ? (r.value += n, "skipped") : (r.value += n, void 0)
                                }(e, t, r, s, l);
                            void 0 === h ? console.warn(`EXRLoader.parse: skipped unknown header attribute type '${s}'.`) : a[o] = h
                        }
                    }
                    if ((-5 & n) != 0) throw console.error("EXRHeader:", a), "THREE.EXRLoader: provided file is currently unsupported.";
                    return a
                }(F, e, O),
                D = function(e, t, r, a, n) {
                    let i = {
                        size: 0,
                        viewer: t,
                        array: r,
                        offset: a,
                        width: e.dataWindow.xMax - e.dataWindow.xMin + 1,
                        height: e.dataWindow.yMax - e.dataWindow.yMin + 1,
                        channels: e.channels.length,
                        bytesPerLine: null,
                        lines: null,
                        inputSize: null,
                        type: e.channels[0].pixelType,
                        uncompress: null,
                        getter: null,
                        format: null,
                        [tz ? "colorSpace" : "encoding"]: null
                    };
                    switch (e.compression) {
                        case "NO_COMPRESSION":
                            i.lines = 1, i.uncompress = g;
                            break;
                        case "RLE_COMPRESSION":
                            i.lines = 1, i.uncompress = v;
                            break;
                        case "ZIPS_COMPRESSION":
                            i.lines = 1, i.uncompress = y;
                            break;
                        case "ZIP_COMPRESSION":
                            i.lines = 16, i.uncompress = y;
                            break;
                        case "PIZ_COMPRESSION":
                            i.lines = 32, i.uncompress = w;
                            break;
                        case "PXR24_COMPRESSION":
                            i.lines = 16, i.uncompress = b;
                            break;
                        case "DWAA_COMPRESSION":
                            i.lines = 32, i.uncompress = x;
                            break;
                        case "DWAB_COMPRESSION":
                            i.lines = 256, i.uncompress = x;
                            break;
                        default:
                            throw "EXRLoader.parse: " + e.compression + " is unsupported"
                    }
                    if (i.scanlineBlockSize = i.lines, 1 == i.type) switch (n) {
                        case ea.FloatType:
                            i.getter = k, i.inputSize = 2;
                            break;
                        case ea.HalfFloatType:
                            i.getter = I, i.inputSize = 2
                    } else if (2 == i.type) switch (n) {
                        case ea.FloatType:
                            i.getter = P, i.inputSize = 4;
                            break;
                        case ea.HalfFloatType:
                            i.getter = R, i.inputSize = 4
                    } else throw "EXRLoader.parse: unsupported pixelType " + i.type + " for " + e.compression + ".";
                    i.blockCount = (e.dataWindow.yMax + 1) / i.scanlineBlockSize;
                    for (var o = 0; o < i.blockCount; o++) C(t, a);
                    i.outputChannels = 3 == i.channels ? 4 : i.channels;
                    let s = i.width * i.height * i.outputChannels;
                    switch (n) {
                        case ea.FloatType:
                            i.byteArray = new Float32Array(s), i.channels < i.outputChannels && i.byteArray.fill(1, 0, s);
                            break;
                        case ea.HalfFloatType:
                            i.byteArray = new Uint16Array(s), i.channels < i.outputChannels && i.byteArray.fill(15360, 0, s);
                            break;
                        default:
                            console.error("THREE.EXRLoader: unsupported type: ", n)
                    }
                    return i.bytesPerLine = i.width * i.inputSize * i.channels, 4 == i.outputChannels ? i.format = ea.RGBAFormat : i.format = ea.RedFormat, tz ? i.colorSpace = "srgb-linear" : i.encoding = 3e3, i
                }(B, F, U, O, this.type),
                L = {
                    value: 0
                },
                G = {
                    R: 0,
                    G: 1,
                    B: 2,
                    A: 3,
                    Y: 0
                };
            for (let e = 0; e < D.height / D.scanlineBlockSize; e++) {
                let t = T(F, O);
                D.size = T(F, O), D.lines = t + D.scanlineBlockSize > D.height ? D.height - t : D.scanlineBlockSize;
                let r = D.size < D.lines * D.bytesPerLine ? D.uncompress(D) : g(D);
                O.value += D.size;
                for (let t = 0; t < D.scanlineBlockSize; t++) {
                    let a = t + e * D.scanlineBlockSize;
                    if (a >= D.height) break;
                    for (let e = 0; e < D.channels; e++) {
                        let n = G[B.channels[e].name];
                        for (let i = 0; i < D.width; i++) {
                            L.value = (t * (D.channels * D.width) + e * D.width + i) * D.inputSize;
                            let o = (D.height - 1 - a) * (D.width * D.outputChannels) + i * D.outputChannels + n;
                            D.byteArray[o] = D.getter(r, L)
                        }
                    }
                }
            }
            return {
                header: B,
                width: D.width,
                height: D.height,
                data: D.byteArray,
                format: D.format,
                [tz ? "colorSpace" : "encoding"]: D[tz ? "colorSpace" : "encoding"],
                type: this.type
            }
        }
        setDataType(e) {
            return this.type = e, this
        }
        load(e, t, r, a) {
            return super.load(e, function(e, r) {
                tz ? e.colorSpace = r.colorSpace : e.encoding = r.encoding, e.minFilter = ea.LinearFilter, e.magFilter = ea.LinearFilter, e.generateMipmaps = !1, e.flipY = !1, t && t(e, r)
            }, r, a)
        }
    }
    let tj = (e, t, r) => {
        let n;
        switch (e) {
            case a.UnsignedByteType:
                n = new Uint8ClampedArray(t * r * 4);
                break;
            case a.HalfFloatType:
                n = new Uint16Array(t * r * 4);
                break;
            case a.UnsignedIntType:
                n = new Uint32Array(t * r * 4);
                break;
            case a.ByteType:
                n = new Int8Array(t * r * 4);
                break;
            case a.ShortType:
                n = new Int16Array(t * r * 4);
                break;
            case a.IntType:
                n = new Int32Array(t * r * 4);
                break;
            case a.FloatType:
                n = new Float32Array(t * r * 4);
                break;
            default:
                throw Error("Unsupported data type")
        }
        return n
    };
    class tW {
        _renderer;
        _rendererIsDisposable = !1;
        _material;
        _scene;
        _camera;
        _quad;
        _renderTarget;
        _width;
        _height;
        _type;
        _colorSpace;
        _supportsReadPixels = !0;
        constructor(e) {
            this._width = e.width, this._height = e.height, this._type = e.type, this._colorSpace = e.colorSpace;
            const r = {
                format: a.RGBAFormat,
                depthBuffer: !1,
                stencilBuffer: !1,
                type: this._type,
                colorSpace: this._colorSpace,
                anisotropy: e.renderTargetOptions ? .anisotropy !== void 0 ? e.renderTargetOptions ? .anisotropy : 1,
                generateMipmaps: e.renderTargetOptions ? .generateMipmaps !== void 0 && e.renderTargetOptions ? .generateMipmaps,
                magFilter: e.renderTargetOptions ? .magFilter !== void 0 ? e.renderTargetOptions ? .magFilter : a.LinearFilter,
                minFilter: e.renderTargetOptions ? .minFilter !== void 0 ? e.renderTargetOptions ? .minFilter : a.LinearFilter,
                samples: e.renderTargetOptions ? .samples !== void 0 ? e.renderTargetOptions ? .samples : void 0,
                wrapS: e.renderTargetOptions ? .wrapS !== void 0 ? e.renderTargetOptions ? .wrapS : a.ClampToEdgeWrapping,
                wrapT: e.renderTargetOptions ? .wrapT !== void 0 ? e.renderTargetOptions ? .wrapT : a.ClampToEdgeWrapping
            };
            if (this._material = e.material, e.renderer ? this._renderer = e.renderer : (this._renderer = tW.instantiateRenderer(), this._rendererIsDisposable = !0), this._scene = new a.Scene, this._camera = new a.OrthographicCamera, this._camera.position.set(0, 0, 10), this._camera.left = -.5, this._camera.right = .5, this._camera.top = .5, this._camera.bottom = -.5, this._camera.updateProjectionMatrix(), !((e, r, n, i) => {
                    if (void 0 !== t) return t;
                    let o = new a.WebGLRenderTarget(1, 1, i);
                    r.setRenderTarget(o);
                    let s = new a.Mesh(new a.PlaneGeometry, new a.MeshBasicMaterial({
                        color: 0xffffff
                    }));
                    r.render(s, n), r.setRenderTarget(null);
                    let l = tj(e, o.width, o.height);
                    return r.readRenderTargetPixels(o, 0, 0, o.width, o.height, l), o.dispose(), s.geometry.dispose(), s.material.dispose(), t = 0 !== l[0]
                })(this._type, this._renderer, this._camera, r)) {
                let e;
                this._type === a.HalfFloatType && (e = this._renderer.extensions.has("EXT_color_buffer_float") ? a.FloatType : void 0), void 0 !== e ? (console.warn(`This browser does not support reading pixels from ${this._type} RenderTargets, switching to ${a.FloatType}`), this._type = e) : (this._supportsReadPixels = !1, console.warn("This browser dos not support toArray or toDataTexture, calls to those methods will result in an error thrown"))
            }
            this._quad = new a.Mesh(new a.PlaneGeometry, this._material), this._quad.geometry.computeBoundingBox(), this._scene.add(this._quad), this._renderTarget = new a.WebGLRenderTarget(this.width, this.height, r), this._renderTarget.texture.mapping = e.renderTargetOptions ? .mapping !== void 0 ? e.renderTargetOptions ? .mapping : a.UVMapping
        }
        static instantiateRenderer() {
            let e = new Q.WebGLRenderer;
            return e.setSize(128, 128), e
        }
        render = () => {
            this._renderer.setRenderTarget(this._renderTarget);
            try {
                this._renderer.render(this._scene, this._camera)
            } catch (e) {
                throw this._renderer.setRenderTarget(null), e
            }
            this._renderer.setRenderTarget(null)
        };
        toArray() {
            if (!this._supportsReadPixels) throw Error("Can't read pixels in this browser");
            let e = tj(this._type, this._width, this._height);
            return this._renderer.readRenderTargetPixels(this._renderTarget, 0, 0, this._width, this._height, e), e
        }
        toDataTexture(e) {
            let t = new a.DataTexture(this.toArray(), this.width, this.height, a.RGBAFormat, this._type, e ? .mapping || a.UVMapping, e ? .wrapS || a.ClampToEdgeWrapping, e ? .wrapT || a.ClampToEdgeWrapping, e ? .magFilter || a.LinearFilter, e ? .minFilter || a.LinearFilter, e ? .anisotropy || 1, a.LinearSRGBColorSpace);
            return t.generateMipmaps = e ? .generateMipmaps !== void 0 && e ? .generateMipmaps, t
        }
        disposeOnDemandRenderer() {
            this._renderer.setRenderTarget(null), this._rendererIsDisposable && (this._renderer.dispose(), this._renderer.forceContextLoss())
        }
        dispose(e) {
            this.disposeOnDemandRenderer(), e && this.renderTarget.dispose(), this.material instanceof a.ShaderMaterial && Object.values(this.material.uniforms).forEach(e => {
                e.value instanceof a.Texture && e.value.dispose()
            }), Object.values(this.material).forEach(e => {
                e instanceof a.Texture && e.dispose()
            }), this.material.dispose(), this._quad.geometry.dispose()
        }
        get width() {
            return this._width
        }
        set width(e) {
            this._width = e, this._renderTarget.setSize(this._width, this._height)
        }
        get height() {
            return this._height
        }
        set height(e) {
            this._height = e, this._renderTarget.setSize(this._width, this._height)
        }
        get renderer() {
            return this._renderer
        }
        get renderTarget() {
            return this._renderTarget
        }
        set renderTarget(e) {
            this._renderTarget = e, this._width = e.width, this._height = e.height
        }
        get material() {
            return this._material
        }
        get type() {
            return this._type
        }
        get colorSpace() {
            return this._colorSpace
        }
    }
    var tN = a;
    class tV extends Error {}
    class t$ extends Error {}
    let tq = (e, t, r) => {
        let a = RegExp(`${t}="([^"]*)"`, "i").exec(e);
        if (a) return a[1];
        let n = RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`, "i").exec(e);
        if (n) {
            let e = n[1].match(/<rdf:li>([^<]*)<\/rdf:li>/g);
            return e && 3 === e.length ? e.map(e => e.replace(/<\/?rdf:li>/g, "")) : n[1].trim()
        }
        if (void 0 !== r) return r;
        throw Error(`Can't find ${t} in gainmap metadata`)
    };
    class tX {
        options;
        constructor(e) {
            this.options = {
                debug: !!e && void 0 !== e.debug && e.debug,
                extractFII: !e || void 0 === e.extractFII || e.extractFII,
                extractNonFII: !e || void 0 === e.extractNonFII || e.extractNonFII
            }
        }
        extract(e) {
            return new Promise((t, r) => {
                let a, n = this.options.debug,
                    i = new DataView(e.buffer);
                if (65496 !== i.getUint16(0)) return void r(Error("Not a valid jpeg"));
                let o = i.byteLength,
                    s = 2,
                    l = 0;
                for (; s < o;) {
                    if (++l > 250) return void r(Error(`Found no marker after ${l} loops 😵`));
                    if (255 !== i.getUint8(s)) return void r(Error(`Not a valid marker at offset 0x${s.toString(16)}, found: 0x${i.getUint8(s).toString(16)}`));
                    if (a = i.getUint8(s + 1), n && console.log(`Marker: ${a.toString(16)}`), 226 === a) {
                        n && console.log("Found APP2 marker (0xffe2)");
                        let e = s + 4;
                        if (0x4d504600 === i.getUint32(e)) {
                            let a, n = e + 4;
                            if (18761 === i.getUint16(n)) a = !1;
                            else {
                                if (19789 !== i.getUint16(n)) return void r(Error("No valid endianness marker found in TIFF header"));
                                a = !0
                            }
                            if (42 !== i.getUint16(n + 2, !a)) return void r(Error("Not valid TIFF data! (no 0x002A marker)"));
                            let o = i.getUint32(n + 4, !a);
                            if (o < 8) return void r(Error("Not valid TIFF data! (First offset less than 8)"));
                            let s = n + o,
                                l = i.getUint16(s, !a),
                                h = s + 2,
                                u = 0;
                            for (let e = h; e < h + 12 * l; e += 12) 45057 === i.getUint16(e, !a) && (u = i.getUint32(e + 8, !a));
                            let f = s + 2 + 12 * l + 4,
                                c = [];
                            for (let e = f; e < f + 16 * u; e += 16) {
                                let t = {
                                    MPType: i.getUint32(e, !a),
                                    size: i.getUint32(e + 4, !a),
                                    dataOffset: i.getUint32(e + 8, !a),
                                    dependantImages: i.getUint32(e + 12, !a),
                                    start: -1,
                                    end: -1,
                                    isFII: !1
                                };
                                t.dataOffset ? (t.start = n + t.dataOffset, t.isFII = !1) : (t.start = 0, t.isFII = !0), t.end = t.start + t.size, c.push(t)
                            }
                            if (this.options.extractNonFII && c.length) {
                                let e = new Blob([i]),
                                    r = [];
                                for (let t of c) {
                                    if (t.isFII && !this.options.extractFII) continue;
                                    let a = e.slice(t.start, t.end + 1, "image/jpeg");
                                    r.push(a)
                                }
                                t(r)
                            }
                        }
                    }
                    s += 2 + i.getUint16(s + 2)
                }
            })
        }
    }
    let tY = async e => {
            let t = (e => {
                let t, r = (t = "u" > typeof TextDecoder ? new TextDecoder().decode(e) : e.toString()).indexOf("<x:xmpmeta");
                for (; - 1 !== r;) {
                    let e = t.indexOf("x:xmpmeta>", r),
                        a = t.slice(r, e + 10);
                    try {
                        let e = tq(a, "hdrgm:GainMapMin", "0"),
                            t = tq(a, "hdrgm:GainMapMax"),
                            r = tq(a, "hdrgm:Gamma", "1"),
                            n = tq(a, "hdrgm:OffsetSDR", "0.015625"),
                            i = tq(a, "hdrgm:OffsetHDR", "0.015625"),
                            o = /hdrgm:HDRCapacityMin="([^"]*)"/.exec(a),
                            s = o ? o[1] : "0",
                            l = /hdrgm:HDRCapacityMax="([^"]*)"/.exec(a);
                        if (!l) throw Error("Incomplete gainmap metadata");
                        let h = l[1];
                        return {
                            gainMapMin: Array.isArray(e) ? e.map(e => parseFloat(e)) : [parseFloat(e), parseFloat(e), parseFloat(e)],
                            gainMapMax: Array.isArray(t) ? t.map(e => parseFloat(e)) : [parseFloat(t), parseFloat(t), parseFloat(t)],
                            gamma: Array.isArray(r) ? r.map(e => parseFloat(e)) : [parseFloat(r), parseFloat(r), parseFloat(r)],
                            offsetSdr: Array.isArray(n) ? n.map(e => parseFloat(e)) : [parseFloat(n), parseFloat(n), parseFloat(n)],
                            offsetHdr: Array.isArray(i) ? i.map(e => parseFloat(e)) : [parseFloat(i), parseFloat(i), parseFloat(i)],
                            hdrCapacityMin: parseFloat(s),
                            hdrCapacityMax: parseFloat(h)
                        }
                    } catch (e) {}
                    r = t.indexOf("<x:xmpmeta", e)
                }
            })(e);
            if (!t) throw new t$("Gain map XMP metadata not found");
            let r = new tX({
                    extractFII: !0,
                    extractNonFII: !0
                }),
                a = await r.extract(e);
            if (2 !== a.length) throw new tV("Gain map recovery image not found");
            return {
                sdr: new Uint8Array(await a[0].arrayBuffer()),
                gainMap: new Uint8Array(await a[1].arrayBuffer()),
                metadata: t
            }
        },
        tZ = e => new Promise((t, r) => {
            let a = document.createElement("img");
            a.onload = () => {
                t(a)
            }, a.onerror = e => {
                r(e)
            }, a.src = URL.createObjectURL(e)
        });
    class tQ extends tN.Loader {
        _renderer;
        _renderTargetOptions;
        _internalLoadingManager;
        _config;
        constructor(e, t) {
            super(t), this._config = e, e.renderer && (this._renderer = e.renderer), this._internalLoadingManager = new tN.LoadingManager
        }
        setRenderer(e) {
            return this._renderer = e, this
        }
        setRenderTargetOptions(e) {
            return this._renderTargetOptions = e, this
        }
        prepareQuadRenderer() {
            this._renderer || console.warn("WARNING: A Renderer was not passed to this Loader constructor or in setRenderer, the result of this Loader will need to be converted to a Data Texture with toDataTexture() before you can use it in your renderer.");
            let e = this._config.createMaterial({
                gainMapMax: [1, 1, 1],
                gainMapMin: [0, 0, 0],
                gamma: [1, 1, 1],
                offsetHdr: [1, 1, 1],
                offsetSdr: [1, 1, 1],
                hdrCapacityMax: 1,
                hdrCapacityMin: 0,
                maxDisplayBoost: 1,
                gainMap: new tN.Texture,
                sdr: new tN.Texture
            });
            return this._config.createQuadRenderer({
                width: 16,
                height: 16,
                type: tN.HalfFloatType,
                colorSpace: tN.LinearSRGBColorSpace,
                material: e,
                renderer: this._renderer,
                renderTargetOptions: this._renderTargetOptions
            })
        }
        async processImages(e, t, r) {
            let a, n, i = t ? new Blob([t], {
                    type: "image/jpeg"
                }) : void 0,
                o = new Blob([e], {
                    type: "image/jpeg"
                }),
                s = !1;
            if ("u" < typeof createImageBitmap) {
                let e = await Promise.all([i ? tZ(i) : Promise.resolve(void 0), tZ(o)]);
                n = e[0], a = e[1], s = "flipY" === r
            } else {
                let e = await Promise.all([i ? createImageBitmap(i, {
                    imageOrientation: r || "flipY"
                }) : Promise.resolve(void 0), createImageBitmap(o, {
                    imageOrientation: r || "flipY"
                })]);
                n = e[0], a = e[1]
            }
            return {
                sdrImage: a,
                gainMapImage: n,
                needsFlip: s
            }
        }
        createTextures(e, t, r) {
            let a = new tN.Texture(t || new ImageData(2, 2), tN.UVMapping, tN.ClampToEdgeWrapping, tN.ClampToEdgeWrapping, tN.LinearFilter, tN.LinearMipMapLinearFilter, tN.RGBAFormat, tN.UnsignedByteType, 1, tN.LinearSRGBColorSpace);
            a.flipY = r, a.needsUpdate = !0;
            let n = new tN.Texture(e, tN.UVMapping, tN.ClampToEdgeWrapping, tN.ClampToEdgeWrapping, tN.LinearFilter, tN.LinearMipMapLinearFilter, tN.RGBAFormat, tN.UnsignedByteType, 1, tN.SRGBColorSpace);
            return n.flipY = r, n.needsUpdate = !0, {
                gainMap: a,
                sdr: n
            }
        }
        updateQuadRenderer(e, t, r, a, n) {
            e.width = t.width, e.height = t.height, e.material.gainMap = r, e.material.sdr = a, e.material.gainMapMin = n.gainMapMin, e.material.gainMapMax = n.gainMapMax, e.material.offsetHdr = n.offsetHdr, e.material.offsetSdr = n.offsetSdr, e.material.gamma = n.gamma, e.material.hdrCapacityMin = n.hdrCapacityMin, e.material.hdrCapacityMax = n.hdrCapacityMax, e.material.maxDisplayBoost = Math.pow(2, n.hdrCapacityMax), e.material.needsUpdate = !0
        }
    }
    var tK = a;
    let tJ = `
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
        t0 = `
// min half float value
#define HALF_FLOAT_MIN vec3( -65504, -65504, -65504 )
// max half float value
#define HALF_FLOAT_MAX vec3( 65504, 65504, 65504 )

uniform sampler2D sdr;
uniform sampler2D gainMap;
uniform vec3 gamma;
uniform vec3 offsetHdr;
uniform vec3 offsetSdr;
uniform vec3 gainMapMin;
uniform vec3 gainMapMax;
uniform float weightFactor;

varying vec2 vUv;

void main() {
  vec3 rgb = texture2D( sdr, vUv ).rgb;
  vec3 recovery = texture2D( gainMap, vUv ).rgb;
  vec3 logRecovery = pow( recovery, gamma );
  vec3 logBoost = gainMapMin * ( 1.0 - logRecovery ) + gainMapMax * logRecovery;
  vec3 hdrColor = (rgb + offsetSdr) * exp2( logBoost * weightFactor ) - offsetHdr;
  vec3 clampedHdrColor = max( HALF_FLOAT_MIN, min( HALF_FLOAT_MAX, hdrColor ));
  gl_FragColor = vec4( clampedHdrColor , 1.0 );
}
`;
    class t1 extends tK.ShaderMaterial {
        _maxDisplayBoost;
        _hdrCapacityMin;
        _hdrCapacityMax;
        constructor({
            gamma: e,
            offsetHdr: t,
            offsetSdr: r,
            gainMapMin: a,
            gainMapMax: n,
            maxDisplayBoost: i,
            hdrCapacityMin: o,
            hdrCapacityMax: s,
            sdr: l,
            gainMap: h
        }) {
            super({
                name: "GainMapDecoderMaterial",
                vertexShader: tJ,
                fragmentShader: t0,
                uniforms: {
                    sdr: {
                        value: l
                    },
                    gainMap: {
                        value: h
                    },
                    gamma: {
                        value: new tK.Vector3(1 / e[0], 1 / e[1], 1 / e[2])
                    },
                    offsetHdr: {
                        value: new tK.Vector3().fromArray(t)
                    },
                    offsetSdr: {
                        value: new tK.Vector3().fromArray(r)
                    },
                    gainMapMin: {
                        value: new tK.Vector3().fromArray(a)
                    },
                    gainMapMax: {
                        value: new tK.Vector3().fromArray(n)
                    },
                    weightFactor: {
                        value: (Math.log2(i) - o) / (s - o)
                    }
                },
                blending: tK.NoBlending,
                depthTest: !1,
                depthWrite: !1
            }), this._maxDisplayBoost = i, this._hdrCapacityMin = o, this._hdrCapacityMax = s, this.needsUpdate = !0, this.uniformsNeedUpdate = !0
        }
        get sdr() {
            return this.uniforms.sdr.value
        }
        set sdr(e) {
            this.uniforms.sdr.value = e
        }
        get gainMap() {
            return this.uniforms.gainMap.value
        }
        set gainMap(e) {
            this.uniforms.gainMap.value = e
        }
        get offsetHdr() {
            return this.uniforms.offsetHdr.value.toArray()
        }
        set offsetHdr(e) {
            this.uniforms.offsetHdr.value.fromArray(e)
        }
        get offsetSdr() {
            return this.uniforms.offsetSdr.value.toArray()
        }
        set offsetSdr(e) {
            this.uniforms.offsetSdr.value.fromArray(e)
        }
        get gainMapMin() {
            return this.uniforms.gainMapMin.value.toArray()
        }
        set gainMapMin(e) {
            this.uniforms.gainMapMin.value.fromArray(e)
        }
        get gainMapMax() {
            return this.uniforms.gainMapMax.value.toArray()
        }
        set gainMapMax(e) {
            this.uniforms.gainMapMax.value.fromArray(e)
        }
        get gamma() {
            let e = this.uniforms.gamma.value;
            return [1 / e.x, 1 / e.y, 1 / e.z]
        }
        set gamma(e) {
            let t = this.uniforms.gamma.value;
            t.x = 1 / e[0], t.y = 1 / e[1], t.z = 1 / e[2]
        }
        get hdrCapacityMin() {
            return this._hdrCapacityMin
        }
        set hdrCapacityMin(e) {
            this._hdrCapacityMin = e, this.calculateWeight()
        }
        get hdrCapacityMax() {
            return this._hdrCapacityMax
        }
        set hdrCapacityMax(e) {
            this._hdrCapacityMax = e, this.calculateWeight()
        }
        get maxDisplayBoost() {
            return this._maxDisplayBoost
        }
        set maxDisplayBoost(e) {
            this._maxDisplayBoost = Math.max(1, Math.min(65504, e)), this.calculateWeight()
        }
        calculateWeight() {
            let e = (Math.log2(this._maxDisplayBoost) - this._hdrCapacityMin) / (this._hdrCapacityMax - this._hdrCapacityMin);
            this.uniforms.weightFactor.value = Math.max(0, Math.min(1, e))
        }
    }
    Q.WebGLRenderer;
    class t2 extends tQ {
        constructor(e, t) {
            super({
                renderer: e,
                createMaterial: e => new t1(e),
                createQuadRenderer: e => new tW(e)
            }, t)
        }
        async render(e, t, r, a) {
            let {
                sdrImage: n,
                gainMapImage: i,
                needsFlip: o
            } = await this.processImages(r, a, "flipY"), {
                gainMap: s,
                sdr: l
            } = this.createTextures(n, i, o);
            this.updateQuadRenderer(e, n, s, l, t), e.render()
        }
    }
    class t5 extends t2 {
        load([e, t, r], a, n, i) {
            let o, s, l, h = this.prepareQuadRenderer(),
                u = async () => {
                    if (o && s && l) {
                        try {
                            await this.render(h, l, o, s)
                        } catch (a) {
                            this.manager.itemError(e), this.manager.itemError(t), this.manager.itemError(r), "function" == typeof i && i(a), h.disposeOnDemandRenderer();
                            return
                        }
                        "function" == typeof a && a(h), this.manager.itemEnd(e), this.manager.itemEnd(t), this.manager.itemEnd(r), h.disposeOnDemandRenderer()
                    }
                },
                f = !0,
                c = 0,
                d = 0,
                p = !0,
                m = 0,
                g = 0,
                v = !0,
                y = 0,
                w = 0,
                b = () => {
                    "function" == typeof n && n(new ProgressEvent("progress", {
                        lengthComputable: f && p && v,
                        loaded: d + g + w,
                        total: c + m + y
                    }))
                };
            this.manager.itemStart(e), this.manager.itemStart(t), this.manager.itemStart(r);
            let x = new tK.FileLoader(this._internalLoadingManager);
            x.setResponseType("arraybuffer"), x.setRequestHeader(this.requestHeader), x.setPath(this.path), x.setWithCredentials(this.withCredentials), x.load(e, async e => {
                if ("string" == typeof e) throw Error("Invalid sdr buffer");
                o = e, await u()
            }, e => {
                f = e.lengthComputable, d = e.loaded, c = e.total, b()
            }, t => {
                this.manager.itemError(e), "function" == typeof i && i(t)
            });
            let M = new tK.FileLoader(this._internalLoadingManager);
            M.setResponseType("arraybuffer"), M.setRequestHeader(this.requestHeader), M.setPath(this.path), M.setWithCredentials(this.withCredentials), M.load(t, async e => {
                if ("string" == typeof e) throw Error("Invalid gainmap buffer");
                s = e, await u()
            }, e => {
                p = e.lengthComputable, g = e.loaded, m = e.total, b()
            }, e => {
                this.manager.itemError(t), "function" == typeof i && i(e)
            });
            let E = new tK.FileLoader(this._internalLoadingManager);
            return E.setRequestHeader(this.requestHeader), E.setPath(this.path), E.setWithCredentials(this.withCredentials), E.load(r, async e => {
                if ("string" != typeof e) throw Error("Invalid metadata string");
                l = JSON.parse(e), await u()
            }, e => {
                v = e.lengthComputable, w = e.loaded, y = e.total, b()
            }, e => {
                this.manager.itemError(r), "function" == typeof i && i(e)
            }), h
        }
    }
    class t3 extends t2 {
        load(e, t, r, a) {
            let n = this.prepareQuadRenderer(),
                i = new tK.FileLoader(this._internalLoadingManager);
            return i.setResponseType("arraybuffer"), i.setRequestHeader(this.requestHeader), i.setPath(this.path), i.setWithCredentials(this.withCredentials), this.manager.itemStart(e), i.load(e, async r => {
                let i, o, s;
                if ("string" == typeof r) throw Error("Invalid buffer, received [string], was expecting [ArrayBuffer]");
                let l = new Uint8Array(r);
                try {
                    let e = await tY(l);
                    i = e.sdr, o = e.gainMap, s = e.metadata
                } catch (t) {
                    if (t instanceof t$ || t instanceof tV) console.warn(`Failure to reconstruct an HDR image from ${e}: Gain map metadata not found in the file, HDRJPGLoader will render the SDR jpeg`), s = {
                        gainMapMin: [0, 0, 0],
                        gainMapMax: [1, 1, 1],
                        gamma: [1, 1, 1],
                        hdrCapacityMin: 0,
                        hdrCapacityMax: 1,
                        offsetHdr: [0, 0, 0],
                        offsetSdr: [0, 0, 0]
                    }, i = l;
                    else throw t
                }
                try {
                    await this.render(n, s, i.buffer, o ? .buffer)
                } catch (t) {
                    this.manager.itemError(e), "function" == typeof a && a(t), n.disposeOnDemandRenderer();
                    return
                }
                "function" == typeof t && t(n), this.manager.itemEnd(e), n.disposeOnDemandRenderer()
            }, r, t => {
                this.manager.itemError(e), "function" == typeof a && a(t)
            }), n
        }
    }
    let t4 = {
            apartment: "lebombo_1k.hdr",
            city: "potsdamer_platz_1k.hdr",
            dawn: "kiara_1_dawn_1k.hdr",
            forest: "forest_slope_1k.hdr",
            lobby: "st_fagans_interior_1k.hdr",
            night: "dikhololo_night_1k.hdr",
            park: "rooitou_park_1k.hdr",
            studio: "studio_small_03_1k.hdr",
            sunset: "venice_sunset_1k.hdr",
            warehouse: "empty_warehouse_01_1k.hdr"
        },
        t6 = "https://raw.githack.com/pmndrs/drei-assets/456060a26bbeb8fdf79326f224b6d99b8bcce736/hdri/",
        t8 = ["/px.png", "/nx.png", "/py.png", "/ny.png", "/pz.png", "/nz.png"];

    function t7({
        files: e = t8,
        path: t = "",
        preset: n,
        colorSpace: i,
        extensions: o
    } = {}) {
        n && (rt(n), e = t4[n], t = t6);
        let s = Array.isArray(e),
            {
                extension: l,
                isCubemap: u
            } = rr(e),
            f = ra(l);
        if (!f) throw Error("useEnvironment: Unrecognized file extension: " + e);
        let c = (0, q.useThree)(e => e.gl);
        (0, h.useLayoutEffect)(() => {
            ("webp" === l || "jpg" === l || "jpeg" === l) && c.domElement.addEventListener("webglcontextlost", function() {
                r.G.clear(f, s ? [e] : e)
            }, {
                once: !0
            })
        }, [e, c.domElement]);
        let d = (0, r.G)(f, s ? [e] : e, e => {
                ("webp" === l || "jpg" === l || "jpeg" === l) && e.setRenderer(c), null == e.setPath || e.setPath(t), o && o(e)
            }),
            p = s ? d[0] : d;
        if ("jpg" === l || "jpeg" === l || "webp" === l) {
            var m;
            p = null == (m = p.renderTarget) ? void 0 : m.texture
        }
        return p.mapping = u ? a.CubeReflectionMapping : a.EquirectangularReflectionMapping, p.colorSpace = null != i ? i : u ? "srgb" : "srgb-linear", p
    }
    let t9 = {
        files: t8,
        path: "",
        preset: void 0,
        extensions: void 0
    };
    t7.preload = e => {
        let t = { ...t9,
                ...e
            },
            {
                files: a,
                path: n = ""
            } = t,
            {
                preset: i,
                extensions: o
            } = t;
        i && (rt(i), a = t4[i], n = t6);
        let {
            extension: s
        } = rr(a);
        if ("webp" === s || "jpg" === s || "jpeg" === s) throw Error("useEnvironment: Preloading gainmaps is not supported");
        let l = ra(s);
        if (!l) throw Error("useEnvironment: Unrecognized file extension: " + a);
        r.G.preload(l, Array.isArray(a) ? [a] : a, e => {
            null == e.setPath || e.setPath(n), o && o(e)
        })
    };
    let re = {
        files: t8,
        preset: void 0
    };

    function rt(e) {
        if (!(e in t4)) throw Error("Preset must be one of: " + Object.keys(t4).join(", "))
    }

    function rr(e) {
        var t;
        let r = Array.isArray(e) && 6 === e.length,
            a = Array.isArray(e) && 3 === e.length && e.some(e => e.endsWith("json")),
            n = Array.isArray(e) ? e[0] : e;
        return {
            extension: r ? "cube" : a ? "webp" : n.startsWith("data:application/exr") ? "exr" : n.startsWith("data:application/hdr") ? "hdr" : n.startsWith("data:image/jpeg") ? "jpg" : null == (t = n.split(".").pop()) || null == (t = t.split("?")) || null == (t = t.shift()) ? void 0 : t.toLowerCase(),
            isCubemap: r,
            isGainmap: a
        }
    }

    function ra(e) {
        return "cube" === e ? a.CubeTextureLoader : "hdr" === e ? er : "exr" === e ? tH : "jpg" === e || "jpeg" === e ? t3 : "webp" === e ? t5 : null
    }

    function rn(e, t, r, a, n = {}) {
        var i, o, s, l, h;
        let u;
        n = {
            backgroundBlurriness: 0,
            backgroundIntensity: 1,
            backgroundRotation: [0, 0, 0],
            environmentIntensity: 1,
            environmentRotation: [0, 0, 0],
            ...n
        };
        let f = (u = h = t || r).current && u.current.isScene ? h.current : h,
            c = f.background,
            d = f.environment,
            p = {
                backgroundBlurriness: f.backgroundBlurriness,
                backgroundIntensity: f.backgroundIntensity,
                backgroundRotation: null != (i = null == (o = f.backgroundRotation) || null == o.clone ? void 0 : o.clone()) ? i : [0, 0, 0],
                environmentIntensity: f.environmentIntensity,
                environmentRotation: null != (s = null == (l = f.environmentRotation) || null == l.clone ? void 0 : l.clone()) ? s : [0, 0, 0]
            };
        return "only" !== e && (f.environment = a), e && (f.background = a), (0, Y.s)(f, n), () => {
            "only" !== e && (f.environment = d), e && (f.background = c), (0, Y.s)(f, p)
        }
    }

    function ri({
        scene: e,
        background: t = !1,
        map: r,
        ...a
    }) {
        let n = (0, q.useThree)(e => e.scene);
        return h.useLayoutEffect(() => {
            if (r) return rn(t, e, n, r, a)
        }), null
    }

    function ro({
        background: e = !1,
        scene: t,
        blur: r,
        backgroundBlurriness: a,
        backgroundIntensity: n,
        backgroundRotation: i,
        environmentIntensity: o,
        environmentRotation: s,
        ...l
    }) {
        let u = t7(l),
            f = (0, q.useThree)(e => e.scene);
        return h.useLayoutEffect(() => rn(e, t, f, u, {
            backgroundBlurriness: null != r ? r : a,
            backgroundIntensity: n,
            backgroundRotation: i,
            environmentIntensity: o,
            environmentRotation: s
        })), h.useEffect(() => () => {
            u.dispose()
        }, [u]), null
    }

    function rs({
        children: e,
        near: t = .1,
        far: r = 1e3,
        resolution: n = 256,
        frames: i = 1,
        map: o,
        background: s = !1,
        blur: l,
        backgroundBlurriness: f,
        backgroundIntensity: c,
        backgroundRotation: d,
        environmentIntensity: p,
        environmentRotation: m,
        scene: g,
        files: v,
        path: y,
        preset: w,
        extensions: b
    }) {
        let x = (0, q.useThree)(e => e.gl),
            M = (0, q.useThree)(e => e.scene),
            E = h.useRef(null),
            [T] = h.useState(() => new a.Scene),
            S = h.useMemo(() => {
                let e = new Q.WebGLCubeRenderTarget(n);
                return e.texture.type = a.HalfFloatType, e
            }, [n]);
        h.useEffect(() => () => {
            S.dispose()
        }, [S]), h.useLayoutEffect(() => {
            if (1 === i) {
                let e = x.autoClear;
                x.autoClear = !0, E.current.update(x, T), x.autoClear = e
            }
            return rn(s, g, M, S.texture, {
                backgroundBlurriness: null != l ? l : f,
                backgroundIntensity: c,
                backgroundRotation: d,
                environmentIntensity: p,
                environmentRotation: m
            })
        }, [e, T, S.texture, g, M, s, i, x]);
        let A = 1;
        return (0, u.useFrame)(() => {
            if (i === 1 / 0 || A < i) {
                let e = x.autoClear;
                x.autoClear = !0, E.current.update(x, T), x.autoClear = e, A++
            }
        }), h.createElement(h.Fragment, null, (0, X.o)(h.createElement(h.Fragment, null, e, h.createElement("cubeCamera", {
            ref: E,
            args: [t, r, S]
        }), v || w ? h.createElement(ro, {
            background: !0,
            files: v,
            preset: w,
            path: y,
            extensions: b
        }) : o ? h.createElement(ri, {
            background: !0,
            map: o,
            extensions: b
        }) : null), T))
    }

    function rl(e) {
        var t, r, a, n;
        let i = t7(e),
            o = e.map || i;
        h.useMemo(() => (0, Z.e)({
            GroundProjectedEnvImpl: ee
        }), []), h.useEffect(() => () => {
            i.dispose()
        }, [i]);
        let s = h.useMemo(() => [o], [o]),
            l = null == (t = e.ground) ? void 0 : t.height,
            u = null == (r = e.ground) ? void 0 : r.radius,
            f = null != (a = null == (n = e.ground) ? void 0 : n.scale) ? a : 1e3;
        return h.createElement(h.Fragment, null, h.createElement(ri, (0, $.default)({}, e, {
            map: o
        })), h.createElement("groundProjectedEnvImpl", {
            args: s,
            scale: f,
            height: l,
            radius: u
        }))
    }

    function rh(e) {
        return e.ground ? h.createElement(rl, e) : e.map ? h.createElement(ri, e) : e.children ? h.createElement(rs, e) : h.createElement(ro, e)
    }
    t7.clear = e => {
        let t = { ...re,
                ...e
            },
            {
                files: a
            } = t,
            {
                preset: n
            } = t;
        n && (rt(n), a = t4[n]);
        let {
            extension: i
        } = rr(a), o = ra(i);
        if (!o) throw Error("useEnvironment: Unrecognized file extension: " + a);
        r.G.clear(o, Array.isArray(a) ? [a] : a)
    };
    var Y = r;
    let ru = h.forwardRef(({
        light: e,
        args: t,
        map: r,
        toneMapped: n = !1,
        color: i = "white",
        form: o = "rect",
        intensity: s = 1,
        scale: l = 1,
        target: u = [0, 0, 0],
        children: f,
        ...c
    }, d) => {
        let p = h.useRef(null);
        return h.useImperativeHandle(d, () => p.current, []), h.useLayoutEffect(() => {
            f || c.material || ((0, Y.s)(p.current.material, {
                color: i
            }), p.current.material.color.multiplyScalar(s))
        }, [i, s, f, c.material]), h.useLayoutEffect(() => {
            c.rotation || p.current.quaternion.identity(), u && !c.rotation && ("boolean" == typeof u ? p.current.lookAt(0, 0, 0) : p.current.lookAt(Array.isArray(u) ? new a.Vector3(...u) : u))
        }, [u, c.rotation]), l = Array.isArray(l) && 2 === l.length ? [l[0], l[1], 1] : l, h.createElement("mesh", (0, $.default)({
            ref: p,
            scale: l
        }, c), "circle" === o ? h.createElement("ringGeometry", {
            args: t || [0, .5, 64]
        }) : "ring" === o ? h.createElement("ringGeometry", {
            args: t || [.25, .5, 64]
        }) : "rect" === o || "plane" === o ? h.createElement("planeGeometry", {
            args: t || [1, 1]
        }) : "box" === o ? h.createElement("boxGeometry", {
            args: t || [1, 1, 1]
        }) : h.createElement(o, {
            args: t
        }), f || h.createElement("meshBasicMaterial", {
            toneMapped: n,
            map: r,
            side: a.DoubleSide
        }), e && h.createElement("pointLight", (0, $.default)({
            castShadow: !0
        }, e)))
    });
    e.s(["default", 0, function() {
        return (0, s.jsxs)(s.Fragment, {
            children: [(0, s.jsx)("ambientLight", {
                intensity: .28
            }), (0, s.jsx)("directionalLight", {
                position: [-3, 4, 6],
                intensity: 1.35
            }), (0, s.jsx)("directionalLight", {
                position: [4, -2, 5],
                intensity: .3,
                color: "#ffe2b8"
            }), (0, s.jsxs)(rh, {
                resolution: 256,
                frames: 1,
                environmentIntensity: .5,
                children: [(0, s.jsx)("color", {
                    attach: "background",
                    args: ["#26272a"]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: .5,
                    position: [-4.4, 4.4, 11],
                    "rotation-z": .55,
                    scale: [9, 9, 1]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: 2,
                    position: [0, 4, 7],
                    scale: [14, 1.4, 1]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: 1.6,
                    position: [-9, 0, .8],
                    scale: [.8, 12, 1]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: 1.6,
                    position: [9, 0, .8],
                    scale: [.8, 12, 1]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: 1.4,
                    position: [0, 9, .8],
                    scale: [16, .8, 1]
                }), (0, s.jsx)(ru, {
                    form: "rect",
                    intensity: .8,
                    color: "#ffd9a6",
                    position: [0, -9, .8],
                    scale: [16, .8, 1]
                })]
            })]
        })
    }], 318615)
}]);