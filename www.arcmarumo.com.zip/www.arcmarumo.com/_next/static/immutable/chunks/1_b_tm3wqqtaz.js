(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 302355, e => {
    "use strict";
    var t = e.i(247167),
        n = e.i(271645),
        r = e.i(618566);

    function i() {
        return "u" > typeof window
    }

    function o() {
        return "production"
    }

    function a() {
        return "development" === ((i() ? window.vam : o()) || "production")
    }

    function s(e) {
        return RegExp(`/${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?=[/?#]|$)`)
    }

    function c(e) {
        return e.startsWith("http://") || e.startsWith("https://") || e.startsWith("/") ? e : `/${e}`
    }

    function d(e) {
        return (0, n.useEffect)(() => {
            var t;
            e.beforeSend && (null == (t = window.va) || t.call(window, "beforeSend", e.beforeSend))
        }, [e.beforeSend]), (0, n.useEffect)(() => {
            ! function(e = {
                debug: !0
            }, t) {
                var n;
                if (!i()) return;
                let {
                    beforeSend: r,
                    src: s,
                    dataset: d
                } = function(e, t) {
                    var n, r;
                    let i = e;
                    if (t) try {
                        i = { ...null == (n = JSON.parse(t)) ? void 0 : n.analytics,
                            ...e
                        }
                    } catch {}! function(e = "auto") {
                        if ("auto" === e) {
                            window.vam = o();
                            return
                        }
                        window.vam = e
                    }(i.mode);
                    let s = {
                        sdkn: "@vercel/analytics" + (i.framework ? `/${i.framework}` : ""),
                        sdkv: "2.0.1"
                    };
                    return i.disableAutoTrack && (s.disableAutoTrack = "1"), i.viewEndpoint && (s.viewEndpoint = c(i.viewEndpoint)), i.eventEndpoint && (s.eventEndpoint = c(i.eventEndpoint)), i.sessionEndpoint && (s.sessionEndpoint = c(i.sessionEndpoint)), a() && !1 === i.debug && (s.debug = "false"), i.dsn && (s.dsn = i.dsn), i.endpoint ? s.endpoint = i.endpoint : i.basePath && (s.endpoint = c(`${i.basePath}/insights`)), {
                        beforeSend: i.beforeSend,
                        src: (r = i).scriptSrc ? c(r.scriptSrc) : a() ? "https://va.vercel-scripts.com/v1/script.debug.js" : r.basePath ? c(`${r.basePath}/insights/script.js`) : "/_vercel/insights/script.js",
                        dataset: s
                    }
                }(e, t);
                if (window.va || (window.va = function(...e) {
                        window.vaq || (window.vaq = []), window.vaq.push(e)
                    }), r && (null == (n = window.va) || n.call(window, "beforeSend", r)), document.head.querySelector(`script[src*="${s}"]`)) return;
                let u = document.createElement("script");
                for (let [e, t] of (u.src = s, Object.entries(d))) u.dataset[e] = t;
                u.defer = !0, u.onerror = () => {
                    let e = a() ? "Please check if any ad blockers are enabled and try again." : "Be sure to enable Web Analytics for your project and deploy again. See https://vercel.com/docs/analytics/quickstart for more information.";
                    console.log(`[Vercel Web Analytics] Failed to load script from ${s}. ${e}`)
                }, document.head.appendChild(u)
            }({
                framework: e.framework || "react",
                basePath: e.basePath ? ? function() {
                    if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.REACT_APP_VERCEL_OBSERVABILITY_BASEPATH
                }(),
                ...void 0 !== e.route && {
                    disableAutoTrack: !0
                },
                ...e
            }, e.configString ? ? function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.REACT_APP_VERCEL_OBSERVABILITY_CLIENT_CONFIG
            }())
        }, []), (0, n.useEffect)(() => {
            e.route && e.path && function({
                route: e,
                path: t
            }) {
                var n;
                null == (n = window.va) || n.call(window, "pageview", {
                    route: e,
                    path: t
                })
            }({
                route: e.route,
                path: e.path
            })
        }, [e.route, e.path]), null
    }

    function u(e) {
        let i, o, a, {
            route: c,
            path: u
        } = (i = (0, r.useParams)(), o = (0, r.useSearchParams)(), a = (0, r.usePathname)(), i ? {
            route: function(e, t) {
                if (!e || !t) return e;
                let n = e;
                try {
                    let e = Object.entries(t);
                    for (let [t, r] of e)
                        if (!Array.isArray(r)) {
                            let e = s(r);
                            e.test(n) && (n = n.replace(e, `/[${t}]`))
                        }
                    for (let [t, r] of e)
                        if (Array.isArray(r)) {
                            let e = s(r.join("/"));
                            e.test(n) && (n = n.replace(e, `/[...${t}]`))
                        }
                    return n
                } catch {
                    return e
                }
            }(a, Object.keys(i).length ? i : Object.fromEntries(o.entries())),
            path: a
        } : {
            route: null,
            path: a
        });
        return n.default.createElement(d, {
            path: u,
            route: c,
            ...e,
            basePath: function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.NEXT_PUBLIC_VERCEL_OBSERVABILITY_BASEPATH
            }(),
            configString: function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return '{"analytics":{"scriptSrc":"aafe13344bef70fc/script.js","viewEndpoint":"aafe13344bef70fc/view","eventEndpoint":"aafe13344bef70fc/event","sessionEndpoint":"aafe13344bef70fc/session"},"speedInsights":{"scriptSrc":"5d18c82ce29be22e/script.js","endpoint":"5d18c82ce29be22e/vitals"}}'
            }(),
            framework: "next"
        })
    }
    e.s(["Analytics", 0, function(e) {
        return n.default.createElement(n.Suspense, {
            fallback: null
        }, n.default.createElement(u, { ...e
        }))
    }])
}, 748646, function(e) {
    e.n(e.i(302355))
}]);