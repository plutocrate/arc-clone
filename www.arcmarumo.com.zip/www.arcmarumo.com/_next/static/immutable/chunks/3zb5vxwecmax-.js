(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 247015, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(770703),
        n = e.i(271645),
        l = e.i(926236);
    let a = (0, r.default)(() => e.A(678638).then(e => e.Analytics), {
            loadableGenerated: {
                modules: [748646]
            },
            ssr: !1
        }),
        o = (0, r.default)(() => e.A(967141).then(e => e.SpeedInsights), {
            loadableGenerated: {
                modules: [255343]
            },
            ssr: !1
        });
    e.s(["default", 0, function() {
        let [e, r] = (0, n.useState)(!1);
        return (0, n.useEffect)(() => (0, l.afterFirstPaint)(() => r(!0)), []), e ? (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)(a, {}), (0, t.jsx)(o, {})]
        }) : null
    }])
}, 744218, e => {
    "use strict";
    var t = e.i(271645),
        r = e.i(618566),
        n = e.i(172311);
    let l = "",
        a = !1,
        o = !1;
    e.s(["default", 0, function() {
        let e = (0, r.useRouter)(),
            u = (0, r.usePathname)();
        return (0, t.useLayoutEffect)(() => {
            l && l !== u && (o = !0), l = u, (0, n.pageArrived)()
        }, [u]), (0, t.useEffect)(() => {
            let e = e => {
                if (a || location.pathname === l || !(0, n.canTransition)()) return;
                e.stopImmediatePropagation();
                let t = e.state;
                (0, n.transitionTo)(() => {
                    a = !0, window.dispatchEvent(new PopStateEvent("popstate", {
                        state: t
                    })), a = !1
                })
            };
            return window.addEventListener("popstate", e, !0), () => window.removeEventListener("popstate", e, !0)
        }, []), (0, t.useEffect)(() => {
            let t = t => {
                if (t.defaultPrevented || 0 !== t.button || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey) return;
                let r = t.target instanceof Element ? t.target.closest("a") : null;
                if (!r || "_blank" === r.target || r.hasAttribute("download")) return;
                if (r.hasAttribute("data-back") && o) {
                    t.preventDefault(), t.stopPropagation(), history.back();
                    return
                }
                let l = new URL(r.href, location.href);
                l.origin !== location.origin || l.pathname.startsWith("/studio") || l.pathname !== location.pathname && (t.preventDefault(), t.stopPropagation(), (0, n.transitionTo)(() => e.push(l.pathname + l.search + l.hash)))
            };
            return document.addEventListener("click", t, !0), () => document.removeEventListener("click", t, !0)
        }, [e]), null
    }])
}, 926236, e => {
    "use strict";
    e.s(["afterFirstPaint", 0, function(e, t = 4e3) {
        let r = !1,
            n = 0,
            l = null,
            a = () => {
                r || (r = !0, l ? .disconnect(), window.clearTimeout(u), e())
            },
            o = () => {
                n = "function" == typeof window.requestIdleCallback ? window.requestIdleCallback(a, {
                    timeout: 300
                }) : window.setTimeout(a, 50)
            },
            u = window.setTimeout(a, t);
        return performance.getEntriesByType("paint").some(e => "first-contentful-paint" === e.name) ? o() : PerformanceObserver.supportedEntryTypes ? .includes("paint") ? (l = new PerformanceObserver(e => {
            e.getEntries().some(e => "first-contentful-paint" === e.name) && (l ? .disconnect(), o())
        })).observe({
            type: "paint",
            buffered: !0
        }) : o(), () => {
            r = !0, l ? .disconnect(), window.clearTimeout(u), "function" == typeof window.cancelIdleCallback && window.cancelIdleCallback(n), window.clearTimeout(n)
        }
    }])
}, 172311, e => {
    "use strict";
    var t = e.i(271645);
    let r = null,
        n = !1,
        l = new Set,
        a = e => {
            n = e, l.forEach(e => e())
        };

    function o() {
        return !!document.startViewTransition && !n && !window.matchMedia("(prefers-reduced-motion: reduce)").matches
    }

    function u() {
        r ? .(), r = null
    }
    e.s(["canTransition", 0, o, "pageArrived", 0, u, "transitionTo", 0, function(e) {
        ! function(e) {
            if (!o()) return e();
            a(!0);
            let t = document.startViewTransition(e);
            t.ready.catch(() => {}), t.finished.finally(() => a(!1))
        }(() => new Promise(t => {
            r = t, e(), window.setTimeout(u, 3e3)
        }))
    }, "useTransitionRunning", 0, function() {
        return (0, t.useSyncExternalStore)(e => (l.add(e), () => void l.delete(e)), () => n, () => !1)
    }])
}, 678638, e => {
    e.v(t => Promise.all(["static/immutable/chunks/1_b_tm3wqqtaz.js"].map(t => e.l(t))).then(() => t(748646)))
}, 967141, e => {
    e.v(t => Promise.all(["static/immutable/chunks/134kwktq953r0.js"].map(t => e.l(t))).then(() => t(255343)))
}, 728298, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useRouterBFCache", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(271645);

    function l(e, t, r) {
        let [l, a] = (0, n.useState)(() => ({
            tree: e,
            cacheNode: t,
            stateKey: r,
            next: null
        }));
        if (l.tree === e) return l;
        let o = {
                tree: e,
                cacheNode: t,
                stateKey: r,
                next: null
            },
            u = 1,
            i = l,
            s = o;
        for (; null !== i && u < 1;) {
            if (i.stateKey === r) {
                s.next = i.next;
                break
            } {
                u++;
                let e = {
                    tree: i.tree,
                    cacheNode: i.cacheNode,
                    stateKey: i.stateKey,
                    next: null
                };
                s.next = e, s = e
            }
            i = i.next
        }
        return a(o), o
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 347257, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ClientPageRoot", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(843476),
        l = e.r(8372),
        a = e.r(271645),
        o = e.r(33906),
        u = e.r(261994),
        i = e.r(15783);

    function s({
        Component: e,
        serverProvidedParams: t
    }) {
        let r, d;
        if (null !== t) r = t.searchParams, d = t.params;
        else {
            let e = (0, a.use)(l.LayoutRouterContext);
            d = null !== e ? e.parentParams : {}, r = (0, o.urlSearchParamsToParsedUrlQuery)((0, a.use)(u.SearchParamsContext))
        }
        let c = (0, i.createClientSearchParams)(r),
            f = (0, i.createClientParams)(d);
        return (0, n.jsx)(e, {
            params: f,
            searchParams: c
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 92825, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ClientSegmentRoot", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(843476),
        l = e.r(8372),
        a = e.r(271645),
        o = e.r(15783);

    function u({
        Component: e,
        slots: t,
        serverProvidedParams: r
    }) {
        let i;
        if (null !== r) i = r.params;
        else {
            let e = (0, a.use)(l.LayoutRouterContext);
            i = null !== e ? e.parentParams : {}
        }
        let s = (0, o.createClientParams)(i);
        return (0, n.jsx)(e, { ...t,
            params: s
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 768017, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function() {
            return d
        }
    });
    let n = e.r(190809),
        l = e.r(843476),
        a = n._(e.r(271645)),
        o = e.r(590373),
        u = e.r(754394),
        i = e.r(8372);
    class s extends a.default.Component {
        constructor(e) {
            super(e), this.state = {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            }
        }
        componentDidCatch() {}
        static getDerivedStateFromError(e) {
            if ((0, u.isHTTPAccessFallbackError)(e)) return {
                triggeredStatus: (0, u.getAccessFallbackHTTPStatus)(e)
            };
            throw e
        }
        static getDerivedStateFromProps(e, t) {
            return e.pathname !== t.previousPathname && t.triggeredStatus ? {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            } : {
                triggeredStatus: t.triggeredStatus,
                previousPathname: e.pathname
            }
        }
        render() {
            let {
                notFound: e,
                forbidden: t,
                unauthorized: r,
                children: n
            } = this.props, {
                triggeredStatus: a
            } = this.state, o = {
                [u.HTTPAccessErrorStatus.NOT_FOUND]: e,
                [u.HTTPAccessErrorStatus.FORBIDDEN]: t,
                [u.HTTPAccessErrorStatus.UNAUTHORIZED]: r
            };
            if (a) {
                let i = a === u.HTTPAccessErrorStatus.NOT_FOUND && e,
                    s = a === u.HTTPAccessErrorStatus.FORBIDDEN && t,
                    d = a === u.HTTPAccessErrorStatus.UNAUTHORIZED && r;
                return i || s || d ? (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("meta", {
                        name: "robots",
                        content: "noindex"
                    }), !1, o[a]]
                }) : n
            }
            return n
        }
    }

    function d({
        notFound: e,
        forbidden: t,
        unauthorized: r,
        children: n
    }) {
        let u = (0, o.useUntrackedPathname)(),
            c = (0, a.useContext)(i.MissingSlotContext);
        return e || t || r ? (0, l.jsx)(s, {
            pathname: u,
            notFound: e,
            forbidden: t,
            unauthorized: r,
            missingSlots: c,
            children: n
        }) : (0, l.jsx)(l.Fragment, {
            children: n
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 722976, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        InstantValidationBoundaryContext: function() {
            return a
        },
        PlaceValidationBoundaryBelowThisLevel: function() {
            return o
        },
        RenderValidationBoundaryAtThisLevel: function() {
            return u
        },
        SlotMarker: function() {
            return i
        }
    };
    for (var l in n) Object.defineProperty(r, l, {
        enumerable: !0,
        get: n[l]
    });
    let a = null,
        o = null,
        u = null,
        i = null;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 877694, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        InstantValidationBoundaryContext: function() {
            return a.InstantValidationBoundaryContext
        },
        PlaceValidationBoundaryBelowThisLevel: function() {
            return a.PlaceValidationBoundaryBelowThisLevel
        },
        RenderValidationBoundaryAtThisLevel: function() {
            return a.RenderValidationBoundaryAtThisLevel
        },
        SlotMarker: function() {
            return a.SlotMarker
        }
    };
    for (var l in n) Object.defineProperty(r, l, {
        enumerable: !0,
        get: n[l]
    });
    let a = e.r(722976);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 339756, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        LoadingBoundaryProvider: function() {
            return T
        },
        default: function() {
            return w
        }
    };
    for (var l in n) Object.defineProperty(r, l, {
        enumerable: !0,
        get: n[l]
    });
    let a = e.r(555682),
        o = e.r(190809),
        u = e.r(843476),
        i = o._(e.r(271645)),
        s = a._(e.r(174080)),
        d = e.r(8372),
        c = e.r(201244),
        f = e.r(972383),
        p = e.r(491915),
        m = e.r(358442),
        b = e.r(768017);
    e.r(877694);
    let y = e.r(270725),
        h = e.r(728298);
    e.r(174180);
    let _ = e.r(261994),
        P = e.r(33906),
        g = e.r(595871);
    s.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function v(e, t, r) {
        let n = e.getClientRects();
        if (0 === n.length) return 0;
        let l = 1 / 0;
        for (let e = 0; e < n.length; e++) {
            let t = n[e];
            t.top < l && (l = t.top)
        }
        return l >= r() && l <= t ? 1 : 2
    }
    i.default.Component;
    let j = function(e) {
        let t = i.default.useRef(null);
        return (0, i.useLayoutEffect)(() => {
            let {
                focusAndScrollRef: r,
                cacheNode: n
            } = e, l = r.forceScroll ? r.scrollRef : n.scrollRef;
            if (null === l || !l.current) return;
            let a = null,
                o = r.hashFragment;
            if (o) {
                var u;
                if (null === (a = "top" === (u = o) ? document.body : document.getElementById(u) ? ? document.getElementsByName(u)[0] ? ? null)) {
                    l.current = !1, r.onlyHashChange = !1, r.hashFragment = null;
                    return
                }
            } else a = t.current;
            if (null === a) return;
            let i = !1;
            (0, p.disableSmoothScrollDuringRouteTransition)(() => {
                let e = document.documentElement,
                    t = null,
                    r = null,
                    n = null,
                    u = () => {
                        var r, l;
                        let a, o;
                        return null === n && (r = e, l = t, n = !Number.isFinite(o = Number.parseFloat(a = getComputedStyle(r).scrollPaddingTop)) || o < 0 ? 0 : a.endsWith("px") ? o : a.endsWith("%") ? o / 100 * l : 0), n
                    };
                (o || (t = e.clientHeight, 0 !== (r = v(a, t, u)))) && ((i = !0, l.current = !1, o) ? a.scrollIntoView() : 1 !== r && (e.scrollTop = 0, 2 === v(a, t, u) && a.scrollIntoView()))
            }, {
                dontForceLayout: !0,
                onlyHashChange: r.onlyHashChange
            }), i && (r.onlyHashChange = !1, r.hashFragment = null)
        }, void 0), (0, u.jsx)(i.Fragment, {
            ref: t,
            children: e.children
        })
    };

    function O({
        children: e,
        cacheNode: t
    }) {
        let r = (0, i.useContext)(d.GlobalLayoutRouterContext);
        if (!r) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        return (0, u.jsx)(j, {
            focusAndScrollRef: r.focusAndScrollRef,
            cacheNode: t,
            children: e
        })
    }

    function x({
        tree: e,
        segmentPath: t,
        debugNameContext: r,
        cacheNode: n,
        params: l,
        url: a,
        isActive: o
    }) {
        let s, f = (0, i.useContext)(d.GlobalLayoutRouterContext);
        if ((0, i.useContext)(_.NavigationPromisesContext), !f) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        let p = null !== n ? n : (0, i.use)(c.unresolvedThenable),
            m = null !== p.prefetchRsc ? p.prefetchRsc : p.rsc,
            b = (0, i.useDeferredValue)(p.rsc, m);
        if ((0, g.isDeferredRsc)(b)) {
            let e = (0, i.use)(b);
            null === e && (0, i.use)(c.unresolvedThenable), s = e
        } else null === b && (0, i.use)(c.unresolvedThenable), s = b;
        let y = s;
        return (0, u.jsx)(d.LayoutRouterContext.Provider, {
            value: {
                parentTree: e,
                parentCacheNode: p,
                parentSegmentPath: t,
                parentParams: l,
                parentLoadingData: null,
                debugNameContext: r,
                url: a,
                isActive: o
            },
            children: y
        })
    }

    function T({
        loading: e,
        children: t
    }) {
        let r = (0, i.use)(d.LayoutRouterContext);
        return null === r ? t : (0, u.jsx)(d.LayoutRouterContext.Provider, {
            value: {
                parentTree: r.parentTree,
                parentCacheNode: r.parentCacheNode,
                parentSegmentPath: r.parentSegmentPath,
                parentParams: r.parentParams,
                parentLoadingData: e,
                debugNameContext: r.debugNameContext,
                url: r.url,
                isActive: r.isActive
            },
            children: t
        })
    }

    function C({
        name: e,
        loading: t,
        children: r
    }) {
        if (null !== t) {
            let n = t[0],
                l = t[1],
                a = t[2];
            return (0, u.jsx)(i.Suspense, {
                name: e,
                fallback: (0, u.jsxs)(u.Fragment, {
                    children: [l, a, n]
                }),
                children: r
            })
        }
        return (0, u.jsx)(u.Fragment, {
            children: r
        })
    }

    function w({
        parallelRouterKey: e,
        error: t,
        errorStyles: r,
        errorScripts: n,
        templateStyles: l,
        templateScripts: a,
        template: o,
        notFound: s,
        forbidden: p,
        unauthorized: _,
        segmentViewBoundaries: g
    }) {
        let v = (0, i.useContext)(d.LayoutRouterContext);
        if (!v) throw Object.defineProperty(Error("invariant expected layout router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E56",
            enumerable: !1,
            configurable: !0
        });
        let {
            parentTree: j,
            parentCacheNode: T,
            parentSegmentPath: R,
            parentParams: S,
            parentLoadingData: E,
            url: M,
            isActive: A,
            debugNameContext: F
        } = v, N = j[0], L = null === R ? [e] : R.concat([N, e]), k = j[1][e], B = T.slots;
        (void 0 === k || null === B) && (0, i.use)(c.unresolvedThenable);
        let D = k[0],
            I = B[e] ? ? null,
            H = (0, y.createRouterCacheKey)(D, !0),
            U = (0, h.useRouterBFCache)(k, I, H),
            V = [];
        do {
            let e = U.tree,
                i = U.cacheNode,
                c = U.stateKey,
                y = e[0],
                h = S;
            if (Array.isArray(y)) {
                let e = y[0],
                    t = y[1],
                    r = y[2],
                    n = (0, P.getParamValueFromCacheKey)(t, r);
                null !== n && (h = { ...S,
                    [e]: n
                })
            }
            let g = function(e) {
                    if ("/" === e) return "/";
                    if ("string" == typeof e)
                        if ("(__SLOT__)" === e) return;
                        else return e + "/";
                    return e[1] + "/"
                }(y),
                v = g ? ? F,
                j = void 0 === g ? void 0 : F,
                T = (0, u.jsxs)(O, {
                    cacheNode: i,
                    children: [(0, u.jsx)(f.ErrorBoundary, {
                        errorComponent: t,
                        errorStyles: r,
                        errorScripts: n,
                        children: (0, u.jsx)(C, {
                            name: j,
                            loading: E,
                            children: (0, u.jsx)(b.HTTPAccessFallbackBoundary, {
                                notFound: s,
                                forbidden: p,
                                unauthorized: _,
                                children: (0, u.jsxs)(m.RedirectBoundary, {
                                    children: [(0, u.jsx)(x, {
                                        url: M,
                                        tree: e,
                                        params: h,
                                        cacheNode: i,
                                        segmentPath: L,
                                        debugNameContext: v,
                                        isActive: A && c === H
                                    }), null]
                                })
                            })
                        })
                    }), null]
                }),
                w = (0, u.jsxs)(d.TemplateContext.Provider, {
                    value: T,
                    children: [l, a, o]
                }, c);
            V.push(w), U = U.next
        } while (null !== U) return V
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 837457, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(190809),
        l = e.r(843476),
        a = n._(e.r(271645)),
        o = e.r(8372);

    function u() {
        let e = (0, a.useContext)(o.TemplateContext);
        return (0, l.jsx)(l.Fragment, {
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 806831, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = new WeakMap;

    function l(e) {
        let t = n.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return n.set(e, r), r
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 797689, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(806831).createRenderParamsFromClient;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 793504, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = new WeakMap;

    function l(e) {
        let t = n.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return n.set(e, r), r
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 266996, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(793504).createRenderSearchParamsFromClient;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 15783, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        createClientParams: function() {
            return a.createRenderParamsFromClient
        },
        createClientSearchParams: function() {
            return o.createRenderSearchParamsFromClient
        }
    };
    for (var l in n) Object.defineProperty(r, l, {
        enumerable: !0,
        get: n[l]
    });
    let a = e.r(797689),
        o = e.r(266996);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 27201, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "IconMark", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(843476),
        l = () => "u" > typeof window ? null : (0, n.jsx)("meta", {
            name: "«nxt-icon»"
        })
}, 90317, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        bindSnapshot: function() {
            return s
        },
        createAsyncLocalStorage: function() {
            return i
        },
        createSnapshot: function() {
            return d
        }
    };
    for (var l in n) Object.defineProperty(r, l, {
        enumerable: !0,
        get: n[l]
    });
    let a = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: !1,
        configurable: !0
    });
    class o {
        disable() {
            throw a
        }
        getStore() {}
        run() {
            throw a
        }
        exit() {
            throw a
        }
        enterWith() {
            throw a
        }
        static bind(e) {
            return e
        }
    }
    let u = "u" > typeof globalThis && globalThis.AsyncLocalStorage;

    function i() {
        return u ? new u : new o
    }

    function s(e) {
        return u ? u.bind(e) : o.bind(e)
    }

    function d() {
        return u ? u.snapshot() : function(e, ...t) {
            return e(...t)
        }
    }
}, 242344, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 563599, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.workAsyncStorageInstance
        }
    });
    let n = e.r(242344)
}, 309885, (e, t, r) => {
    "use strict";

    function n(e) {
        return e.split("/").map(e => encodeURIComponent(e)).join("/")
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "encodeURIPath", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 667585, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "BailoutToCSR", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(132061);

    function l({
        reason: e,
        children: t
    }) {
        if ("u" < typeof window) throw Object.defineProperty(new n.BailoutToCSRError(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return t
    }
}, 869093, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(843476),
        l = e.r(271645),
        a = e.r(667585),
        o = e.r(652157);

    function u(e) {
        return {
            default: e && "default" in e ? e.default : e
        }
    }
    let i = {
            loader: () => Promise.resolve(u(() => null)),
            loading: null,
            ssr: !0
        },
        s = function(e) {
            let t = { ...i,
                    ...e
                },
                r = (0, l.lazy)(() => t.loader().then(u)),
                s = t.loading;

            function d(e) {
                let u = s ? (0, n.jsx)(s, {
                        isLoading: !0,
                        pastDelay: !0,
                        error: null
                    }) : null,
                    i = !t.ssr || !!t.loading,
                    d = i ? l.Suspense : l.Fragment,
                    c = t.ssr ? (0, n.jsxs)(n.Fragment, {
                        children: ["u" < typeof window ? (0, n.jsx)(o.PreloadChunks, {
                            moduleIds: t.modules
                        }) : null, (0, n.jsx)(r, { ...e
                        })]
                    }) : (0, n.jsx)(a.BailoutToCSR, {
                        reason: "next/dynamic",
                        children: (0, n.jsx)(r, { ...e
                        })
                    });
                return (0, n.jsx)(d, { ...i ? {
                        fallback: u
                    } : {},
                    children: c
                })
            }
            return d.displayName = "LoadableComponent", d
        }
}, 770703, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(555682)._(e.r(869093));

    function l(e, t) {
        let r = {};
        "function" == typeof e && (r.loader = e);
        let l = { ...r,
            ...t
        };
        return (0, n.default)({ ...l,
            modules: l.loadableGenerated ? .modules
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 652157, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "PreloadChunks", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(843476),
        l = e.r(174080),
        a = e.r(563599),
        o = e.r(309885),
        u = e.r(543369);

    function i({
        moduleIds: e
    }) {
        if ("u" > typeof window) return null;
        let t = a.workAsyncStorage.getStore();
        if (void 0 === t) return null;
        let r = [];
        if (t.reactLoadableManifest && e) {
            let n = t.reactLoadableManifest;
            for (let t of e) {
                if (!n[t]) continue;
                let e = n[t].files;
                r.push(...e)
            }
        }
        if (0 === r.length) return null;
        let s = (0, u.getAssetTokenQuery)();
        return (0, n.jsx)(n.Fragment, {
            children: r.map(e => {
                let r = `${t.assetPrefix}/_next/${(0,o.encodeURIPath)(e)}${s}`;
                return e.endsWith(".css") ? (0, n.jsx)("link", {
                    precedence: "dynamic",
                    href: r,
                    rel: "stylesheet",
                    as: "style",
                    nonce: t.nonce
                }, e) : ((0, l.preload)(r, {
                    as: "script",
                    fetchPriority: "low",
                    nonce: t.nonce
                }), null)
            })
        })
    }
}, 491915, (e, t, r) => {
    "use strict";

    function n(e, t = {}) {
        if (t.onlyHashChange) return void e();
        let r = document.documentElement;
        if ("smooth" !== r.dataset.scrollBehavior) return void e();
        let l = r.style.scrollBehavior;
        r.style.scrollBehavior = "auto", t.dontForceLayout || r.getClientRects(), e(), r.style.scrollBehavior = l
    }
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 618566, (e, t, r) => {
    t.exports = e.r(976562)
}]);