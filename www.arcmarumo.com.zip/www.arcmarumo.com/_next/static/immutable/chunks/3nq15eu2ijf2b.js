(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 820453, t => {
    t.v(s => Promise.all(["static/immutable/chunks/09ouw4cybbr0h.js"].map(s => t.l(s))).then(() => s(374914)))
}, 28344, t => {
    t.v(s => Promise.all(["static/immutable/chunks/1gh2i6gkorm5q.js", "static/immutable/chunks/37n3r0zuw47_4.js", "static/immutable/chunks/0qxtffwpvg0u2.js"].map(s => t.l(s))).then(() => s(436345)))
}]);