(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 745850, 495634, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["REVEAL_STAGGER_MS", 0, 70, "useIntro", 0, function(e, t, n = !0) {
        let [i, a] = (0, r.useState)(0), [o, s] = (0, r.useState)(!1), [l, u] = (0, r.useState)(!1), c = (0, r.useRef)(0), d = (0, r.useRef)(!1), f = (0, r.useRef)(t);
        return (0, r.useEffect)(() => {
            f.current = t
        }, [t]), (0, r.useEffect)(() => {
            if (!n) return;
            let e = window.setTimeout(() => s(!0), 220);
            return () => window.clearTimeout(e)
        }, [n]), (0, r.useEffect)(() => {
            if (!o) return;
            let e = window.setTimeout(() => {
                d.current = !0, f.current && u(!0)
            }, 1170);
            return () => window.clearTimeout(e)
        }, [o]), (0, r.useEffect)(() => {
            t && d.current && u(!0)
        }, [t]), (0, r.useEffect)(() => {
            let r = 0,
                n = performance.now(),
                i = () => {
                    let o = performance.now(),
                        s = Math.min(.25, (o - n) / 1e3);
                    n = o;
                    let l = 1 - Math.exp(-7 * s),
                        u = t ? 26 : Math.min(26 * e, 25);
                    c.current += (u - c.current) * l, t && 26 - c.current < .35 && (c.current = 26);
                    let d = Math.max(0, Math.round(c.current));
                    a(e => d > e ? d : e), t && 26 === c.current || (r = requestAnimationFrame(i))
                };
            return r = requestAnimationFrame(i), () => cancelAnimationFrame(r)
        }, [e, t]), {
            year: i,
            textIn: o,
            spiralIn: l
        }
    }], 495634);
    var n = e.i(306257),
        i = e.i(58685);
    let a = "hello@arcmarumo.com";

    function o() {
        return (0, t.jsxs)(t.Fragment, {
            children: ["[", (0, t.jsx)("span", {
                className: "pj-live-arrow",
                "aria-hidden": !0,
                children: "←"
            }), "]"]
        })
    }

    function s(e) {
        return window.addEventListener("bwchange", e), () => window.removeEventListener("bwchange", e)
    }
    e.s(["BwToggle", 0, function() {
        let e = (0, r.useSyncExternalStore)(s, () => document.documentElement.classList.contains("bw"), () => !1);
        return (0, t.jsxs)("button", {
            type: "button",
            role: "switch",
            "aria-checked": e,
            className: "vhs-bw-toggle",
            onClick: () => {
                let t = !e;
                document.documentElement.classList.toggle("bw", t);
                try {
                    localStorage.setItem("bw", t ? "1" : "0")
                } catch {}
                window.dispatchEvent(new Event("bwchange"))
            },
            children: ["B&W ", (0, t.jsxs)("span", {
                "aria-hidden": !0,
                children: ["[", e ? "ON" : "OFF", "]"]
            })]
        })
    }, "CONTACT_EMAIL", 0, a, "ContactLink", 0, function({
        label: e = "Contact",
        copiedLabel: n = "Copied",
        email: i = a,
        arrow: s = !1
    }) {
        let [l, u] = (0, r.useState)(!1);
        return (0, t.jsxs)("a", {
            href: `mailto:${i}`,
            onClick: () => {
                navigator.clipboard ? .writeText(i).then(() => {
                    u(!0), window.setTimeout(() => u(!1), 1600)
                }).catch(() => {})
            },
            "aria-live": "polite",
            children: [l ? n : e, s && (0, t.jsx)(o, {})]
        })
    }, "CrtLines", 0, function() {
        let e = (0, r.useRef)(null);
        return (0, r.useEffect)(() => {
            let t = e.current,
                r = t ? .getContext("2d");
            if (!t || !r) return;
            let i = () => {
                let e = Math.min(2, window.devicePixelRatio || 1),
                    i = t.clientWidth,
                    a = t.clientHeight;
                if (!i || !a) return;
                t.width = Math.round(i * e), t.height = Math.round(a * e), r.setTransform(e, 0, 0, e, 0, 0), r.clearRect(0, 0, i, a);
                let o = i / 2,
                    s = a / 2;
                r.fillStyle = "rgba(0, 0, 0, 0.32)";
                let l = 3 * Math.ceil(a * n.K / 3);
                for (let e = -l; e < a + l; e += 3) {
                    r.beginPath();
                    for (let t = 0; t <= i + 12; t += 12) {
                        let i = (t - o) / o,
                            a = s + (e - s) / (1 + n.K * i * i);
                        0 === t ? r.moveTo(t, a) : r.lineTo(t, a)
                    }
                    for (let t = 12 * Math.ceil((i + 12) / 12); t >= 0; t -= 12) {
                        let i = (t - o) / o;
                        r.lineTo(t, s + (e - s) / (1 + n.K * i * i) + 1)
                    }
                    r.fill()
                }
            };
            i();
            let a = new ResizeObserver(i);
            return a.observe(t), () => a.disconnect()
        }, []), (0, t.jsx)("canvas", {
            ref: e,
            className: "vhs-crt-lines",
            "aria-hidden": !0
        })
    }, "Grain", 0, function({
        fixed: e
    }) {
        return (0, t.jsx)("div", {
            className: `grain${e?" grain-fixed":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("div", {
                className: "grain-layer"
            })
        })
    }, "LinkArrow", 0, o, "Reveal", 0, function({
        on: e,
        i: n = 0,
        className: a,
        children: o
    }) {
        let [s, l] = (0, r.useState)(!1);
        (0, r.useEffect)(() => {
            if (void 0 !== e) return;
            let t = requestAnimationFrame(() => l(!0));
            return () => cancelAnimationFrame(t)
        }, [e]);
        let u = (0, i.useScreenReady)(),
            c = e ? ? (s && u);
        return (0, t.jsx)("span", {
            className: `rv${a?` ${a}`:""}`,
            children: (0, t.jsx)("span", {
                className: `rv-i${c?" rv-in":""}`,
                style: {
                    transitionDelay: `${70*n}ms`
                },
                children: o
            })
        })
    }, "TvGlass", 0, function() {
        return (0, t.jsx)("div", {
            className: "tv-glass",
            "aria-hidden": !0
        })
    }], 745850)
}, 862356, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645),
        n = e.i(942295);
    e.s(["default", 0, function({
        text: e = null,
        idle: i = null
    }) {
        let a = (0, r.useRef)(null),
            [o, s] = (0, r.useState)(null),
            [l, u] = (0, r.useState)(!0),
            c = e ? ? o ? ? (l ? null : i),
            [d, f] = (0, r.useState)(null),
            [h, m] = (0, r.useState)(null);
        c !== h && (m(c), !c || h && d || f(c));
        let p = !!c && !!d && c !== d;
        (0, r.useEffect)(() => {
            if (!p) return;
            let e = window.setTimeout(() => f(c), 200);
            return () => window.clearTimeout(e)
        }, [p, c]);
        let g = (0, r.useRef)(!1);
        return (0, r.useEffect)(() => {
            if (c) {
                g.current = !0;
                return
            }
            let e = window.setTimeout(() => g.current = !1, 300);
            return () => window.clearTimeout(e)
        }, [c]), (0, r.useEffect)(() => {
            let e = a.current ? .closest(".vhs");
            if (!e) return;
            let t = window.matchMedia("(prefers-reduced-motion: reduce)").matches,
                r = {
                    x: 0,
                    y: 0,
                    vx: 0,
                    vy: 0
                },
                i = {
                    x: 0,
                    y: 0
                },
                o = 0,
                l = 0,
                c = () => {
                    let e = a.current;
                    e && (e.style.transform = `translate3d(${r.x.toFixed(1)}px, ${r.y.toFixed(1)}px, 0)`)
                },
                d = e => {
                    let t = Math.min(.05, (e - l) / 1e3);
                    l = e;
                    let a = (0, n.springTo)(r.x, r.vx, i.x, t, 16),
                        s = (0, n.springTo)(r.y, r.vy, i.y, t, 16);
                    r.x = a.x, r.vx = a.v, r.y = s.x, r.vy = s.v;
                    let u = .1 > Math.abs(i.x - r.x) && .1 > Math.abs(i.y - r.y) && Math.abs(r.vx) + Math.abs(r.vy) < 1;
                    u && (r.x = i.x, r.y = i.y, r.vx = r.vy = 0), c(), o = u ? 0 : requestAnimationFrame(d)
                },
                f = n => {
                    let a = "mouse" === n.pointerType ? n.target : null;
                    s(a ? .closest("[data-caption]") ? .getAttribute("data-caption") ? ? null), u(!a || !!a.closest("a, button, [role='dialog'], .vhs-about"));
                    let f = e.getBoundingClientRect();
                    i.x = n.clientX - f.left, i.y = n.clientY - f.top, t || !g.current ? (r.x = i.x, r.y = i.y, r.vx = r.vy = 0, c()) : o || (l = performance.now(), o = requestAnimationFrame(d))
                },
                h = () => {
                    s(null), u(!0)
                };
            return window.addEventListener("pointermove", f), document.documentElement.addEventListener("pointerleave", h), () => {
                window.removeEventListener("pointermove", f), document.documentElement.removeEventListener("pointerleave", h), cancelAnimationFrame(o)
            }
        }, []), (0, t.jsx)("p", {
            ref: a,
            className: `cursor-caption${c&&!p?" is-on":""}${p?" is-swapping":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("span", {
                className: "cursor-caption-i",
                children: d
            })
        })
    }])
}, 111837, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    e.s(["default", 0, function({
        progress: e,
        ready: n,
        onDone: i
    }) {
        let [a, o] = (0, r.useState)(0), [s, l] = (0, r.useState)(!1), u = (0, r.useRef)(0), c = (0, r.useRef)(i);
        return (0, r.useEffect)(() => {
            c.current = i
        }, [i]), (0, r.useEffect)(() => {
            let t = 0,
                r = performance.now(),
                i = () => {
                    let a = performance.now(),
                        s = Math.min(.25, (a - r) / 1e3);
                    r = a;
                    let l = n ? 100 : Math.min(100 * e, 99);
                    u.current += (l - u.current) * (1 - Math.exp(-5 * s)), n && 100 - u.current < .5 && (u.current = 100);
                    let c = Math.floor(u.current);
                    o(e => c > e ? c : e), u.current < 100 && (t = requestAnimationFrame(i))
                };
            return t = requestAnimationFrame(i), () => cancelAnimationFrame(t)
        }, [e, n]), (0, r.useEffect)(() => {
            if (a < 100) return;
            let e = window.setTimeout(() => l(!0), 350),
                t = window.setTimeout(() => c.current(), 850);
            return () => {
                window.clearTimeout(e), window.clearTimeout(t)
            }
        }, [a]), (0, t.jsxs)("div", {
            className: `vhs-loader${s?" is-out":""}`,
            role: "status",
            "aria-label": `Loading, ${a}%`,
            children: [(0, t.jsx)("p", {
                className: "vhs-loader-label",
                children: "Loading"
            }), (0, t.jsx)("p", {
                className: "vhs-loader-count",
                children: a
            }), (0, t.jsxs)("div", {
                className: "vhs-loader-bar",
                "aria-hidden": !0,
                style: {
                    "--loaded": a / 100
                },
                children: [(0, t.jsx)("i", {
                    className: "vhs-loader-ticks"
                }), (0, t.jsx)("i", {
                    className: "vhs-loader-dashes"
                })]
            })]
        })
    }])
}, 556304, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(618566);
    e.s(["default", 0, function({
        href: e,
        ...i
    }) {
        let a = (0, n.usePathname)() === e;
        return (0, t.jsx)(r.default, {
            href: e,
            "aria-current": a ? "page" : void 0,
            ...i
        })
    }])
}, 521145, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(522016),
        n = e.i(271645),
        i = e.i(745850),
        a = e.i(111837),
        o = e.i(58685),
        s = e.i(783329),
        l = e.i(569414),
        u = e.i(844294),
        c = e.i(556304);
    e.s(["ProjectChrome", 0, function() {
        let [e, d] = (0, n.useState)(l.navSeen), [f, h] = (0, n.useState)(() => !(0, l.navSeen)()), m = (0, o.usePageLoad)(), p = (0, n.useCallback)(() => {
            h(!1), (0, o.releaseScreen)()
        }, []);
        (0, n.useEffect)(() => {
            (0, l.navSeen)() || (0, o.holdScreen)()
        }, []);
        let g = (0, n.useRef)(null);
        (0, u.useSiteTime)(g);
        let v = (0, u.useSastClock)(),
            w = (0, s.useDevice)(),
            y = {
                "--source-ch": `Source: ${w||"—"}`.length,
                "--first-ch": 7
            };
        return (0, n.useEffect)(() => {
            if (f) return;
            let e = requestAnimationFrame(() => {
                d(!0), (0, l.markNavSeen)()
            });
            return () => cancelAnimationFrame(e)
        }, [f]), (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsxs)("div", {
                className: "vhs-crt",
                "aria-hidden": !0,
                children: [(0, t.jsx)(i.CrtLines, {}), (0, t.jsx)(i.Grain, {}), (0, t.jsx)("div", {
                    className: "vhs-crt-roll"
                })]
            }), (0, t.jsxs)("header", {
                className: "vhs-head pj-chrome",
                style: y,
                children: [(0, t.jsxs)(r.default, {
                    href: "/",
                    className: "vhs-logo",
                    children: [(0, t.jsx)("span", {
                        className: "vhs-logo-mark",
                        children: (0, t.jsx)("span", {
                            className: `vhs-logo-i${e?" is-in":""}`,
                            children: (0, t.jsxs)("picture", {
                                children: [(0, t.jsx)("source", {
                                    media: "(max-width: 700px)",
                                    srcSet: "/brand/arc-bands.svg",
                                    width: 67,
                                    height: 30
                                }), (0, t.jsx)("img", {
                                    src: "/brand/arc-logo.svg",
                                    width: 115,
                                    height: 30,
                                    alt: "Arc — home"
                                })]
                            })
                        })
                    }), (0, t.jsx)("img", {
                        className: "vhs-logo-rule",
                        src: "/brand/logo-rule.svg",
                        width: 115,
                        height: 2,
                        alt: ""
                    }), (0, t.jsxs)("span", {
                        className: "vhs-logo-meta",
                        children: [(0, t.jsx)(i.Reveal, {
                            on: e,
                            i: 1,
                            children: "Year"
                        }), (0, t.jsx)(i.Reveal, {
                            on: e,
                            i: 1,
                            children: (0, t.jsx)("span", {
                                className: "vhs-year",
                                children: "2026"
                            })
                        })]
                    })]
                }), (0, t.jsx)(i.Reveal, {
                    on: e,
                    i: 2,
                    className: "vhs-counter",
                    children: (0, t.jsx)("span", {
                        ref: g,
                        children: "00:00:00"
                    })
                }), (0, t.jsx)(i.Reveal, {
                    on: e,
                    i: 3,
                    className: "vhs-home",
                    children: (0, t.jsx)(c.default, {
                        href: "/",
                        children: "Home"
                    })
                }), (0, t.jsxs)("nav", {
                    className: "vhs-nav",
                    children: [(0, t.jsx)(i.Reveal, {
                        on: e,
                        i: 4,
                        className: "vhs-nav-about",
                        children: (0, t.jsx)(c.default, {
                            href: "/profile",
                            children: "Profile"
                        })
                    }), (0, t.jsx)(i.Reveal, {
                        on: e,
                        i: 4,
                        className: "vhs-nav-gallery",
                        children: (0, t.jsx)(c.default, {
                            href: "/news-watch",
                            children: "News Watch"
                        })
                    }), (0, t.jsx)(i.Reveal, {
                        on: e,
                        i: 4,
                        children: (0, t.jsx)("a", {
                            href: `mailto:${i.CONTACT_EMAIL}`,
                            children: "Contact"
                        })
                    })]
                })]
            }), (0, t.jsxs)("footer", {
                className: "vhs-foot pj-chrome",
                style: y,
                children: [(0, t.jsxs)(i.Reveal, {
                    on: e,
                    i: 9,
                    children: [v || "00:00", (0, t.jsx)("span", {
                        className: "vhs-tz",
                        children: " SAST"
                    })]
                }), (0, t.jsx)(i.Reveal, {
                    on: e,
                    i: 9,
                    className: "vhs-bw",
                    children: (0, t.jsx)(i.BwToggle, {})
                }), (0, t.jsx)(i.Reveal, {
                    on: e,
                    i: 10,
                    className: "vhs-source",
                    children: (0, t.jsxs)("span", {
                        children: ["Source: ", w || "—"]
                    })
                }), (0, t.jsx)(i.Reveal, {
                    on: e,
                    i: 11,
                    className: "vhs-email",
                    children: (0, t.jsx)(i.ContactLink, {
                        label: "Email"
                    })
                })]
            }), f && (0, t.jsx)(a.default, {
                progress: m.progress,
                ready: m.ready,
                onDone: p
            })]
        })
    }])
}, 900949, 429452, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(657688),
        n = e.i(271645);

    function i() {
        let [e, t] = (0, n.useState)(!1);
        return {
            done: e,
            onDone: (0, n.useCallback)(() => t(!0), []),
            fade: `media-fade${e?" is-in":""}`
        }
    }

    function a({
        done: e
    }) {
        return (0, t.jsx)("span", {
            className: `media-loading${e?" is-done":""}`,
            "aria-hidden": !0,
            children: (0, t.jsx)("span", {
                className: "media-loading-label",
                children: "[Loading]"
            })
        })
    }
    e.s(["MediaLoading", 0, a, "useMediaLoad", 0, i], 429452);
    var o = e.i(306257),
        s = e.i(942295);
    let l = e => ({
        l: e.left,
        t: e.top,
        w: e.width,
        h: e.height
    });

    function u({
        m: e
    }) {
        let {
            done: n,
            onDone: o,
            fade: s
        } = i();
        return (0, t.jsxs)(t.Fragment, {
            children: [(0, t.jsx)(a, {
                done: n
            }), "video" === e.kind ? (0, t.jsx)("video", {
                src: e.src,
                poster: e.poster,
                muted: !0,
                loop: !0,
                playsInline: !0,
                autoPlay: !0,
                className: s,
                onLoadedData: o,
                onError: o,
                "aria-label": e.alt || void 0
            }) : (0, t.jsx)(r.default, {
                src: e.src,
                alt: e.alt,
                fill: !0,
                sizes: "100vw",
                priority: !0,
                className: s,
                onLoad: o,
                onError: o,
                style: {
                    objectFit: "contain"
                }
            })]
        })
    }
    e.s(["default", 0, function({
        slides: e,
        index: r,
        onIndex: i,
        onClose: a,
        from: c,
        toRect: d
    }) {
        let f = e.length,
            h = e[r],
            m = (0, n.useRef)(null),
            p = (0, n.useRef)(null),
            g = (0, n.useRef)(null),
            v = (0, o.useBend)(p),
            w = (0, n.useRef)(null),
            y = (0, n.useCallback)(() => {
                let e = g.current;
                if (!e) return null;
                let t = {
                        l: e.offsetLeft,
                        t: e.offsetTop,
                        w: e.offsetWidth,
                        h: e.offsetHeight
                    },
                    r = e.offsetParent ? .getBoundingClientRect();
                r && (t.l += r.left, t.t += r.top);
                let n = h.width / h.height || 1,
                    [i, a] = n > t.w / t.h ? [t.w, t.w / n] : [t.h * n, t.h];
                return {
                    l: t.l + (t.w - i) / 2,
                    t: t.t + (t.h - a) / 2,
                    w: i,
                    h: a,
                    ox: t.l,
                    oy: t.t
                }
            }, [h.width, h.height]),
            b = (0, n.useCallback)(() => {
                let e = g.current,
                    t = w.current;
                if (!e || !t) return;
                let {
                    cur: r,
                    zoom: n,
                    page: i
                } = t;
                e.style.transformOrigin = `${n.l-n.ox}px ${n.t-n.oy}px`;
                let a = r.w / n.w,
                    o = .05 > Math.abs(r.l - n.l) && .05 > Math.abs(r.t - n.t) && 1e-4 > Math.abs(a - 1);
                e.style.transform = o ? "" : `translate3d(${r.l-n.l}px, ${r.t-n.t}px, 0) scale(${a})`;
                let s = Math.min(1, Math.max(0, (r.w - i.w) / (n.w - i.w || 1)));
                v(1 - s), m.current ? .style.setProperty("--zp", s.toFixed(4))
            }, [v]),
            x = (0, n.useCallback)(() => {
                let e = w.current;
                if (!e) return;
                cancelAnimationFrame(e.raf), e.last = performance.now();
                let t = e => {
                    let r = w.current;
                    if (!r) return;
                    let n = Math.max(0, Math.min(.1, (e - r.last) / 1e3));
                    r.last = e;
                    let i = 1 - Math.exp(-22 * n),
                        a = 1 - Math.exp(-s.EASE * n),
                        o = r.aim,
                        l = r.cur,
                        u = r.to;
                    for (let e of ["l", "t", "w", "h"]) o[e] += (u[e] - o[e]) * i, l[e] += (o[e] - l[e]) * a;
                    let c = Math.max(Math.abs(u.l - l.l), Math.abs(u.t - l.t), Math.abs(u.w - l.w), Math.abs(u.h - l.h));
                    if (c < .3 && (Object.assign(l, {
                            l: u.l,
                            t: u.t,
                            w: u.w,
                            h: u.h
                        }), Object.assign(o, l)), b(), c < .3) {
                        let e = r.done;
                        r.done = void 0, e ? .()
                    } else r.raf = requestAnimationFrame(t)
                };
                e.raf = requestAnimationFrame(t)
            }, [b]);
        (0, n.useEffect)(() => () => cancelAnimationFrame(w.current ? .raf ? ? 0), []);
        let j = (0, n.useRef)(!1);
        (0, n.useLayoutEffect)(() => {
            if (j.current) return;
            j.current = !0;
            let e = y();
            if (!e || !c || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return void v(0);
            let t = l(c);
            w.current = {
                cur: { ...t
                },
                aim: { ...t
                },
                to: {
                    l: e.l,
                    t: e.t,
                    w: e.w,
                    h: e.h
                },
                page: t,
                zoom: e,
                raf: 0,
                last: 0
            }, b(), x()
        }, [c, y, b, x, v]), (0, n.useEffect)(() => {
            let e = w.current,
                t = y();
            e && t && !e.done && (e.zoom = t, e.to = {
                l: t.l,
                t: t.t,
                w: t.w,
                h: t.h
            }, e.cur.w !== e.to.w && x())
        }, [r, y, x]);
        let [E, S] = (0, n.useState)(!1), _ = (0, n.useCallback)(() => {
            if (E) return;
            let e = d ? .(r),
                t = y();
            if (!e || !t || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return a();
            S(!0);
            let n = w.current,
                i = n ? n.cur : {
                    l: t.l,
                    t: t.t,
                    w: t.w,
                    h: t.h
                },
                o = n ? n.aim : { ...i
                },
                s = l(e);
            w.current = {
                cur: i,
                aim: o,
                to: s,
                page: s,
                zoom: t,
                raf: n ? .raf ? ? 0,
                last: 0,
                done: a
            }, x()
        }, [E, d, r, y, a, x]);
        return (0, n.useEffect)(() => {
            let e = e => {
                E || ("Escape" === e.key ? _() : "ArrowRight" === e.key ? i((r + 1) % f) : "ArrowLeft" === e.key && i((r - 1 + f) % f))
            };
            return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e)
        }, [r, f, i, _, E]), (0, t.jsxs)("div", {
            ref: m,
            className: `pj-zoom${c?" is-grown":""}${E?" is-closing":""}`,
            role: "dialog",
            "aria-modal": "true",
            "aria-label": `${r+1} of ${f}`,
            children: [(0, t.jsx)("div", {
                ref: p,
                className: "pj-zoom-stage",
                children: (0, t.jsx)("button", {
                    ref: g,
                    type: "button",
                    className: "pj-zoom-shot",
                    "data-caption": "[Close]",
                    "aria-label": "Close",
                    onClick: _,
                    children: (0, t.jsx)(u, {
                        m: h
                    }, h.src)
                })
            }), (0, t.jsx)("button", {
                type: "button",
                className: "pj-zoom-close",
                onClick: _,
                children: "Close[X]"
            }), f > 1 && (0, t.jsxs)(t.Fragment, {
                children: [(0, t.jsx)("button", {
                    type: "button",
                    className: "pj-zoom-arrow is-prev",
                    "aria-label": "Previous",
                    onClick: () => i((r - 1 + f) % f),
                    children: (0, t.jsx)("img", {
                        src: "/brand/arrow-next.svg",
                        width: 17,
                        height: 23,
                        alt: ""
                    })
                }), (0, t.jsx)("button", {
                    type: "button",
                    className: "pj-zoom-arrow is-next",
                    "aria-label": "Next",
                    onClick: () => i((r + 1) % f),
                    children: (0, t.jsx)("img", {
                        src: "/brand/arrow-next.svg",
                        width: 17,
                        height: 23,
                        alt: ""
                    })
                })]
            })]
        })
    }], 900949)
}, 306257, e => {
    "use strict";
    var t = e.i(271645);
    let r = 0,
        n = null,
        i = "http://www.w3.org/2000/svg";

    function a() {
        let e = navigator.userAgent;
        return !(/safari/i.test(e) && !/chrome|chromium|crios|fxios|edg|android/i.test(e)) && !window.matchMedia("(pointer: coarse)").matches
    }
    e.s(["K", 0, .16, "bendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            i = r.height / 2,
            a = (e - r.left - n) / n,
            o = (t - r.top - i) / i,
            s = a,
            l = o;
        for (let e = 0; e < 5; e++) l = o / (1 + .16 * (s = a / (1 + .16 * l * l)) * s);
        return {
            x: r.left + n + s * n,
            y: r.top + i + l * i
        }
    }, "canBend", 0, a, "unbendPoint", 0, function(e, t, r) {
        let n = r.width / 2,
            i = r.height / 2,
            a = (e - r.left - n) / n,
            o = (t - r.top - i) / i;
        return {
            x: r.left + n + a * (1 + .16 * o * o) * n,
            y: r.top + i + o * (1 + .16 * a * a) * i
        }
    }, "useBend", 0, function(e) {
        let o = (0, t.useRef)(1),
            s = (0, t.useRef)(null);
        return (0, t.useEffect)(() => {
            let t = e.current;
            if (!t || !a()) return;
            let l = `crt-bend-${++r}`,
                u = document.createElementNS(i, "filter");
            u.id = l, u.setAttribute("x", "0"), u.setAttribute("y", "0"), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("primitiveUnits", "userSpaceOnUse"), u.setAttribute("color-interpolation-filters", "sRGB");
            let c = document.createElementNS(i, "feImage");
            c.setAttribute("preserveAspectRatio", "none"), c.setAttribute("result", "map");
            let d = document.createElementNS(i, "feDisplacementMap");
            d.setAttribute("in", "SourceGraphic"), d.setAttribute("in2", "map"), d.setAttribute("xChannelSelector", "R"), d.setAttribute("yChannelSelector", "G"), u.append(c, d), (function() {
                if (n ? .isConnected) return n;
                let e = document.createElementNS(i, "svg");
                return e.setAttribute("aria-hidden", "true"), e.setAttribute("width", "0"), e.setAttribute("height", "0"), e.style.position = "absolute", n = document.createElementNS(i, "defs"), e.appendChild(n), document.body.appendChild(e), n
            })().appendChild(u);
            let f = "",
                h = 0,
                m = () => {
                    d.setAttribute("scale", String(h * o.current)), t.style.filter = o.current > .001 ? `url(#${l})` : ""
                };
            s.current = m;
            let p = () => {
                let e = t.offsetWidth,
                    r = t.offsetHeight;
                if (!e || !r || `${e}x${r}` === f) return;
                f = `${e}x${r}`;
                let n = .16 * Math.max(e, r);
                c.setAttribute("x", "0"), c.setAttribute("y", "0"), c.setAttribute("width", String(e)), c.setAttribute("height", String(r)), c.setAttribute("href", function(e, t, r) {
                    let n = document.createElement("canvas");
                    n.width = n.height = 128;
                    let i = n.getContext("2d"),
                        a = i.createImageData(128, 128);
                    for (let n = 0; n < 128; n++) {
                        let i = (n + .5) / 128 * 2 - 1;
                        for (let o = 0; o < 128; o++) {
                            let s = (o + .5) / 128 * 2 - 1,
                                l = .16 * s * i * i * (e / 2),
                                u = .16 * i * s * s * (t / 2),
                                c = (128 * n + o) * 4;
                            a.data[c] = Math.round((.5 + l / r) * 255), a.data[c + 1] = Math.round((.5 + u / r) * 255), a.data[c + 2] = 128, a.data[c + 3] = 255
                        }
                    }
                    return i.putImageData(a, 0, 0), n.toDataURL()
                }(e, r, n)), h = n, m()
            };
            p();
            let g = new ResizeObserver(p);
            return g.observe(t), () => {
                g.disconnect(), s.current = null, u.remove(), t.style.filter = ""
            }
        }, [e]), (0, t.useCallback)(e => {
            o.current = e, s.current ? .()
        }, [])
    }])
}, 783329, 569414, 844294, e => {
    "use strict";
    var t = e.i(271645);
    let r = [
        [1512, 982, "MacBook 14″"],
        [1352, 878, "MacBook 14″"],
        [1800, 1169, "MacBook 14″"],
        [1728, 1117, "MacBook 16″"],
        [1496, 967, "MacBook 16″"],
        [2056, 1329, "MacBook 16″"],
        [1470, 956, "MacBook Air 13″"],
        [1280, 832, "MacBook Air 13″"],
        [1710, 1107, "MacBook Air 13″"],
        [1710, 1112, "MacBook Air 15″"],
        [1440, 932, "MacBook Air 15″"],
        [1440, 900, "MacBook 13″"],
        [1280, 800, "MacBook 13″"],
        [1680, 1050, "MacBook 13″"],
        [1536, 960, "MacBook 16″"]
    ];

    function n() {
        if ("u" < typeof navigator) return "Unknown";
        let e = navigator.userAgent,
            t = navigator.maxTouchPoints > 1;
        if (/iPhone/.test(e)) return "iPhone";
        if (/iPad/.test(e) || /Macintosh/.test(e) && t) return "iPad";
        if (/Android/.test(e)) return /Mobile/.test(e) ? "Android" : "Android Tablet";
        if (/CrOS/.test(e)) return "Chromebook";
        if (/Macintosh/.test(e)) {
            let e = Math.max(screen.width, screen.height),
                t = Math.min(screen.width, screen.height),
                n = r.find(([r, n]) => r === e && n === t);
            return n ? n[2] : e > 2056 ? "Mac Display" : "Mac"
        }
        return /Windows/.test(e) ? "PC" : /Linux/.test(e) ? "Linux" : "Unknown"
    }
    let i = () => () => {};
    e.s(["useDevice", 0, function() {
        return (0, t.useSyncExternalStore)(i, n, () => "")
    }], 783329);
    let a = !1;
    e.s(["markNavSeen", 0, function() {
        a = !0
    }, "navSeen", 0, () => a], 569414);
    let o = new Intl.DateTimeFormat("en-GB", {
            timeZone: "Africa/Johannesburg",
            hour: "2-digit",
            minute: "2-digit",
            hour12: !1
        }),
        s = () => o.format(new Date),
        l = e => {
            let t = window.setInterval(e, 15e3);
            return () => window.clearInterval(t)
        };
    e.s(["useSastClock", 0, function() {
        return (0, t.useSyncExternalStore)(l, s, () => "")
    }, "useSiteTime", 0, function(e, r = !0) {
        (0, t.useLayoutEffect)(() => {
            let t, n = function(e) {
                let t = "arc:visit";
                try {
                    let r = Number(sessionStorage.getItem(t));
                    if (r > 0) return r;
                    if (!e) return null;
                    let n = Date.now();
                    return sessionStorage.setItem(t, String(n)), n
                } catch {
                    return e ? Date.now() : null
                }
            }(r);
            if (null === n) return;
            let i = () => {
                let t = Math.max(0, Math.floor((Date.now() - n) / 1e3)),
                    r = String(Math.floor(t / 3600)).padStart(2, "0"),
                    i = String(Math.floor(t % 3600 / 60)).padStart(2, "0"),
                    a = String(t % 60).padStart(2, "0");
                e.current && (e.current.textContent = `${r}:${i}:${a}`)
            };
            i();
            let a = () => {
                t = window.setTimeout(() => {
                    i(), a()
                }, 1e3 - (Date.now() - n) % 1e3)
            };
            return a(), () => window.clearTimeout(t)
        }, [e, r])
    }], 844294)
}, 916494, e => {
    "use strict";
    let t = /swiftshader|llvmpipe|lavapipe|softpipe|software|basic render|warp/i,
        r = "arc:gpu",
        n = null;
    e.s(["can3D", 0, function() {
        let e = "hardware" === function() {
            if (n) return n;
            try {
                let e = new URLSearchParams(location.search).get("3d");
                if ("0" === e) return n = "software";
                if ("1" === e) return n = "hardware";
                let t = sessionStorage.getItem(r);
                if ("hardware" === t || "software" === t || "none" === t) return n = t
            } catch {}
            let e = "none";
            try {
                let r = document.createElement("canvas").getContext("webgl2", {
                    failIfMajorPerformanceCaveat: !0
                });
                if (r) {
                    let n = r.getExtension("WEBGL_debug_renderer_info"),
                        i = String(r.getParameter(n ? n.UNMASKED_RENDERER_WEBGL : r.RENDERER) ? ? "");
                    e = t.test(i) ? "software" : "hardware", r.getExtension("WEBGL_lose_context") ? .loseContext()
                }
            } catch {
                e = "none"
            }
            try {
                sessionStorage.setItem(r, e)
            } catch {}
            return n = e
        }();
        return !e && "u" > typeof document && document.documentElement.classList.add("lite"), e
    }])
}, 942295, e => {
    "use strict";
    e.s(["EASE", 0, 7, "SETTLE", 0, 4.2, "releaseSpeed", 0, function(e, t, r) {
        return Math.max(-r, Math.min(r, e * Math.exp(-Math.max(0, t - 40) / 45)))
    }, "settleSlot", 0, function(e, t, r, n = .12) {
        let i = Math.round(e / r) * r,
            a = e - t;
        return Math.abs(i - t) < r / 2 && Math.abs(a) > r * n ? t + Math.sign(a) * r : i
    }, "springTo", 0, function(e, t, r, n, i = 7) {
        let a = e - r,
            o = Math.exp(-i * n),
            s = t + i * a;
        return {
            x: r + (a + s * n) * o,
            v: (t - s * i * n) * o
        }
    }])
}, 58685, e => {
    "use strict";
    var t = e.i(271645);
    let r = !0,
        n = new Set,
        i = () => n.forEach(e => e()),
        a = e => (n.add(e), () => n.delete(e));
    e.s(["holdScreen", 0, function() {
        r = !1, i()
    }, "releaseScreen", 0, function() {
        r = !0, i()
    }, "usePageLoad", 0, function() {
        let [e, r] = (0, t.useState)({
            progress: 0,
            ready: !1
        });
        return (0, t.useEffect)(() => {
            if ("complete" === document.readyState) return void r({
                progress: 1,
                ready: !0
            });
            let e = [...document.images],
                t = () => {
                    let t = e.filter(e => e.complete).length;
                    r(r => r.ready ? r : {
                        progress: e.length ? t / e.length : .5,
                        ready: !1
                    })
                },
                n = () => r({
                    progress: 1,
                    ready: !0
                });
            return e.forEach(e => e.addEventListener("load", t)), window.addEventListener("load", n), t(), () => {
                e.forEach(e => e.removeEventListener("load", t)), window.removeEventListener("load", n)
            }
        }, []), e
    }, "useScreenReady", 0, function() {
        return (0, t.useSyncExternalStore)(a, () => r, () => !0)
    }])
}, 522016, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return v
        },
        useLinkStatus: function() {
            return y
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = e.r(190809),
        o = e.r(843476),
        s = a._(e.r(271645)),
        l = e.r(195057),
        u = e.r(8372),
        c = e.r(818581),
        d = e.r(718967),
        f = e.r(405550),
        h = e.r(388540),
        m = e.r(91949),
        p = e.r(573668),
        g = e.r(509396);

    function v(t) {
        var r;
        let n, i, a, [v, y] = (0, s.useOptimistic)(m.IDLE_LINK_STATUS),
            b = (0, s.useRef)(null),
            {
                href: x,
                as: j,
                children: E,
                prefetch: S = null,
                passHref: _,
                replace: M,
                shallow: C,
                scroll: P,
                onClick: R,
                onMouseEnter: A,
                onTouchStart: O,
                legacyBehavior: N = !1,
                onNavigate: T,
                transitionTypes: k,
                ref: L,
                unstable_dynamicOnHover: $,
                ...I
            } = t;
        n = E, N && ("string" == typeof n || "number" == typeof n) && (n = (0, o.jsx)("a", {
            children: n
        }));
        let D = s.default.useContext(u.AppRouterContext),
            z = !1 !== S,
            F = !1 === S ? "none" : !0 === S ? "full" : "auto",
            B = "none" !== F ? "auto" === F ? g.FetchStrategy.PPR : g.FetchStrategy.Full : g.FetchStrategy.PPR,
            U = "string" == typeof(r = j || x) ? r : (0, l.formatUrl)(r);
        if (N) {
            if (n ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            i = s.default.Children.only(n)
        }
        let q = N ? i && "object" == typeof i && i.ref : L,
            W, G = s.default.useCallback(e => (null !== D && (b.current = (0, m.mountLinkInstance)(e, U, D, B, z, y, W)), () => {
                b.current && ((0, m.unmountLinkForCurrentNavigation)(b.current), b.current = null), (0, m.unmountPrefetchableInstance)(e)
            }), [z, U, D, B, y, W]),
            K = {
                ref: (0, c.useMergedRef)(G, q),
                onClick(t) {
                    N || "function" != typeof R || R(t), N && i.props && "function" == typeof i.props.onClick && i.props.onClick(t), !D || t.defaultPrevented || function(t, r, n, i, a, o, l, u = "none") {
                        if ("u" > typeof window) {
                            let c, {
                                nodeName: d
                            } = t.currentTarget;
                            if ("A" === d.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, p.isLocalURL)(r)) {
                                i && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), o) {
                                let e = !1;
                                if (o({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: f
                            } = e.r(699781);
                            s.default.startTransition(() => {
                                f(r, i ? "replace" : "push", !1 === a ? h.ScrollBehavior.NoScroll : h.ScrollBehavior.Default, n.current, l, u)
                            })
                        }
                    }(t, U, b, M, P, T, k, F)
                },
                onMouseEnter(e) {
                    N || "function" != typeof A || A(e), N && i.props && "function" == typeof i.props.onMouseEnter && i.props.onMouseEnter(e), D && z && (0, m.onNavigationIntent)(e.currentTarget, !0 === $)
                },
                onTouchStart: function(e) {
                    N || "function" != typeof O || O(e), N && i.props && "function" == typeof i.props.onTouchStart && i.props.onTouchStart(e), D && z && (0, m.onNavigationIntent)(e.currentTarget, !0 === $)
                }
            };
        return (0, d.isAbsoluteUrl)(U) ? K.href = U : N && !_ && ("a" !== i.type || "href" in i.props) || (K.href = (0, f.addBasePath)(U)), a = N ? s.default.cloneElement(i, K) : (0, o.jsx)("a", { ...I,
            ...K,
            children: n
        }), (0, o.jsx)(w.Provider, {
            value: v,
            children: a
        })
    }
    let w = (0, s.createContext)(m.IDLE_LINK_STATUS),
        y = () => (0, s.useContext)(w);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 605500, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "Image", {
        enumerable: !0,
        get: function() {
            return x
        }
    });
    let n = e.r(555682),
        i = e.r(190809),
        a = e.r(843476),
        o = i._(e.r(271645)),
        s = n._(e.r(174080)),
        l = n._(e.r(325633)),
        u = e.r(908927),
        c = e.r(987690),
        d = e.r(918556),
        f = e.r(65856),
        h = n._(e.r(1948)),
        m = e.r(818581),
        p = {
            deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
            imageSizes: [32, 48, 64, 96, 128, 256, 384],
            qualities: [75],
            path: "/_next/image",
            loader: "default",
            dangerouslyAllowSVG: !1,
            unoptimized: !1
        };

    function g(e, t, r, n, i, a, o) {
        let s = e ? .src;
        e && e["data-loaded-src"] !== s && (e["data-loaded-src"] = s, ("decode" in e ? e.decode() : Promise.resolve()).catch(() => {}).then(() => {
            if (e.parentElement && e.isConnected) {
                if ("empty" !== t && i(!0), r ? .current) {
                    let t = new Event("load");
                    Object.defineProperty(t, "target", {
                        writable: !1,
                        value: e
                    });
                    let n = !1,
                        i = !1;
                    r.current({ ...t,
                        nativeEvent: t,
                        currentTarget: e,
                        target: e,
                        isDefaultPrevented: () => n,
                        isPropagationStopped: () => i,
                        persist: () => {},
                        preventDefault: () => {
                            n = !0, t.preventDefault()
                        },
                        stopPropagation: () => {
                            i = !0, t.stopPropagation()
                        }
                    })
                }
                n ? .current && n.current(e)
            }
        }))
    }

    function v(e) {
        return o.use ? {
            fetchPriority: e
        } : {
            fetchpriority: e
        }
    }
    "u" < typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let w = "u" < typeof window ? o.useEffect : o.useLayoutEffect,
        y = (0, o.forwardRef)(({
            src: e,
            srcSet: t,
            sizes: r,
            height: n,
            width: i,
            decoding: s,
            className: l,
            style: u,
            fetchPriority: c,
            placeholder: d,
            loading: f,
            unoptimized: h,
            fill: p,
            onLoadRef: y,
            onLoadingCompleteRef: b,
            setBlurComplete: x,
            setShowAltText: j,
            sizesInput: E,
            onLoad: S,
            onError: _,
            ...M
        }, C) => {
            let P = (0, o.useRef)(!1),
                R = (0, o.useRef)(null);
            w(() => {
                let {
                    current: e
                } = P, {
                    current: t
                } = R;
                e || null === t || (_ && (t.src = t.src), t.complete && g(t, d, y, b, x, h, E), P.current = !0)
            }, [e, d, y, b, _, h, E]);
            let A = (0, m.useMergedRef)(C, R);
            return (0, a.jsx)("img", { ...M,
                ...v(c),
                loading: f,
                width: i,
                height: n,
                decoding: s,
                "data-nimg": p ? "fill" : "1",
                className: l,
                style: u,
                sizes: r,
                srcSet: t,
                src: e,
                ref: A,
                onLoad: e => {
                    g(e.currentTarget, d, y, b, x, h, E)
                },
                onError: e => {
                    j(!0), "empty" !== d && x(!0), _ && _(e)
                }
            })
        });

    function b({
        isAppRouter: e,
        imgAttributes: t
    }) {
        let r = {
            as: "image",
            imageSrcSet: t.srcSet,
            imageSizes: t.sizes,
            crossOrigin: t.crossOrigin,
            referrerPolicy: t.referrerPolicy,
            ...v(t.fetchPriority)
        };
        return e && s.default.preload ? (s.default.preload(t.src, r), null) : (0, a.jsx)(l.default, {
            children: (0, a.jsx)("link", {
                rel: "preload",
                href: t.srcSet ? void 0 : t.src,
                ...r
            }, "__nimg-" + t.src + t.srcSet + t.sizes)
        })
    }
    let x = (0, o.forwardRef)((e, t) => {
        let r = (0, o.useContext)(f.RouterContext),
            n = (0, o.useContext)(d.ImageConfigContext),
            i = (0, o.useMemo)(() => {
                let e = p || n || c.imageConfigDefault,
                    t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
                    r = e.deviceSizes.sort((e, t) => e - t),
                    i = e.qualities ? .sort((e, t) => e - t);
                return { ...e,
                    allSizes: t,
                    deviceSizes: r,
                    qualities: i,
                    localPatterns: "u" < typeof window ? n ? .localPatterns : e.localPatterns
                }
            }, [n]),
            {
                onLoad: s,
                onLoadingComplete: l
            } = e,
            m = (0, o.useRef)(s);
        (0, o.useEffect)(() => {
            m.current = s
        }, [s]);
        let g = (0, o.useRef)(l);
        (0, o.useEffect)(() => {
            g.current = l
        }, [l]);
        let [v, w] = (0, o.useState)(!1), [x, j] = (0, o.useState)(!1), {
            props: E,
            meta: S
        } = (0, u.getImgProps)(e, {
            defaultLoader: h.default,
            imgConf: i,
            blurComplete: v,
            showAltText: x
        });
        return (0, a.jsxs)(a.Fragment, {
            children: [(0, a.jsx)(y, { ...E,
                unoptimized: S.unoptimized,
                placeholder: S.placeholder,
                fill: S.fill,
                onLoadRef: m,
                onLoadingCompleteRef: g,
                setBlurComplete: w,
                setShowAltText: j,
                sizesInput: e.sizes,
                ref: t
            }), S.preload ? (0, a.jsx)(b, {
                isAppRouter: !r,
                imgAttributes: E
            }) : null]
        })
    });
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794909, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return c
        },
        getImageProps: function() {
            return u
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = e.r(555682),
        o = e.r(908927),
        s = e.r(605500),
        l = a._(e.r(1948));

    function u(e) {
        let {
            props: t
        } = (0, o.getImgProps)(e, {
            defaultLoader: l.default,
            imgConf: {
                deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                imageSizes: [32, 48, 64, 96, 128, 256, 384],
                qualities: [75],
                path: "/_next/image",
                loader: "default",
                dangerouslyAllowSVG: !1,
                unoptimized: !1
            }
        });
        for (let [e, r] of Object.entries(t)) void 0 === r && delete t[e];
        return {
            props: t
        }
    }
    let c = s.Image
}, 657688, (e, t, r) => {
    t.exports = e.r(794909)
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(271645);

    function i(e, t) {
        let r = (0, n.useRef)(null),
            i = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = i.current;
                t && (i.current = null, t())
            } else e && (r.current = a(e, n)), t && (i.current = a(t, n))
        }, [e, t])
    }

    function a(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 325633, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return p
        },
        defaultHead: function() {
            return d
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = e.r(555682),
        o = e.r(190809),
        s = e.r(843476),
        l = o._(e.r(271645)),
        u = a._(e.r(898879)),
        c = e.r(742732);

    function d() {
        return [(0, s.jsx)("meta", {
            charSet: "utf-8"
        }, "charset"), (0, s.jsx)("meta", {
            name: "viewport",
            content: "width=device-width"
        }, "viewport")]
    }

    function f(e, t) {
        return "string" == typeof t || "number" == typeof t ? e : t.type === l.default.Fragment ? e.concat(l.default.Children.toArray(t.props.children).reduce((e, t) => "string" == typeof t || "number" == typeof t ? e : e.concat(t), [])) : e.concat(t)
    }
    let h = ["name", "httpEquiv", "charSet", "itemProp"];

    function m(e) {
        let t, r, n, i;
        return e.reduce(f, []).reverse().concat(d().reverse()).filter((t = new Set, r = new Set, n = new Set, i = {}, e => {
            let a = !0,
                o = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
                o = !0;
                let r = e.key.slice(e.key.indexOf("$") + 1);
                t.has(r) ? a = !1 : t.add(r)
            }
            switch (e.type) {
                case "title":
                case "base":
                    r.has(e.type) ? a = !1 : r.add(e.type);
                    break;
                case "meta":
                    for (let t = 0, r = h.length; t < r; t++) {
                        let r = h[t];
                        if (e.props.hasOwnProperty(r))
                            if ("charSet" === r) n.has(r) ? a = !1 : n.add(r);
                            else {
                                let t = e.props[r],
                                    n = i[r] || new Set;
                                ("name" !== r || !o) && n.has(t) ? a = !1 : (n.add(t), i[r] = n)
                            }
                    }
            }
            return a
        })).reverse().map((e, t) => {
            let r = e.key || t;
            return l.default.cloneElement(e, {
                key: r
            })
        })
    }
    let p = function({
        children: e
    }) {
        let t = (0, l.useContext)(c.HeadManagerContext);
        return (0, s.jsx)(u.default, {
            reduceComponentsToState: m,
            headManager: t,
            children: e
        })
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 918556, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ImageConfigContext", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(555682)._(e.r(271645)),
        i = e.r(987690),
        a = n.default.createContext(i.imageConfigDefault)
}, 65856, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "RouterContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(555682)._(e.r(271645)).default.createContext(null)
}, 670965, (e, t, r) => {
    "use strict";

    function n(e, t) {
        let r = e || 75;
        return t ? .qualities ? .length ? t.qualities.reduce((e, t) => Math.abs(t - r) < Math.abs(e - r) ? t : e, t.qualities[0]) : r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findClosestQuality", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 1948, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(670965),
        i = e.r(543369);

    function a({
        config: e,
        src: t,
        width: r,
        quality: o
    }) {
        let s = (0, i.getDeploymentId)();
        if (t.startsWith("/") && !t.startsWith("//"))
            if (t.includes("/_next/static/immutable") && !(0, i.getAssetToken)()) s = void 0;
            else {
                let e = t.indexOf("?");
                if (-1 !== e) {
                    let r = new URLSearchParams(t.slice(e + 1)),
                        n = r.get("dpl");
                    if (n) {
                        s = n, r.delete("dpl");
                        let i = r.toString();
                        t = t.slice(0, e) + (i ? "?" + i : "")
                    }
                }
            }
        if (t.startsWith("/") && t.includes("?") && e.localPatterns ? .length === 1 && "**" === e.localPatterns[0].pathname && "" === e.localPatterns[0].search) throw Object.defineProperty(Error(`Image with src "${t}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`), "__NEXT_ERROR_CODE", {
            value: "E871",
            enumerable: !1,
            configurable: !0
        });
        let l = (0, n.findClosestQuality)(o, e);
        return `${e.path}?url=${encodeURIComponent(t)}&w=${r}&q=${l}${t.startsWith("/")&&s?`&dpl=${s}`:""}`
    }
    a.__next_img_default = !0;
    let o = a
}, 488143, (e, t, r) => {
    "use strict";

    function n({
        widthInt: e,
        heightInt: t,
        blurWidth: r,
        blurHeight: i,
        blurDataURL: a,
        objectFit: o
    }) {
        let s = r ? 40 * r : e,
            l = i ? 40 * i : t,
            u = s && l ? `viewBox='0 0 ${s} ${l}'` : "";
        return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${u}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${u?"none":"contain"===o?"xMidYMid":"cover"===o?"xMidYMid slice":"none"}' style='filter: url(%23b);' href='${a}'/%3E%3C/svg%3E`
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getImageBlurSvg", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 987690, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        VALID_LOADERS: function() {
            return a
        },
        imageConfigDefault: function() {
            return o
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = ["default", "imgix", "cloudinary", "akamai", "custom"],
        o = {
            deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
            imageSizes: [32, 48, 64, 96, 128, 256, 384],
            path: "/_next/image",
            loader: "default",
            loaderFile: "",
            domains: [],
            disableStaticImages: !1,
            minimumCacheTTL: 14400,
            formats: ["image/webp"],
            maximumDiskCacheSize: void 0,
            maximumRedirects: 3,
            maximumResponseBody: 5e7,
            dangerouslyAllowLocalIP: !1,
            dangerouslyAllowSVG: !1,
            contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
            contentDispositionType: "attachment",
            localPatterns: void 0,
            remotePatterns: [],
            qualities: [75],
            unoptimized: !1,
            customCacheHandler: !1
        }
}, 908927, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getImgProps", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(543369),
        i = e.r(488143),
        a = e.r(987690),
        o = ["-moz-initial", "fill", "none", "scale-down", void 0];

    function s(e) {
        return void 0 !== e.default
    }

    function l(e) {
        return void 0 === e ? e : "number" == typeof e ? Number.isFinite(e) ? e : NaN : "string" == typeof e && /^[0-9]+$/.test(e) ? parseInt(e, 10) : NaN
    }

    function u({
        src: e,
        sizes: t,
        unoptimized: r = !1,
        priority: c = !1,
        preload: d = !1,
        loading: f,
        className: h,
        quality: m,
        width: p,
        height: g,
        fill: v = !1,
        style: w,
        overrideSrc: y,
        onLoad: b,
        onLoadingComplete: x,
        placeholder: j = "empty",
        blurDataURL: E,
        fetchPriority: S,
        decoding: _ = "async",
        layout: M,
        objectFit: C,
        objectPosition: P,
        lazyBoundary: R,
        lazyRoot: A,
        ...O
    }, N) {
        var T;
        let k, L, $, {
                imgConf: I,
                showAltText: D,
                blurComplete: z,
                defaultLoader: F
            } = N,
            B = I || a.imageConfigDefault;
        if ("allSizes" in B) k = B;
        else {
            let e = [...B.deviceSizes, ...B.imageSizes].sort((e, t) => e - t),
                t = B.deviceSizes.sort((e, t) => e - t),
                r = B.qualities ? .sort((e, t) => e - t);
            k = { ...B,
                allSizes: e,
                deviceSizes: t,
                qualities: r
            }
        }
        if (void 0 === F) throw Object.defineProperty(Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config"), "__NEXT_ERROR_CODE", {
            value: "E163",
            enumerable: !1,
            configurable: !0
        });
        let U = O.loader || F;
        delete O.loader, delete O.srcSet;
        let q = "__next_img_default" in U;
        if (q) {
            if ("custom" === k.loader) throw Object.defineProperty(Error(`Image with src "${e}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`), "__NEXT_ERROR_CODE", {
                value: "E252",
                enumerable: !1,
                configurable: !0
            })
        } else {
            let e = U;
            U = t => {
                let {
                    config: r,
                    ...n
                } = t;
                return e(n)
            }
        }
        if (M) {
            "fill" === M && (v = !0);
            let e = {
                intrinsic: {
                    maxWidth: "100%",
                    height: "auto"
                },
                responsive: {
                    width: "100%",
                    height: "auto"
                }
            }[M];
            e && (w = { ...w,
                ...e
            });
            let r = {
                responsive: "100vw",
                fill: "100vw"
            }[M];
            r && !t && (t = r)
        }
        let W = "",
            G = l(p),
            K = l(g);
        if ((T = e) && "object" == typeof T && (s(T) || void 0 !== T.src)) {
            let t = s(e) ? e.default : e;
            if (!t.src) throw Object.defineProperty(Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(t)}`), "__NEXT_ERROR_CODE", {
                value: "E460",
                enumerable: !1,
                configurable: !0
            });
            if (!t.height || !t.width) throw Object.defineProperty(Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(t)}`), "__NEXT_ERROR_CODE", {
                value: "E48",
                enumerable: !1,
                configurable: !0
            });
            if (L = t.blurWidth, $ = t.blurHeight, E = E || t.blurDataURL, W = t.src, !v)
                if (G || K) {
                    if (G && !K) {
                        let e = G / t.width;
                        K = Math.round(t.height * e)
                    } else if (!G && K) {
                        let e = K / t.height;
                        G = Math.round(t.width * e)
                    }
                } else G = t.width, K = t.height
        }
        let X = !c && !d && ("lazy" === f || void 0 === f);
        (!(e = "string" == typeof e ? e : W) || e.startsWith("data:") || e.startsWith("blob:")) && (r = !0, X = !1), k.unoptimized && (r = !0), q && !k.dangerouslyAllowSVG && e.split("?", 1)[0].endsWith(".svg") && (r = !0);
        let H = l(m),
            V = Object.assign(v ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: C,
                objectPosition: P
            } : {}, D ? {} : {
                color: "transparent"
            }, w),
            J = z || "empty" === j ? null : "blur" === j ? `url("data:image/svg+xml;charset=utf-8,${(0,i.getImageBlurSvg)({widthInt:G,heightInt:K,blurWidth:L,blurHeight:$,blurDataURL:E||"",objectFit:V.objectFit})}")` : `url("${j}")`,
            Q = o.includes(V.objectFit) ? "fill" === V.objectFit ? "100% 100%" : "cover" : V.objectFit,
            Y = J ? {
                backgroundSize: Q,
                backgroundPosition: V.objectPosition || "50% 50%",
                backgroundRepeat: "no-repeat",
                backgroundImage: J
            } : {},
            Z = function({
                config: e,
                src: t,
                unoptimized: r,
                width: i,
                quality: a,
                sizes: o,
                loader: s
            }) {
                if (r) {
                    if (t.startsWith("/") && !t.startsWith("//")) {
                        let e = (0, n.getDeploymentId)();
                        if (t.includes("/_next/static/immutable") && !(0, n.getAssetToken)()) e = void 0;
                        else if (e) {
                            let r = t.indexOf("?");
                            if (-1 !== r) {
                                let n = new URLSearchParams(t.slice(r + 1));
                                n.get("dpl") || (n.append("dpl", e), t = t.slice(0, r) + "?" + n.toString())
                            } else t += `?dpl=${e}`
                        }
                    }
                    return {
                        src: t,
                        srcSet: void 0,
                        sizes: void 0
                    }
                }
                let {
                    widths: l,
                    kind: u
                } = function({
                    deviceSizes: e,
                    allSizes: t
                }, r, n) {
                    if (n) {
                        let r = /(^|\s)(1?\d?\d)vw/g,
                            i = [];
                        for (let e; e = r.exec(n);) i.push(parseInt(e[2]));
                        if (i.length) {
                            let r = .01 * Math.min(...i);
                            return {
                                widths: t.filter(t => t >= e[0] * r),
                                kind: "w"
                            }
                        }
                        return {
                            widths: t,
                            kind: "w"
                        }
                    }
                    return "number" != typeof r ? {
                        widths: e,
                        kind: "w"
                    } : {
                        widths: [...new Set([r, 2 * r].map(e => t.find(t => t >= e) || t[t.length - 1]))],
                        kind: "x"
                    }
                }(e, i, o), c = l.length - 1;
                return {
                    sizes: o || "w" !== u ? o : "100vw",
                    srcSet: l.map((r, n) => `${s({config:e,src:t,quality:a,width:r})} ${"w"===u?r:n+1}${u}`).join(", "),
                    src: s({
                        config: e,
                        src: t,
                        quality: a,
                        width: l[c]
                    })
                }
            }({
                config: k,
                src: e,
                unoptimized: r,
                width: G,
                quality: H,
                sizes: t,
                loader: U
            }),
            ee = X ? "lazy" : f;
        return {
            props: { ...O,
                loading: ee,
                fetchPriority: S,
                width: G,
                height: K,
                decoding: _,
                className: h,
                style: { ...V,
                    ...Y
                },
                sizes: Z.sizes,
                srcSet: Z.srcSet,
                src: y || Z.src
            },
            meta: {
                unoptimized: r,
                preload: d || c,
                placeholder: j,
                fill: v
            }
        }
    }
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(718967),
        i = e.r(652817);

    function a(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, i.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 998183, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        assign: function() {
            return l
        },
        searchParamsToUrlQuery: function() {
            return a
        },
        urlQueryToSearchParams: function() {
            return s
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });

    function a(e) {
        let t = {};
        for (let [r, n] of e.entries()) {
            let e = t[r];
            void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
        }
        return t
    }

    function o(e) {
        return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
    }

    function s(e) {
        let t = new URLSearchParams;
        for (let [r, n] of Object.entries(e))
            if (Array.isArray(n))
                for (let e of n) t.append(r, o(e));
            else t.set(r, o(n));
        return t
    }

    function l(e, ...t) {
        for (let r of t) {
            for (let t of r.keys()) e.delete(t);
            for (let [t, n] of r.entries()) e.append(t, n)
        }
        return e
    }
}, 195057, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return s
        },
        formatWithValidation: function() {
            return u
        },
        urlObjectKeys: function() {
            return l
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = e.r(190809)._(e.r(998183)),
        o = /https?|ftp|gopher|file/;

    function s(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", i = e.pathname || "", s = e.hash || "", l = e.query || "", u = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? u = t + e.host : r && (u = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (u += ":" + e.port)), l && "object" == typeof l && (l = String(a.urlQueryToSearchParams(l)));
        let c = e.search || l && `?${l}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || o.test(n)) && !1 !== u ? (u = "//" + (u || ""), i && "/" !== i[0] && (i = "/" + i)) : u || (u = ""), s && "#" !== s[0] && (s = "#" + s), c && "?" !== c[0] && (c = "?" + c), i = i.replace(/[?#]/g, encodeURIComponent), c = c.replace("#", "%23"), `${n}${u}${i}${c}${s}`
    }
    let l = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function u(e) {
        return s(e)
    }
}, 898879, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(271645),
        i = "u" < typeof window,
        a = i ? () => {} : n.useLayoutEffect,
        o = i ? () => {} : n.useEffect;

    function s(e) {
        let {
            headManager: t,
            reduceComponentsToState: r
        } = e;

        function s() {
            if (t && t.mountedInstances) {
                let e = n.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
                t.updateHead(r(e))
            }
        }
        return i && (t ? .mountedInstances ? .add(e.children), s()), a(() => (t ? .mountedInstances ? .add(e.children), () => {
            t ? .mountedInstances ? .delete(e.children)
        })), a(() => (t && (t._pendingUpdate = s), () => {
            t && (t._pendingUpdate = s)
        })), o(() => (t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null), () => {
            t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null)
        })), null
    }
}, 718967, (e, t, r) => {
    "use strict";
    e.i(247167), Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DecodeError: function() {
            return v
        },
        MiddlewareNotFoundError: function() {
            return x
        },
        MissingStaticPage: function() {
            return b
        },
        NormalizeError: function() {
            return w
        },
        PageNotFoundError: function() {
            return y
        },
        SP: function() {
            return p
        },
        ST: function() {
            return g
        },
        WEB_VITALS: function() {
            return a
        },
        execOnce: function() {
            return o
        },
        getDisplayName: function() {
            return d
        },
        getLocationOrigin: function() {
            return u
        },
        getURL: function() {
            return c
        },
        isAbsoluteUrl: function() {
            return l
        },
        isResSent: function() {
            return f
        },
        loadGetInitialProps: function() {
            return m
        },
        normalizeRepeatedSlashes: function() {
            return h
        },
        stringifyError: function() {
            return j
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

    function o(e) {
        let t, r = !1;
        return (...n) => (r || (r = !0, t = e(...n)), t)
    }
    let s = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
        l = e => {
            let t = e.charCodeAt(0);
            return !!(t >= 65 && t <= 90 || t >= 97 && t <= 122) && s.test(e)
        };

    function u() {
        let {
            protocol: e,
            hostname: t,
            port: r
        } = window.location;
        return `${e}//${t}${r?":"+r:""}`
    }

    function c() {
        let {
            href: e
        } = window.location, t = u();
        return e.substring(t.length)
    }

    function d(e) {
        return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
    }

    function f(e) {
        return e.finished || e.headersSent
    }

    function h(e) {
        let t = e.split("?");
        return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
    }
    async function m(e, t) {
        let r = t.res || t.ctx && t.ctx.res;
        if (!e.getInitialProps) return t.ctx && t.Component ? {
            pageProps: await m(t.Component, t.ctx)
        } : {};
        let n = await e.getInitialProps(t);
        if (r && f(r)) return n;
        if (!n) throw Object.defineProperty(Error(`"${d(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
            value: "E1025",
            enumerable: !1,
            configurable: !0
        });
        return n
    }
    let p = "u" > typeof performance,
        g = p && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
    class v extends Error {}
    class w extends Error {}
    class y extends Error {
        constructor(e) {
            super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
        }
    }
    class b extends Error {
        constructor(e, t) {
            super(), this.message = `Failed to load static file for page: ${e} ${t}`
        }
    }
    class x extends Error {
        constructor() {
            super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
        }
    }

    function j(e) {
        return JSON.stringify({
            message: e.message,
            stack: e.stack
        })
    }
}]);