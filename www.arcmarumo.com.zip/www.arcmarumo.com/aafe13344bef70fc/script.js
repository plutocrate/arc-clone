"use strict";
(() => {
    var t = (t, e) => () => (t && (e = t(t = 0)), e),
        e = (t, e) => () => (e || t((e = {
            exports: {}
        }).exports, e), e.exports);

    function n(t) {
        let e = location.href;
        if (t) {
            let n = new URL(e);
            if (n.pathname !== t) return n.pathname = t, n.search = "", n.href
        }
        return e
    }

    function r() {
        return !!(navigator.webdriver || navigator.userAgent.includes("Headless"))
    }
    var i = t(() => {});

    function a(t, e, n) {
        let r = l(),
            i = p(t),
            a = r[t],
            o = r[i],
            u = a === e ? { ...o,
                ...n
            } : n;
        if (a === e && f(o, u)) return !1;
        let {
            [i]: s, ...c
        } = r;
        return d({ ...c,
            [t]: e,
            ...Object.keys(u).length && {
                [i]: u
            }
        }), !0
    }

    function o() {
        d({})
    }

    function u() {
        let {
            userId: t,
            groupId: e,
            traits: n,
            groupTraits: r
        } = l(), i = { ...n
        };
        for (let [a, o] of Object.entries(null != r ? r : {})) i[`group_${a}`] = o;
        return { ...t && {
                userId: t
            },
            ...e && {
                groupId: e
            },
            ...Object.keys(i).length && {
                props: i
            }
        }
    }

    function l() {
        if (g) return h;
        try {
            let t = localStorage.getItem(v);
            h = t ? s(JSON.parse(t)) : {}
        } catch (e) {}
        return h
    }

    function d(t) {
        h = t;
        try {
            t.userId || t.groupId ? localStorage.setItem(v, JSON.stringify(t)) : localStorage.removeItem(v), g = !1
        } catch (e) {
            g = !0
        }
    }

    function s(t) {
        return { ..."string" == typeof t.userId && {
                userId: t.userId,
                ...c(t.traits) && {
                    traits: t.traits
                }
            },
            ..."string" == typeof t.groupId && {
                groupId: t.groupId,
                ...c(t.groupTraits) && {
                    groupTraits: t.groupTraits
                }
            }
        }
    }

    function c(t) {
        return "object" == typeof t && null !== t && !Array.isArray(t)
    }

    function p(t) {
        return "userId" === t ? "traits" : "groupTraits"
    }

    function f(t = {}, e = {}) {
        let n = Object.keys(t);
        return n.length === Object.keys(e).length && n.every(n => n in e && t[n] === e[n])
    }
    var v, h, g, y = t(() => {
        v = "__va_attribution", h = {}, g = !1
    });
    e(() => {
        i(), y(),
            function() {
                var t;
                let e = "0.1.3",
                    i = t => t,
                    l = document,
                    d = l.currentScript;
                if (r()) return;
                let s = null != (t = null == d ? void 0 : d.dataset) ? t : {},
                    c = w(s, "view"),
                    p = w(s, "event"),
                    f = w(s, "session"),
                    v = w(s, "identify"),
                    h = w(s, "group"),
                    g = null,
                    y = null,
                    _ = !0;

                function w(t, e) {
                    return t[`${e}Endpoint`] || ("endpoint" in t ? `${t.endpoint}/${e}` : `${null!=d&&d.src.includes("/va/")?"/va":"/_vercel/insights"}/${e}`)
                }
                async function I(t) {
                    if (t && !Array.isArray(t)) return {
                        p: t
                    };
                    let e = l.querySelectorAll("[data-flag-values]");
                    if (!d || !e.length) return;
                    let n = new URL(d.src),
                        r = n.pathname.split("/"),
                        i = r.pop();
                    return i && r.push("flags", i), n.pathname = r.join("/"),
                        import (n.href).then(n => n.gather(e, t))
                }
                async function m(t, e) {
                    try {
                        await fetch(t, {
                            method: "POST",
                            keepalive: !0,
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(e)
                        })
                    } catch (n) {}
                }
                async function k({
                    type: t,
                    data: r,
                    options: a
                }) {
                    var o;
                    let d = n(y),
                        f = null == a ? void 0 : a.__cdp,
                        v = l.referrer,
                        h = i({
                            type: t,
                            url: d,
                            payload: r,
                            ...void 0 !== f && {
                                __cdp: f
                            }
                        });
                    if (!1 === h || null === h) return;
                    h && (d = h.url, r = null != (o = h.payload) ? o : r, f = h.__cdp);
                    let _ = v.includes(location.host),
                        w = {
                            o: d,
                            sv: e,
                            sdkn: s.sdkn,
                            sdkv: s.sdkv,
                            ...g && {
                                dp: g
                            },
                            ...null != a && a.withReferrer && !_ ? {
                                r: v
                            } : {},
                            ...u(),
                            ..."event" === t && r && {
                                en: r.name,
                                ed: r.data
                            },
                            f: await I(null == a ? void 0 : a.flags).catch(() => {}),
                            ...void 0 !== f && {
                                __cdp: f
                            }
                        };
                    return m("pageview" === t ? c : p, w)
                }
                async function b(t = {}) {
                    return k({
                        type: "pageview",
                        options: {
                            withReferrer: t.withReferrer,
                            __cdp: t.__cdp
                        }
                    })
                }
                async function S(t, e, n) {
                    return k({
                        type: "event",
                        data: {
                            name: t,
                            data: e
                        },
                        options: {
                            withReferrer: !0,
                            flags: null == n ? void 0 : n.flags,
                            __cdp: null == n ? void 0 : n.__cdp
                        }
                    })
                }
                async function R(t, r, o, l, d) {
                    var c, p;
                    let f = {
                            type: "event",
                            url: n(y),
                            payload: {
                                name: t,
                                data: { ...l,
                                    [r]: o
                                }
                            },
                            ...void 0 !== d && {
                                __cdp: d
                            }
                        },
                        _ = i(f);
                    if (!1 === _ || null === _) return;
                    let w = _ || f;
                    d = w.__cdp;
                    let {
                        [r]: I, ...k
                    } = null != (p = null == (c = w.payload) ? void 0 : c.data) ? p : {};
                    if ("string" != typeof I || !I || !a(r, I, k) && void 0 === d) return;
                    let b = { ...{
                            o: w.url,
                            sv: e,
                            sdkn: s.sdkn,
                            sdkv: s.sdkv,
                            ...g && {
                                dp: g
                            }
                        },
                        ...u(),
                        en: t,
                        ...Object.keys(k).length && {
                            ed: k
                        },
                        ...void 0 !== d && {
                            __cdp: d
                        }
                    };
                    return m("identify" === t ? v : h, b)
                }
                async function O() {
                    await fetch(f, {
                        method: "GET",
                        keepalive: !0
                    }).catch(() => {})
                }

                function j(t) {
                    return t.pathname === new URL(A).pathname
                }

                function T(t) {
                    let e = t ? "string" == typeof t ? new URL(t, location.origin) : new URL(t.href) : null;
                    !e || j(e) || e.hash && j(e) || b()
                }
                let A = n(),
                    L = () => {
                        var t;
                        window.va = function(t, e) {
                            "beforeSend" === t ? i = e : "event" === t ? e && S(e.name, e.data, { ...e.options,
                                __cdp: e.__cdp
                            }) : "pageview" === t ? e && (e.route && (g = e.route), e.path && (y = e.path), b({
                                withReferrer: _,
                                __cdp: e.__cdp
                            }), _ = !1) : "identify" === t ? null != e && e.userId && R("identify", "userId", e.userId, e.traits, e.__cdp) : "group" === t ? null != e && e.groupId && R("group", "groupId", e.groupId, e.traits, e.__cdp) : "reset" !== t || o(), "enableCookie" === t && O()
                        }, null == (t = window.vaq) || t.forEach(([t, e]) => {
                            window.va(t, e)
                        })
                    };
                (() => {
                    if (window.vai || (window.vai = !0, L(), s.disableAutoTrack)) return;
                    b({
                        withReferrer: !0
                    });
                    let t = history.pushState.bind(history);
                    history.pushState = function(...e) {
                        t(...e);
                        try {
                            T(e[2]), A = n()
                        } catch (r) {}
                    }, window.addEventListener("popstate", function() {
                        T(n()), A = n()
                    })
                })()
            }()
    })()
})();